独立 consumer の最終 source と実行証拠 pack です。結論は review-final.md と evidence/final-review.json にあります。

Source commit: f792b1584ab81013cfc666beaae0acdff074b2ba
Canonical generation input SHA256: cb241770048f238645ea4abde58d068dba39127aeee1158cc26feb2b3ce4f001
Root freeze manifest SHA256: 1e507a7aef14e7c431123e3339cba6c5a5a4d61c0aa4ce5726ce1467e3b10b6d

consumer.ts / tsconfig.consumer.json が public barrel だけを読む最小 production consumer です。raw src/templates/skills/examples と正確な package/lock、正常CLIの生成物 .ui/.agents、clean production dist と各配信資産、実 compile/native/browser/HTTP 結果、原失敗・修正後証拠、selected actual image inspection、最小回帰 test/patch を含みます。node_modules は含みません。依存は package-lock.json に固定しており、installed-exact.json が検証した46直接依存の版を保存します。

現在の再現入口は finalize-input.mjs → verify-types.mjs → build-consumer.mjs → verify-source-closure.mjs → serve-consumer.mjs、別端末から verify-browser.mjs / verify-media-locale.mjs / verify-scheduler-locale.mjs / inspect-browser.mjs / verify-distribution.mjs です。finalize-input.mjs は所有ディレクトリでのみ動き、読取元を第一引数へ渡せます。source/main/freeze 照合スクリプトはこのレビュー環境の元パスを使います。詳細コマンドは review-final.md にあります。

利用ガイドの最終作成物は deliverable-docs/docs/ui-library-consumer-guide.ja.md（SHA3f54fad40b11bcdb42b2bd412858c69efc5204afd2fb6facec9d68aecf2168be）です。自己作者なので独立 source 承認と分けています。docs は読取元の参考snapshotで、canonical製品入力比較の対象ではありません。

証拠名 before-fix / frozen / snapshot / harness-order は当時の結果を保持します。現在の判定は final-* と source provenance で読んでください。negative compilation の exit1 は期待した診断です。Scheduler初回の build 前実行失敗は harness ordering と記録し、製品findingに数えていません。

APPROVE は独立 public consumer / Foundation・Media 境界の記載範囲です。全181部品全状態の native 操作、全SSR/hydration、他browser/OS/AT、backend保存・実upload・Undo、font再compile/PGP、CSP enforcement は未観測です。axe incomplete は保持しています。共有Git/生成物にこのレビュアーから変更はありません。npm公開はしていません。
