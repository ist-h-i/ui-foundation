# 独立 consumer / Foundation・Media レビュー

判定: **APPROVE（記載した範囲）**。公開入口を使う生成 consumer と Foundation / Media の境界に、未修正の blocking finding はありません。全181部品の全状態の実操作や、業務アプリの完成を承認したという意味ではありません。

## 入力と所有範囲

読取元: `/tmp/ui-foundation-final-integration/repository`。レビュー用書込先は `/tmp/ui-foundation-final-catalog-consumer-review` のみ。共有 repo/Git/生成物へ直接編集していません。
生成入力（src/templates/skills/examples と package/lock）の canonical SHA256: `cb241770048f238645ea4abde58d068dba39127aeee1158cc26feb2b3ce4f001`。資産入力 SHA256: `78fa8b8151769a869225fc9bfcdfeb1b6d3f8401f256e1e638b7c5cae2c809e8`。最終操作後にも読取元・own コピーの各ファイルを再照合しました。共有mainのraw入力・資産とのread-only照合も一致しています。
共有 main の source commit は `f792b1584ab81013cfc666beaae0acdff074b2ba`（read-only git rev-parse exit 0）。root freeze manifest SHA256 は `1e507a7aef14e7c431123e3339cba6c5a5a4d61c0aa4ce5726ce1467e3b10b6d`。product対象147件を root/private/own とmanifestのSHAで照合しています。
raw Angular TS は139件。公開 consumer の closure は138件で、数式 worker 1件を別本番 entry として compile/bundle。union は139件。managed 生成物は150件です。

## 実行した検証

- 通常 CLI の sync/check/2回目sync/dry-run はすべて exit 0。check、2回目sync、dry-run 前後で manifest と managed 全ファイルの bytes/hash が一致。generated の手編集はありません。
- 公開 barrel だけから import する consumer、include は consumer.ts 一つ、strictTemplates/AOT positive exit 0。実 worker の ngc と clean production ESM bundle も exit 0。
- 8 negative は各 exit 1 と意図した診断を確認。typed tree/scheduler/table context、ChartKind、FileUpload.value、nullable FormControl、parser の型と barrel 無し ambient 欠落。nullable negative はアプリ control 型の検査であり、Angular CVA 接続の完全な値型保証とは区別。
- Media追加live localeのguided/denseは各17観測が合格。実失敗から保持した5error、比較sliderのparameterized ARIA、3既存statusが辞書更新へ追随し、再取得/worker再作成0・同一DOM/focus・FileCVA・app labelsを保持。Gridではlibrary辞書keyと完全一致するapp提供errorをrawのまま保持することもnativeで確認。
- Scheduler追加nativeはguided/dense各1ケース合格。zone修復とnative日時の再編集で旧cached statusを消し、app failMoveの辞書key完全一致raw文言、retry新ID/旧ACK拒否、DOM/focusと元eventsを保持。
- 6 route の actual render はすべて page error / console warning/error 0。最終 native Chromium は23/23、page error 0。実 clipboard、画像、WAV/VTT、native dialog、実 worker と lazy chunks を使用。旧 media 6所見の対象を fresh 操作で再測定。
- HTTP 資産231件を実配信 bytes/SHA/MIMEで照合。PDF kit 202件、kit 原 license 11件、対応 source 11件、4 TTF の mapping一致。media notice4原文と third-party notice 240435 bytesを保持。lazy vendor entryは22件。全distributionは311 files / 43691632 bytes（source mapsを含む観測値）。

| 境界 | 最終 native 観測 |
| --- | --- |
| DateRange | invalid start + valid end で確定 range を保持、修正時のみ atomic commit、same reset、disabled、format設定変更でもraw/invalid/selection保持、native badInput、valid修復/clear/calendar/resetで新書式採用（2 profile） |
| Composer / Chat | same/new/null reset、controlled値、親CVA、旧ACK拒否、unknown draft、app error保持と再試行、新要求成功、2 profile |
| FileUpload | real File[]、mixed rejection時のCVA保持、既存拒否理由のlive辞書更新、Validator、unknown draft保持、readonly/disabled/reset、remount ID/request epoch |
| Scheduler | cached errorのlive辞書更新と修復後解除、app error raw保持、retry新ID/旧ACK拒否、同一DOM/focusと元events保持（2 profile、resource checkbox writerはソースレビューのみ） |
| Locale | public UI_LOCALE DI、public CDK Directionality、明示 input/外部attrs優先、scope破棄時owned属性cleanupとchange.complete |
| Keyboard / Focus | Tree ArrowDown/EnterとpopupCVA、DataGrid F2/invalid draft/失敗復旧、実clipboard、Dialog Escape/opener/draft保持 |
| Media play / Caption | 実native play後の旧Promise completion、pending新要求、native reentry/source epoch、実VTT cue removal/同ID source変更/reorder |
| PDF | 実workerによる2ページの異なるcanvas/text、named region、null unload/terminate、invalid/再取得/valid復旧 |
| Gallery / Lightbox | native pointer Stopとfocus意図、keyboard再開、2 profileで0/90/180/270度positive scroll bounds、Escape focus |
| Specialist | 実Chart SVG、MapLibre canvas/worker（外部mapdata0）、Spreadsheet workerのSUM=5、CodeMirror/ProseMirror実描画 |

axe は5観測の violations 0。incompleteのrule/nodeはJSONにそのまま保存しています。guided/dense、320px/200%/RTLのdraftとselection/DOM保持、水平overflowなしを測定し画像も確認しました。

## Finding とソースレビュー

P2: MessageComposer が明示CVA reset後にも以前の送信エラーを残す問題を native で再現して root に報告しました。root 修正は writeValue で invalidatePending 直後に sendError を消す最小変更です。一般 invalidatePending は変更せず、既存retry/pending契約を維持。修正後の両profileでexplicit reset・旧応答・新失敗/成功・親Chat・controlled valueを再測定し合格しました。
修正後 chat.ts SHA256: `e2dc44531a698721ca72794fcb49af200fff7414359e677dfe47366fb79b34d1`。原 findingのJSON/画像と修正前SHAを evidence に保持しています。

P2: DatePicker の DI dateInputFormat 変更で invalid draft を失い reset なしで valid になる問題もnativeで報告しました。修正後のguided/denseでcustom/nativeを含むformat変更中のraw/invalid/DOM/focus/selectionと確定range保持、nativeキーボードのbadInput保持、valid修復・clear・calendar・resetで新format適用を確認しました。修正後 date-input.ts SHA256: `f162b85c9367569c79f403a3fd21773e37f57672f30a600e3f50b82e73e99829`。修正前の実失敗ログ/画像も保持しています。

P2: 保持済みMedia error/statusとImageCompare ARIAがlive辞書変更へ追随しないfamilyも独立consumerで実native再現しました。修正後は両profileで既存5errorと3statusの辞書更新、parameterizedARIA、再取得なし・同一DOM/CVA・app labels保持を確認しました。rootの内部message stateはraw app文字とlibrary-owned部分を分け、動的数値/分岐を書込時に保持します。FileUpload既存rejection理由のlive更新もCVA/Validator/DOM/focus保持と一緒に再測定。元失敗結果もevidenceへ保存しています。

P2: Scheduler の修復済み移動draftへ以前のcached errorが残る問題を両profileで実証しました。修正後はinvalid zone→既存errorの辞書更新→zone修復でstatus解除し、業務failureのraw文字とretry/旧ACK拒否を確認しました。修正後 scheduler-controller.ts SHA256: `238581d46425796e32f941fd486936348d9aa82b1da1c3f13f4b3afb68be7931`。元実失敗JSON/画像と最小patchを保持しています。

FileUploadのatomic intake/CVA Validator、conditions依存とreset、未知値、retained entryからのrequest epoch、DateRangeの両側draft、Composerのapp ACK所有、locale defaults/明示入力とCDK/属性cleanupをソースと実操作で確認しました。source reviewをnative実証と混同していません。実UiLocaleScopeのproduction server DI/global trapではbrowser globals read 0、owned属性cleanupを確認。host/Renderer2は試験adapterであり全SSR/hydrationは未確認です。

## 再現入口・成果物

最小 source は `consumer.ts`、`tsconfig.consumer.json`。`finalize-input.mjs` は raw入力を own領域へ正確にコピーして通常CLIを実行し、`verify-types.mjs` がpositive/negativeを実compileします。`build-consumer.mjs` は独立clean bundle、`verify-source-closure.mjs` はcompile経路の139件照合です。

```sh
cd /tmp/ui-foundation-final-catalog-consumer-review
node finalize-input.mjs /tmp/ui-foundation-final-integration/repository
node verify-types.mjs
node build-consumer.mjs
node verify-source-closure.mjs
node verify-main-source-exact.mjs
node verify-root-freeze.mjs
node serve-consumer.mjs
# 別の端末で同じ own directory から実行
node verify-browser.mjs
node verify-media-locale.mjs
node verify-scheduler-locale.mjs
node inspect-browser.mjs
node verify-distribution.mjs
node --import tsx scope-server-trap.ts
```

実行ログ、期待negativeの診断/source、final input/generated/installed manifests、実browser結果、distribution各fileのbytes/SHA、実view対象とSHAのvisual-final.json、画像は `evidence/` に保存。`final-review.json` が機械可読の結論とscript SHAを持ちます。最終結果のJSON保存先はbrowser-final-results.jsonです。

Date書式回帰の正式fixture向けコピー候補は `deliverable-tests/foundation-date-format-retention.spec.ts`（4本、既存fixture変更0）。独立consumerの実測とroot正式testの実行は区別しています。

利用ガイドは `deliverable-docs/docs/ui-library-consumer-guide.ja.md`。レビュアーが作成した文書なので、このsource承認を利用ガイド自身への独立レビュー承認とは扱いません。rootで採用前に内容を確認できます。

## 未観測

- Browser checks cover selected boundaries, not all 181 components and states.
- Application backend persistence, uploads, Undo and screen-reader/user understanding are not exercised. Application result callbacks are deliberately supplied; upload entries remain queued.
- Chromium only; Firefox/Safari, OS IME/touch and assistive-technology operation are unobserved.
- UiLocaleScope server DI/global trap uses host and Renderer2 adapters; no full SSR rendering or hydration claim.
- axe incomplete results are preserved without upgrading them to passes.
- CSP policy and font-source recompilation/PGP signatures are unobserved.
- No npm publication, shared Git mutation or messages to third parties performed by this reviewer.
