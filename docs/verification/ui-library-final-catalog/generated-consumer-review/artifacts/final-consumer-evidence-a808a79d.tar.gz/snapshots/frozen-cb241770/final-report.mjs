import {readFile,writeFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const read=async path=>JSON.parse(await readFile(path,'utf8'));
const input=await read('evidence/input-final.json'),assets=await read('evidence/input-assets-final.json');
for(const [path,sha] of Object.entries({...input.files,...assets.files})){assert.equal(hash(await readFile(path)),sha,path+' own final exactness');assert.equal(hash(await readFile(input.source+'/'+path)),sha,path+' current source exactness');}
const cli=await read('evidence/final-cli-results.json'),types=await read('evidence/type-results.json'),build=await read('evidence/build-results.json'),closure=await read('evidence/compile-source-closure.json'),browser=await read('evidence/browser-final-results.json'),smoke=await read('evidence/smoke-final.json'),distribution=await read('evidence/distribution-verification.json'),scope=await read('evidence/scope-server-trap.json'),generated=await read('evidence/generated-inventory-final.json');
assert.equal(cli.inputDigest,input.sha256);assert.ok(cli.commands.every(x=>x.exit===0));
assert.equal(types.results.length,9);assert.ok(types.results.every(x=>x.exit===x.expectedExit));
assert.equal(build.workerCompileExit,0);assert.equal(build.consumerSourceSha256,hash(await readFile('consumer.ts')));assert.equal(build.generatedManifestSha256,cli.generatedManifestSha);
assert.equal(closure.unionGeneratedTsCount,139);assert.equal(browser.length,23);assert.ok(browser.every(x=>x.pass));assert.equal(smoke.length,6);assert.ok(smoke.every(x=>x.errors.length===0));
const mediaLocale=await read('evidence/media-locale-results.json');assert.equal(mediaLocale.inputSha256,input.sha256);assert.equal(mediaLocale.results.length,2);assert.ok(mediaLocale.results.every(result=>result.pass&&result.checks.every(check=>check.pass)&&result.sameDom&&result.noReload&&result.appLabelsRetained&&result.fileCvaRetained));for(const [name,sha]of Object.entries(mediaLocale.sources))assert.equal(input.files['templates/angular/'+name],sha);
const schedulerLocale=await read('evidence/scheduler-locale-results.json');assert.equal(schedulerLocale.inputSha256,input.sha256);assert.equal(schedulerLocale.results.length,2);assert.ok(schedulerLocale.sourceReview.every(entry=>entry.messageTextCleared));assert.ok(schedulerLocale.results.every(result=>result.pass&&result.checks.every(check=>check.pass)&&result.sameDom&&result.appEventsUnchanged));for(const [name,sha]of Object.entries(schedulerLocale.sources))assert.equal(input.files['templates/angular/'+name],sha);
const browserSource=await read('evidence/browser-source-provenance.json');assert.equal(browserSource.inputSha256,input.sha256);assert.equal(browserSource.consumerSourceSha256,build.consumerSourceSha256);assert.equal(browserSource.generatedManifestSha256,build.generatedManifestSha256);assert.equal(browserSource.caseCount,23);assert.equal(browserSource.caseFilter,null);
const visual=await read('evidence/visual-final.json');assert.equal(visual.inputSha256,input.sha256);assert.ok(visual.images.length>0);for(const entry of visual.images)assert.equal(hash(await readFile(entry.path)),entry.sha256);
const freeze=await read('evidence/root-product-freeze-guard.json');assert.equal(freeze.inputSha256,input.sha256);assert.equal(freeze.allEqual,true);
assert.equal(scope.actualClass,'UiLocaleScope');assert.deepEqual(scope.browserGlobalsRead,[]);assert.equal(distribution.pdfSourceKit.length,11);
assert.notEqual(input.files['templates/angular/date-input.ts'],'ed998d1b5fdc891802c4ceec04314d945426368a099879fdffc952d213283ccc','date format draft-loss finding requires a source correction');
const mainExact=await read('evidence/main-source-exact.json');assert.equal(mainExact.allEqual,true);assert.equal(mainExact.inputSha256,input.sha256);assert.equal(mainExact.assetSha256,assets.sha256);
const sourceCommit=await read('evidence/final-source-commit.json');assert.equal(sourceCommit.inputSha256,input.sha256);assert.equal(sourceCommit.exit,0);assert.equal(sourceCommit.rootFreezeManifestSha256,freeze.manifestSha256);
const axe=[];const collect=(value,name)=>{if(!value||typeof value!=='object')return;if(Array.isArray(value)){for(const item of value)collect(item,name);return;}if(Array.isArray(value.violations)&&Array.isArray(value.incomplete)){assert.deepEqual(value.violations,[]);axe.push({case:name,state:value.state??null,violations:0,incomplete:value.incomplete.map(rule=>({id:rule.id,nodes:rule.nodes?.length??0}))});}for(const [key,v]of Object.entries(value))if(key!=='violations'&&key!=='incomplete')collect(v,name);};for(const item of browser)collect(item.observation,item.name);
const proofNames=['consumer.ts','tsconfig.consumer.json','finalize-input.mjs','verify-types.mjs','build-consumer.mjs','verify-source-closure.mjs','verify-main-source-exact.mjs','verify-root-freeze.mjs','serve-consumer.mjs','verify-browser.mjs','verify-media-locale.mjs','verify-scheduler-locale.mjs','inspect-browser.mjs','verify-distribution.mjs','scope-server-trap.ts','probe-native-date-bad-input.mjs','deliverable-tests/foundation-date-format-retention.spec.ts','final-report.mjs'];const proofScripts={};for(const name of proofNames)proofScripts[name]={sha256:hash(await readFile(name)),bytes:(await readFile(name)).length};
const report={decision:'APPROVE',scope:'Independent generated public consumer and Foundation / Media boundaries only',source:input.source,inputSha256:input.sha256,assetSha256:assets.sha256,rawTemplateTsCount:input.templateTsCount,generatedManagedFileCount:Object.keys(generated.files).length,positiveAotExit:0,negativeAotExits:types.results.filter(x=>x.expectedExit!==0).map(x=>({name:x.name,exit:x.exit})),compileSourceClosure:{consumer:138,separateWorker:1,union:139},browserCases:browser.map(x=>({name:x.name,pass:x.pass,errors:x.errors,warnings:x.warnings})),smokeRoutes:smoke.map(x=>({route:x.route,errors:x.errors})),axe,build,distribution:{httpAssetCount:distribution.assetCount,pdfCompanions:distribution.pdfCompanionCount,pdfCompanionLicenseFiles:distribution.pdfCompanionLicenseFiles.length,pdfSourceFiles:distribution.pdfSourceKit.length,fontMappings:distribution.fontChecks.length,thirdPartyNotice:distribution.thirdPartyNotice,fullMediaNotices:distribution.noticeChecks.length,lazyVendorEntries:distribution.lazyOutputs.length},fixedFinding:{severity:'P2',file:'templates/angular/chat.ts',before:'d7aeeda144b14d74862dd8fdc1f1a0fbd476668386da3093a6b44614fdcac5f6',after:input.files['templates/angular/chat.ts'],problem:'An explicit composer CVA reset retained an error from the previous send request.',correction:'writeValue clears sendError immediately after invalidatePending; general invalidation retains its retry contract.',nativeRegression:'same/new/null reset, parent Chat delegate, controlled value, stale responses and fresh failure/retry/success in guided/dense'},fixedMediaLocaleFinding:{severity:'P2',beforeInput:'766fb21de8fbe85c2ef0def3f3cdbeeadb4a06231d8fb3bd9e8eadceb21fde2c',afterInput:input.sha256,regression:'guided/dense; existing five native engine/acquisition error messages and ImageCompare parameterized aria-valuetext update D1 to D2; existing PDF/Crop empty and Media paused statuses update D2 to D3, without network/worker restart, DOM/focus/CVA or app-label loss.'},mediaLocale:{profiles:mediaLocale.results.map(result=>({profile:result.profile,pass:result.pass,checks:result.checks,errors:result.errors,warnings:result.warnings})),sourceSha256:mediaLocale.sources},remainingBlockingFindings:[],mainExact,proofScripts,guide:{path:'deliverable-docs/docs/ui-library-consumer-guide.ja.md',sha256:hash(await readFile('deliverable-docs/docs/ui-library-consumer-guide.ja.md')),authoredByReviewer:true,independentReviewOfGuide:false},limits:['Browser checks cover selected boundaries, not all 181 components and states.','Application backend persistence, uploads, Undo and screen-reader/user understanding are not exercised. Application result callbacks are deliberately supplied; upload entries remain queued.','Chromium only; Firefox/Safari, OS IME/touch and assistive-technology operation are unobserved.','UiLocaleScope server DI/global trap uses host and Renderer2 adapters; no full SSR rendering or hydration claim.','axe incomplete results are preserved without upgrading them to passes.','CSP policy and font-source recompilation/PGP signatures are unobserved.','No npm publication, shared Git mutation or messages to third parties performed by this reviewer.']};
report.sourceCommit=sourceCommit;report.schedulerLocale=schedulerLocale;report.visual=visual;report.rootFreeze=freeze;report.browserSource=browserSource;report.fixedSchedulerCachedStatusFinding={severity:'P2',before:'598da9e5bc96741515f699891abaf76169e1379cb5d124d8a33eedb8e0062fb1',after:input.files['templates/angular/scheduler-controller.ts'],problem:'Editing a repaired move draft cleared message but left its prior messageText reader, keeping a stale error in role=status.',nativeRegression:'guided/dense: existing invalid-zone error follows two live dictionaries; repair clears alert and cached status; application failMove text matching the exact library dictionary key remains raw; retry new ID and stale response refusal; same DOM/focus and app events unchanged.'};
report.fixedDateFormatFinding={severity:'P2',file:'templates/angular/date-input.ts',before:'ed998d1b5fdc891802c4ceec04314d945426368a099879fdffc952d213283ccc',after:input.files['templates/angular/date-input.ts'],problem:'Changing DI dateInputFormat discarded an invalid draft and cleared validation without reset.',nativeRegression:'guided/dense custom/native format requests retain raw draft, invalid state, DOM/focus/selection and confirmed range; valid repair, child/range clear, calendar selection and explicit reset adopt the configured format; actual native keyboard badInput also retains its native DOM and invalid status.'};
await writeFile('evidence/final-review.json',JSON.stringify(report,null,2)+'\n');
const lines=[
'# 独立 consumer / Foundation・Media レビュー',
'',
'判定: **APPROVE（記載した範囲）**。公開入口を使う生成 consumer と Foundation / Media の境界に、未修正の blocking finding はありません。全181部品の全状態の実操作や、業務アプリの完成を承認したという意味ではありません。',
'',
'## 入力と所有範囲',
'',
`読取元: \`${input.source}\`。レビュー用書込先は \`/tmp/ui-foundation-final-catalog-consumer-review\` のみ。共有 repo/Git/生成物へ直接編集していません。`,
`生成入力（src/templates/skills/examples と package/lock）の canonical SHA256: \`${input.sha256}\`。資産入力 SHA256: \`${assets.sha256}\`。最終操作後にも読取元・own コピーの各ファイルを再照合しました。共有mainのraw入力・資産とのread-only照合も一致しています。`,
`共有 main の source commit は \`${sourceCommit.sourceCommit}\`（read-only git rev-parse exit 0）。root freeze manifest SHA256 は \`${freeze.manifestSha256}\`。product対象147件を root/private/own とmanifestのSHAで照合しています。`,
`raw Angular TS は139件。公開 consumer の closure は138件で、数式 worker 1件を別本番 entry として compile/bundle。union は139件。managed 生成物は${Object.keys(generated.files).length}件です。`,
'',
'## 実行した検証',
'',
'- 通常 CLI の sync/check/2回目sync/dry-run はすべて exit 0。check、2回目sync、dry-run 前後で manifest と managed 全ファイルの bytes/hash が一致。generated の手編集はありません。',
'- 公開 barrel だけから import する consumer、include は consumer.ts 一つ、strictTemplates/AOT positive exit 0。実 worker の ngc と clean production ESM bundle も exit 0。',
'- 8 negative は各 exit 1 と意図した診断を確認。typed tree/scheduler/table context、ChartKind、FileUpload.value、nullable FormControl、parser の型と barrel 無し ambient 欠落。nullable negative はアプリ control 型の検査であり、Angular CVA 接続の完全な値型保証とは区別。',
'- Media追加live localeのguided/denseは各17観測が合格。実失敗から保持した5error、比較sliderのparameterized ARIA、3既存statusが辞書更新へ追随し、再取得/worker再作成0・同一DOM/focus・FileCVA・app labelsを保持。Gridではlibrary辞書keyと完全一致するapp提供errorをrawのまま保持することもnativeで確認。',
'- Scheduler追加nativeはguided/dense各1ケース合格。zone修復とnative日時の再編集で旧cached statusを消し、app failMoveの辞書key完全一致raw文言、retry新ID/旧ACK拒否、DOM/focusと元eventsを保持。',
'- 6 route の actual render はすべて page error / console warning/error 0。最終 native Chromium は23/23、page error 0。実 clipboard、画像、WAV/VTT、native dialog、実 worker と lazy chunks を使用。旧 media 6所見の対象を fresh 操作で再測定。',
`- HTTP 資産${distribution.assetCount}件を実配信 bytes/SHA/MIMEで照合。PDF kit ${distribution.pdfCompanionCount}件、kit 原 license ${distribution.pdfCompanionLicenseFiles.length}件、対応 source ${distribution.pdfSourceKit.length}件、4 TTF の mapping一致。media notice4原文と third-party notice ${distribution.thirdPartyNotice.bytes} bytesを保持。lazy vendor entryは${distribution.lazyOutputs.length}件。全distributionは${build.distributionFiles} files / ${build.distributionBytes} bytes（source mapsを含む観測値）。`,
'',
'| 境界 | 最終 native 観測 |',
'| --- | --- |',
'| DateRange | invalid start + valid end で確定 range を保持、修正時のみ atomic commit、same reset、disabled、format設定変更でもraw/invalid/selection保持、native badInput、valid修復/clear/calendar/resetで新書式採用（2 profile） |',
'| Composer / Chat | same/new/null reset、controlled値、親CVA、旧ACK拒否、unknown draft、app error保持と再試行、新要求成功、2 profile |',
'| FileUpload | real File[]、mixed rejection時のCVA保持、既存拒否理由のlive辞書更新、Validator、unknown draft保持、readonly/disabled/reset、remount ID/request epoch |',
'| Scheduler | cached errorのlive辞書更新と修復後解除、app error raw保持、retry新ID/旧ACK拒否、同一DOM/focusと元events保持（2 profile、resource checkbox writerはソースレビューのみ） |',
'| Locale | public UI_LOCALE DI、public CDK Directionality、明示 input/外部attrs優先、scope破棄時owned属性cleanupとchange.complete |',
'| Keyboard / Focus | Tree ArrowDown/EnterとpopupCVA、DataGrid F2/invalid draft/失敗復旧、実clipboard、Dialog Escape/opener/draft保持 |',
'| Media play / Caption | 実native play後の旧Promise completion、pending新要求、native reentry/source epoch、実VTT cue removal/同ID source変更/reorder |',
'| PDF | 実workerによる2ページの異なるcanvas/text、named region、null unload/terminate、invalid/再取得/valid復旧 |',
'| Gallery / Lightbox | native pointer Stopとfocus意図、keyboard再開、2 profileで0/90/180/270度positive scroll bounds、Escape focus |',
'| Specialist | 実Chart SVG、MapLibre canvas/worker（外部mapdata0）、Spreadsheet workerのSUM=5、CodeMirror/ProseMirror実描画 |',
'',
`axe は${axe.length}観測の violations 0。incompleteのrule/nodeはJSONにそのまま保存しています。guided/dense、320px/200%/RTLのdraftとselection/DOM保持、水平overflowなしを測定し画像も確認しました。`,
'',
'## Finding とソースレビュー',
'',
'P2: MessageComposer が明示CVA reset後にも以前の送信エラーを残す問題を native で再現して root に報告しました。root 修正は writeValue で invalidatePending 直後に sendError を消す最小変更です。一般 invalidatePending は変更せず、既存retry/pending契約を維持。修正後の両profileでexplicit reset・旧応答・新失敗/成功・親Chat・controlled valueを再測定し合格しました。',
`修正後 chat.ts SHA256: \`${input.files['templates/angular/chat.ts']}\`。原 findingのJSON/画像と修正前SHAを evidence に保持しています。`,
'',
`P2: DatePicker の DI dateInputFormat 変更で invalid draft を失い reset なしで valid になる問題もnativeで報告しました。修正後のguided/denseでcustom/nativeを含むformat変更中のraw/invalid/DOM/focus/selectionと確定range保持、nativeキーボードのbadInput保持、valid修復・clear・calendar・resetで新format適用を確認しました。修正後 date-input.ts SHA256: \`${input.files['templates/angular/date-input.ts']}\`。修正前の実失敗ログ/画像も保持しています。`,
'',
'P2: 保持済みMedia error/statusとImageCompare ARIAがlive辞書変更へ追随しないfamilyも独立consumerで実native再現しました。修正後は両profileで既存5errorと3statusの辞書更新、parameterizedARIA、再取得なし・同一DOM/CVA・app labels保持を確認しました。rootの内部message stateはraw app文字とlibrary-owned部分を分け、動的数値/分岐を書込時に保持します。FileUpload既存rejection理由のlive更新もCVA/Validator/DOM/focus保持と一緒に再測定。元失敗結果もevidenceへ保存しています。',
'',
`P2: Scheduler の修復済み移動draftへ以前のcached errorが残る問題を両profileで実証しました。修正後はinvalid zone→既存errorの辞書更新→zone修復でstatus解除し、業務failureのraw文字とretry/旧ACK拒否を確認しました。修正後 scheduler-controller.ts SHA256: \`${input.files['templates/angular/scheduler-controller.ts']}\`。元実失敗JSON/画像と最小patchを保持しています。`,
'',
'FileUploadのatomic intake/CVA Validator、conditions依存とreset、未知値、retained entryからのrequest epoch、DateRangeの両側draft、Composerのapp ACK所有、locale defaults/明示入力とCDK/属性cleanupをソースと実操作で確認しました。source reviewをnative実証と混同していません。実UiLocaleScopeのproduction server DI/global trapではbrowser globals read 0、owned属性cleanupを確認。host/Renderer2は試験adapterであり全SSR/hydrationは未確認です。',
'',
'## 再現入口・成果物',
'',
'最小 source は `consumer.ts`、`tsconfig.consumer.json`。`finalize-input.mjs` は raw入力を own領域へ正確にコピーして通常CLIを実行し、`verify-types.mjs` がpositive/negativeを実compileします。`build-consumer.mjs` は独立clean bundle、`verify-source-closure.mjs` はcompile経路の139件照合です。',
'',
'```sh',
'cd /tmp/ui-foundation-final-catalog-consumer-review',
'node finalize-input.mjs /tmp/ui-foundation-final-integration/repository',
'node verify-types.mjs',
'node build-consumer.mjs',
'node verify-source-closure.mjs',
'node verify-main-source-exact.mjs',
'node verify-root-freeze.mjs',
'node serve-consumer.mjs',
'# 別の端末で同じ own directory から実行',
'node verify-browser.mjs',
'node verify-media-locale.mjs',
'node verify-scheduler-locale.mjs',
'node inspect-browser.mjs',
'node verify-distribution.mjs',
'node --import tsx scope-server-trap.ts',
'```',
'',
'実行ログ、期待negativeの診断/source、final input/generated/installed manifests、実browser結果、distribution各fileのbytes/SHA、実view対象とSHAのvisual-final.json、画像は `evidence/` に保存。`final-review.json` が機械可読の結論とscript SHAを持ちます。最終結果のJSON保存先はbrowser-final-results.jsonです。',
'',
'Date書式回帰の正式fixture向けコピー候補は `deliverable-tests/foundation-date-format-retention.spec.ts`（4本、既存fixture変更0）。独立consumerの実測とroot正式testの実行は区別しています。',
'',
'利用ガイドは `deliverable-docs/docs/ui-library-consumer-guide.ja.md`。レビュアーが作成した文書なので、このsource承認を利用ガイド自身への独立レビュー承認とは扱いません。rootで採用前に内容を確認できます。',
'',
'## 未観測',
'',
...report.limits.map(limit=>'- '+limit),
'',
];
await writeFile('review-final.md',lines.join('\n'));
console.log(JSON.stringify({decision:report.decision,input:input.sha256,browserCases:23,sourceUnion:139,httpAssets:distribution.assetCount,report:'review-final.md',guide:report.guide.path}));
