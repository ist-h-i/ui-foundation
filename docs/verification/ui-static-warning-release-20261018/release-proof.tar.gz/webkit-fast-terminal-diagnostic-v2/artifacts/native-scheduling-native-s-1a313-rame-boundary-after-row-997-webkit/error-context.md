# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: native-scheduling.spec.ts >> native scheduling terminal C: one fixed frame boundary after row 997
- Location: docs/verification/ui-static-warning-release-20261018/webkit-fast-terminal-diagnostic-v2/native-scheduling.spec.ts:6:1

# Error details

```
Error: listener-free native clone exactly preserves source geometry, CSS and environment

expect(received).toEqual(expected) // deep equality

- Expected  - 182
+ Received  + 182

@@ -10,63 +10,63 @@
      "width": 320,
    },
    "rows": Array [
      Object {
        "css": Object {
-         "borderBottomWidth": "1px",
+         "borderBottomWidth": "0px",
          "borderLeftWidth": "0px",
          "borderRadius": "0px",
          "borderRightWidth": "0px",
          "borderTopWidth": "0px",
          "boxSizing": "border-box",
          "contain": "none",
          "direction": "ltr",
-         "font": "36px / 57.600002px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-         "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-         "fontSize": "36px",
-         "lineHeight": "57.600002px",
+         "font": "32px -webkit-standard",
+         "fontFamily": "-webkit-standard",
+         "fontSize": "32px",
+         "lineHeight": "normal",
          "overflowX": "auto",
          "overflowY": "auto",
-         "paddingBottom": "12px",
-         "paddingLeft": "24px",
-         "paddingRight": "24px",
-         "paddingTop": "12px",
+         "paddingBottom": "0px",
+         "paddingLeft": "0px",
+         "paddingRight": "0px",
+         "paddingTop": "0px",
          "scrollBehavior": "auto",
          "scrollPaddingBottom": "auto",
          "scrollPaddingTop": "auto",
        },
        "index": 994,
        "input": Object {
          "css": Object {
-           "borderBottomWidth": "1px",
-           "borderLeftWidth": "1px",
-           "borderRadius": "12px",
-           "borderRightWidth": "1px",
-           "borderTopWidth": "1px",
-           "boxSizing": "border-box",
+           "borderBottomWidth": "2px",
+           "borderLeftWidth": "2px",
+           "borderRadius": "0px",
+           "borderRightWidth": "2px",
+           "borderTopWidth": "2px",
+           "boxSizing": "content-box",
            "contain": "none",
            "direction": "ltr",
-           "font": "36px / 54px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-           "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-           "fontSize": "36px",
-           "lineHeight": "54px",
+           "font": "11px system-ui",
+           "fontFamily": "system-ui",
+           "fontSize": "11px",
+           "lineHeight": "normal",
            "overflowX": "visible",
            "overflowY": "visible",
-           "paddingBottom": "12px",
-           "paddingLeft": "24px",
-           "paddingRight": "24px",
-           "paddingTop": "12px",
+           "paddingBottom": "2px",
+           "paddingLeft": "5px",
+           "paddingRight": "5px",
+           "paddingTop": "2px",
            "scrollBehavior": "auto",
            "scrollPaddingBottom": "auto",
            "scrollPaddingTop": "auto",
          },
          "label": "再検証入力 994",
          "rect": Object {
-           "height": 80,
-           "left": 140,
-           "top": 12,
-           "width": 154,
+           "height": 21,
+           "left": 152,
+           "top": 13.5,
+           "width": 166,
          },
          "tabIndex": 0,
          "type": "text",
          "value": "元の入力 994",
        },
@@ -77,63 +77,63 @@
          "width": 318,
        },
      },
      Object {
        "css": Object {
-         "borderBottomWidth": "1px",
+         "borderBottomWidth": "0px",
          "borderLeftWidth": "0px",
          "borderRadius": "0px",
          "borderRightWidth": "0px",
          "borderTopWidth": "0px",
          "boxSizing": "border-box",
          "contain": "none",
          "direction": "ltr",
-         "font": "36px / 57.600002px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-         "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-         "fontSize": "36px",
-         "lineHeight": "57.600002px",
+         "font": "32px -webkit-standard",
+         "fontFamily": "-webkit-standard",
+         "fontSize": "32px",
+         "lineHeight": "normal",
          "overflowX": "auto",
          "overflowY": "auto",
-         "paddingBottom": "12px",
-         "paddingLeft": "24px",
-         "paddingRight": "24px",
-         "paddingTop": "12px",
+         "paddingBottom": "0px",
+         "paddingLeft": "0px",
+         "paddingRight": "0px",
+         "paddingTop": "0px",
          "scrollBehavior": "auto",
          "scrollPaddingBottom": "auto",
          "scrollPaddingTop": "auto",
        },
        "index": 995,
        "input": Object {
          "css": Object {
-           "borderBottomWidth": "1px",
-           "borderLeftWidth": "1px",
-           "borderRadius": "12px",
-           "borderRightWidth": "1px",
-           "borderTopWidth": "1px",
-           "boxSizing": "border-box",
+           "borderBottomWidth": "2px",
+           "borderLeftWidth": "2px",
+           "borderRadius": "0px",
+           "borderRightWidth": "2px",
+           "borderTopWidth": "2px",
+           "boxSizing": "content-box",
            "contain": "none",
            "direction": "ltr",
-           "font": "36px / 54px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-           "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-           "fontSize": "36px",
-           "lineHeight": "54px",
+           "font": "11px system-ui",
+           "fontFamily": "system-ui",
+           "fontSize": "11px",
+           "lineHeight": "normal",
            "overflowX": "visible",
            "overflowY": "visible",
-           "paddingBottom": "12px",
-           "paddingLeft": "24px",
-           "paddingRight": "24px",
-           "paddingTop": "12px",
+           "paddingBottom": "2px",
+           "paddingLeft": "5px",
+           "paddingRight": "5px",
+           "paddingTop": "2px",
            "scrollBehavior": "auto",
            "scrollPaddingBottom": "auto",
            "scrollPaddingTop": "auto",
          },
          "label": "再検証入力 995",
          "rect": Object {
-           "height": 80,
-           "left": 140,
-           "top": 12,
-           "width": 154,
+           "height": 21,
+           "left": 152,
+           "top": 13.5,
+           "width": 166,
          },
          "tabIndex": 0,
          "type": "text",
          "value": "元の入力 995",
        },
@@ -144,63 +144,63 @@
          "width": 318,
        },
      },
      Object {
        "css": Object {
-         "borderBottomWidth": "1px",
+         "borderBottomWidth": "0px",
          "borderLeftWidth": "0px",
          "borderRadius": "0px",
          "borderRightWidth": "0px",
          "borderTopWidth": "0px",
          "boxSizing": "border-box",
          "contain": "none",
          "direction": "ltr",
-         "font": "36px / 57.600002px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-         "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-         "fontSize": "36px",
-         "lineHeight": "57.600002px",
+         "font": "32px -webkit-standard",
+         "fontFamily": "-webkit-standard",
+         "fontSize": "32px",
+         "lineHeight": "normal",
          "overflowX": "auto",
          "overflowY": "auto",
-         "paddingBottom": "12px",
-         "paddingLeft": "24px",
-         "paddingRight": "24px",
-         "paddingTop": "12px",
+         "paddingBottom": "0px",
+         "paddingLeft": "0px",
+         "paddingRight": "0px",
+         "paddingTop": "0px",
          "scrollBehavior": "auto",
          "scrollPaddingBottom": "auto",
          "scrollPaddingTop": "auto",
        },
        "index": 996,
        "input": Object {
          "css": Object {
-           "borderBottomWidth": "1px",
-           "borderLeftWidth": "1px",
-           "borderRadius": "12px",
-           "borderRightWidth": "1px",
-           "borderTopWidth": "1px",
-           "boxSizing": "border-box",
+           "borderBottomWidth": "2px",
+           "borderLeftWidth": "2px",
+           "borderRadius": "0px",
+           "borderRightWidth": "2px",
+           "borderTopWidth": "2px",
+           "boxSizing": "content-box",
            "contain": "none",
            "direction": "ltr",
-           "font": "36px / 54px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-           "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-           "fontSize": "36px",
-           "lineHeight": "54px",
+           "font": "11px system-ui",
+           "fontFamily": "system-ui",
+           "fontSize": "11px",
+           "lineHeight": "normal",
            "overflowX": "visible",
            "overflowY": "visible",
-           "paddingBottom": "12px",
-           "paddingLeft": "24px",
-           "paddingRight": "24px",
-           "paddingTop": "12px",
+           "paddingBottom": "2px",
+           "paddingLeft": "5px",
+           "paddingRight": "5px",
+           "paddingTop": "2px",
            "scrollBehavior": "auto",
            "scrollPaddingBottom": "auto",
            "scrollPaddingTop": "auto",
          },
          "label": "再検証入力 996",
          "rect": Object {
-           "height": 80,
-           "left": 140,
-           "top": 12,
-           "width": 154,
+           "height": 21,
+           "left": 152,
+           "top": 13.5,
+           "width": 166,
          },
          "tabIndex": 0,
          "type": "text",
          "value": "元の入力 996",
        },
@@ -211,63 +211,63 @@
          "width": 318,
        },
      },
      Object {
        "css": Object {
-         "borderBottomWidth": "1px",
+         "borderBottomWidth": "0px",
          "borderLeftWidth": "0px",
          "borderRadius": "0px",
          "borderRightWidth": "0px",
          "borderTopWidth": "0px",
          "boxSizing": "border-box",
          "contain": "none",
          "direction": "ltr",
-         "font": "36px / 57.600002px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-         "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-         "fontSize": "36px",
-         "lineHeight": "57.600002px",
+         "font": "32px -webkit-standard",
+         "fontFamily": "-webkit-standard",
+         "fontSize": "32px",
+         "lineHeight": "normal",
          "overflowX": "auto",
          "overflowY": "auto",
-         "paddingBottom": "12px",
-         "paddingLeft": "24px",
-         "paddingRight": "24px",
-         "paddingTop": "12px",
+         "paddingBottom": "0px",
+         "paddingLeft": "0px",
+         "paddingRight": "0px",
+         "paddingTop": "0px",
          "scrollBehavior": "auto",
          "scrollPaddingBottom": "auto",
          "scrollPaddingTop": "auto",
        },
        "index": 997,
        "input": Object {
          "css": Object {
-           "borderBottomWidth": "1px",
-           "borderLeftWidth": "1px",
-           "borderRadius": "12px",
-           "borderRightWidth": "1px",
-           "borderTopWidth": "1px",
-           "boxSizing": "border-box",
+           "borderBottomWidth": "2px",
+           "borderLeftWidth": "2px",
+           "borderRadius": "0px",
+           "borderRightWidth": "2px",
+           "borderTopWidth": "2px",
+           "boxSizing": "content-box",
            "contain": "none",
            "direction": "ltr",
-           "font": "36px / 54px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-           "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-           "fontSize": "36px",
-           "lineHeight": "54px",
+           "font": "11px system-ui",
+           "fontFamily": "system-ui",
+           "fontSize": "11px",
+           "lineHeight": "normal",
            "overflowX": "visible",
            "overflowY": "visible",
-           "paddingBottom": "12px",
-           "paddingLeft": "24px",
-           "paddingRight": "24px",
-           "paddingTop": "12px",
+           "paddingBottom": "2px",
+           "paddingLeft": "5px",
+           "paddingRight": "5px",
+           "paddingTop": "2px",
            "scrollBehavior": "auto",
            "scrollPaddingBottom": "auto",
            "scrollPaddingTop": "auto",
          },
          "label": "再検証入力 997",
          "rect": Object {
-           "height": 80,
-           "left": 140,
-           "top": 12,
-           "width": 154,
+           "height": 21,
+           "left": 152,
+           "top": 13.5,
+           "width": 166,
          },
          "tabIndex": 0,
          "type": "text",
          "value": "元の入力 997",
        },
@@ -278,63 +278,63 @@
          "width": 318,
        },
      },
      Object {
        "css": Object {
-         "borderBottomWidth": "1px",
+         "borderBottomWidth": "0px",
          "borderLeftWidth": "0px",
          "borderRadius": "0px",
          "borderRightWidth": "0px",
          "borderTopWidth": "0px",
          "boxSizing": "border-box",
          "contain": "none",
          "direction": "ltr",
-         "font": "36px / 57.600002px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-         "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-         "fontSize": "36px",
-         "lineHeight": "57.600002px",
+         "font": "32px -webkit-standard",
+         "fontFamily": "-webkit-standard",
+         "fontSize": "32px",
+         "lineHeight": "normal",
          "overflowX": "auto",
          "overflowY": "auto",
-         "paddingBottom": "12px",
-         "paddingLeft": "24px",
-         "paddingRight": "24px",
-         "paddingTop": "12px",
+         "paddingBottom": "0px",
+         "paddingLeft": "0px",
+         "paddingRight": "0px",
+         "paddingTop": "0px",
          "scrollBehavior": "auto",
          "scrollPaddingBottom": "auto",
          "scrollPaddingTop": "auto",
        },
        "index": 998,
        "input": Object {
          "css": Object {
-           "borderBottomWidth": "1px",
-           "borderLeftWidth": "1px",
-           "borderRadius": "12px",
-           "borderRightWidth": "1px",
-           "borderTopWidth": "1px",
-           "boxSizing": "border-box",
+           "borderBottomWidth": "2px",
+           "borderLeftWidth": "2px",
+           "borderRadius": "0px",
+           "borderRightWidth": "2px",
+           "borderTopWidth": "2px",
+           "boxSizing": "content-box",
            "contain": "none",
            "direction": "ltr",
-           "font": "36px / 54px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-           "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-           "fontSize": "36px",
-           "lineHeight": "54px",
+           "font": "11px system-ui",
+           "fontFamily": "system-ui",
+           "fontSize": "11px",
+           "lineHeight": "normal",
            "overflowX": "visible",
            "overflowY": "visible",
-           "paddingBottom": "12px",
-           "paddingLeft": "24px",
-           "paddingRight": "24px",
-           "paddingTop": "12px",
+           "paddingBottom": "2px",
+           "paddingLeft": "5px",
+           "paddingRight": "5px",
+           "paddingTop": "2px",
            "scrollBehavior": "auto",
            "scrollPaddingBottom": "auto",
            "scrollPaddingTop": "auto",
          },
          "label": "再検証入力 998",
          "rect": Object {
-           "height": 80,
-           "left": 140,
-           "top": 12,
-           "width": 154,
+           "height": 21,
+           "left": 152,
+           "top": 13.5,
+           "width": 166,
          },
          "tabIndex": 0,
          "type": "text",
          "value": "元の入力 998",
        },
@@ -345,63 +345,63 @@
          "width": 318,
        },
      },
      Object {
        "css": Object {
-         "borderBottomWidth": "1px",
+         "borderBottomWidth": "0px",
          "borderLeftWidth": "0px",
          "borderRadius": "0px",
          "borderRightWidth": "0px",
          "borderTopWidth": "0px",
          "boxSizing": "border-box",
          "contain": "none",
          "direction": "ltr",
-         "font": "36px / 57.600002px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-         "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-         "fontSize": "36px",
-         "lineHeight": "57.600002px",
+         "font": "32px -webkit-standard",
+         "fontFamily": "-webkit-standard",
+         "fontSize": "32px",
+         "lineHeight": "normal",
          "overflowX": "auto",
          "overflowY": "auto",
-         "paddingBottom": "12px",
-         "paddingLeft": "24px",
-         "paddingRight": "24px",
-         "paddingTop": "12px",
+         "paddingBottom": "0px",
+         "paddingLeft": "0px",
+         "paddingRight": "0px",
+         "paddingTop": "0px",
          "scrollBehavior": "auto",
          "scrollPaddingBottom": "auto",
          "scrollPaddingTop": "auto",
        },
        "index": 999,
        "input": Object {
          "css": Object {
-           "borderBottomWidth": "1px",
-           "borderLeftWidth": "1px",
-           "borderRadius": "12px",
-           "borderRightWidth": "1px",
-           "borderTopWidth": "1px",
-           "boxSizing": "border-box",
+           "borderBottomWidth": "2px",
+           "borderLeftWidth": "2px",
+           "borderRadius": "0px",
+           "borderRightWidth": "2px",
+           "borderTopWidth": "2px",
+           "boxSizing": "content-box",
            "contain": "none",
            "direction": "ltr",
-           "font": "36px / 54px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-           "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-           "fontSize": "36px",
-           "lineHeight": "54px",
+           "font": "11px system-ui",
+           "fontFamily": "system-ui",
+           "fontSize": "11px",
+           "lineHeight": "normal",
            "overflowX": "visible",
            "overflowY": "visible",
-           "paddingBottom": "12px",
-           "paddingLeft": "24px",
-           "paddingRight": "24px",
-           "paddingTop": "12px",
+           "paddingBottom": "2px",
+           "paddingLeft": "5px",
+           "paddingRight": "5px",
+           "paddingTop": "2px",
            "scrollBehavior": "auto",
            "scrollPaddingBottom": "auto",
            "scrollPaddingTop": "auto",
          },
          "label": "再検証入力 999",
          "rect": Object {
-           "height": 80,
-           "left": 140,
-           "top": 12,
-           "width": 154,
+           "height": 21,
+           "left": 152,
+           "top": 13.5,
+           "width": 166,
          },
          "tabIndex": 0,
          "type": "text",
          "value": "元の入力 999",
        },
@@ -413,43 +413,43 @@
        },
      },
    ],
    "spacerStyle": "height: 160000px;",
    "viewport": Object {
-     "bottom": 590.375,
-     "clientHeight": 358,
-     "clientLeft": 1,
-     "clientTop": 1,
-     "clientWidth": 318,
+     "bottom": 781.75,
+     "clientHeight": 360,
+     "clientLeft": 0,
+     "clientTop": 0,
+     "clientWidth": 304,
      "css": Object {
-       "borderBottomWidth": "1px",
-       "borderLeftWidth": "1px",
-       "borderRadius": "12px",
-       "borderRightWidth": "1px",
-       "borderTopWidth": "1px",
+       "borderBottomWidth": "0px",
+       "borderLeftWidth": "0px",
+       "borderRadius": "0px",
+       "borderRightWidth": "0px",
+       "borderTopWidth": "0px",
        "boxSizing": "border-box",
        "contain": "strict",
        "direction": "ltr",
-       "font": "36px / 57.600002px system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-       "fontFamily": "system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
-       "fontSize": "36px",
-       "lineHeight": "57.600002px",
+       "font": "32px -webkit-standard",
+       "fontFamily": "-webkit-standard",
+       "fontSize": "32px",
+       "lineHeight": "normal",
        "overflowX": "auto",
        "overflowY": "auto",
        "paddingBottom": "0px",
        "paddingLeft": "0px",
        "paddingRight": "0px",
        "paddingTop": "0px",
        "scrollBehavior": "auto",
-       "scrollPaddingBottom": "6px",
-       "scrollPaddingTop": "6px",
+       "scrollPaddingBottom": "auto",
+       "scrollPaddingTop": "auto",
      },
      "height": 360,
-     "left": 0,
-     "right": 320,
+     "left": 8,
+     "right": 312,
      "scrollHeight": 160000,
      "scrollWidth": 318,
-     "top": 230.375,
-     "width": 320,
+     "top": 421.75,
+     "width": 304,
    },
    "windowStyle": "padding-block-start: 159040px;",
  }
```

```
Error: CSS override browser errors

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "error: Failed to load resource: Could not connect to the server.",
+ ]
```

# Page snapshot

```yaml
- main [ref=e3]:
  - heading "静的警告の実行時検証" [level=1] [ref=e4]
  - generic [ref=e5]:
    - text: 表示設定
    - combobox "表示設定" [ref=e6]:
      - option "guided" [selected]
      - option "dense"
  - button "基準となる操作" [ref=e7]
  - region "検証する部品" [ref=e8]:
    - generic "再検証する編集一覧" [ref=e10]:
      - list "再検証する編集一覧" [ref=e11]:
        - generic [ref=e13]:
          - listitem [ref=e15]:
            - generic [ref=e16]:
              - generic [ref=e17]: 申請 994 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前
              - textbox "再検証入力 994" [ref=e18]: 元の入力 994
          - listitem [ref=e20]:
            - generic [ref=e21]:
              - generic [ref=e22]: 申請 995 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前
              - textbox "再検証入力 995" [ref=e23]: 元の入力 995
          - listitem [ref=e25]:
            - generic [ref=e26]:
              - generic [ref=e27]: 申請 996 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前
              - textbox "再検証入力 996" [ref=e28]: 元の入力 996
          - listitem [ref=e30]:
            - generic [ref=e31]:
              - generic [ref=e32]: 申請 997 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前
              - textbox "再検証入力 997" [ref=e33]: 元の入力 997
          - listitem [ref=e35]:
            - generic [ref=e36]:
              - generic [ref=e37]: 申請 998 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前
              - textbox "再検証入力 998" [ref=e38]: 元の入力 998
          - listitem [ref=e40]:
            - generic [ref=e41]:
              - generic [ref=e42]: 申請 999 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前
              - textbox "再検証入力 999" [ref=e43]: 元の入力 999
    - button "一覧の後" [ref=e45]
```

# Test source

```ts
  1  | import {attachPageLifecycle} from './runtime-lifecycle';
  2  | import {test as base,expect,type Page,type Locator} from '@playwright/test';
  3  | export {expect};
> 4  | export const test=base.extend<{runtimeErrors:string[];lifecycle:ReturnType<typeof attachPageLifecycle>}>({lifecycle:[async({page,context,browser},use,testInfo)=>{const journal=attachPageLifecycle(page,context,context.browser()??browser);try{await use(journal);}finally{for(const error of testInfo.errors)journal.recordError('primary',error);journal.setPhase('diagnostic');try{await journal.flush((name,options)=>testInfo.attach(name,options));}finally{journal.dispose();}}},{auto:true}],runtimeErrors:[async({page},use)=>{const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));page.on('console',message=>{if(message.type()==='error'||message.type()==='warning')errors.push(message.type()+': '+message.text());});await use(errors);expect(errors,'CSS override browser errors').toEqual([]);},{auto:true}]});
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ^ Error: CSS override browser errors
  5  | export const contexts=[
  6  |  {name:'A',profile:'guided',width:1280,font:'100%',dir:'ltr',motion:'no-preference'},
  7  |  {name:'B',profile:'dense',width:320,font:'200%',dir:'rtl',motion:'reduce'},
  8  |  {name:'C',profile:'guided',width:320,font:'200%',dir:'ltr',motion:'no-preference'},
  9  |  {name:'D',profile:'dense',width:1280,font:'100%',dir:'rtl',motion:'reduce'},
  10 | ] as const;
  11 | export type Context=typeof contexts[number];
  12 | export async function settle(page:Page){await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));}
  13 | export async function environment(page:Page,context:Context){
  14 |  await page.setViewportSize({width:context.width,height:1000});await page.emulateMedia({reducedMotion:context.motion});
  15 |  await page.evaluate(c=>{document.documentElement.style.fontSize=c.font;document.documentElement.dir=c.dir;const main=document.querySelector<HTMLElement>('main')!;main.setAttribute('data-ui-profile',c.profile);main.style.padding='0';},context);await settle(page);
  16 | }
  17 | export async function ready(page:Page,context:Context){await page.goto('/catalog/static-runtime');await expect.poll(()=>page.evaluate(()=>typeof(window as any).__runtime?.create)).toBe('function');await environment(page,context);}
  18 | export const host=(page:Page,id:number)=>page.locator(`[data-runtime-id="${id}"]`);
  19 | export async function create(page:Page,name:string,inputs:Record<string,unknown>,projection?:string){return page.evaluate(({name,inputs,projection})=>(window as any).__runtime.create(name,inputs,projection),{name,inputs,projection});}
  20 | export async function update(page:Page,id:number,inputs:Record<string,unknown>){await page.evaluate(({id,inputs})=>(window as any).__runtime.update(id,inputs),{id,inputs});await settle(page);}
  21 | export async function set(target:Locator,property:string,value:string,priority='important'){await target.evaluate((el,{property,value,priority})=>(el as HTMLElement).style.setProperty(property,value,priority),{property,value,priority});}
  22 | export async function clear(target:Locator,property:string){await target.evaluate((el,p)=>(el as HTMLElement).style.removeProperty(p),property);}
  23 | export async function record(name:string,data:unknown){await test.info().attach(name,{body:JSON.stringify(data,null,2),contentType:'application/json'});}
  24 | export async function destroy(page:Page,id:number){const before=await page.evaluate(id=>{const runtime=(window as any).__runtime,snapshot=structuredClone(runtime.inspect(id));runtime.destroy(id);return snapshot;},id);expect(before.errors).toEqual([]);await settle(page);await expect(host(page,id)).toHaveCount(0);const after=await page.evaluate(id=>(window as any).__runtime.inspect(id),id);expect(after.errors).toEqual([]);expect(after.events).toEqual(before.events);}
  25 | export async function hiddenReveal(page:Page,node:Locator){await node.evaluate(el=>(el as HTMLElement).hidden=true);await expect(node).toBeHidden();await node.evaluate(el=>(el as HTMLElement).hidden=false);await expect(node).toBeVisible();await settle(page);}
  26 | 
```