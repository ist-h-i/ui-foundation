"""Read the completed release gates; never turn an incomplete run into a pass."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import socket
import subprocess
import io
from browser_run_proof import verify_release_browsers

OUTPUT_NAMES = ['normal-v4-summary.json', 'final-scope-bridge-v2.json']
NATIVE_CHANGES = ['docs/ui-warning-reviews.json', 'scripts/test-svg-paint.mjs',
                  'scripts/verification/prepare-svg-consumer.mjs',
                  'tests/ui/static-runtime-reassessment-layout.spec.ts',
                  'tests/verification-tools/portable.test.mjs']
RUNTIME_CHANGES = ['docs/ui-warning-reviews.json', 'scripts/test-svg-paint.mjs',
                   'scripts/verification/prepare-svg-consumer.mjs', 'tests/ui/post-burst-paint.ts',
                   'tests/ui/static-runtime-p2-tables.spec.ts',
                   'tests/ui/static-runtime-reassessment-layout.spec.ts',
                   'tests/ui/static-runtime-reassessment-navigation.spec.ts',
                   'tests/ui/virtual-fast-tab.spec.ts', 'tests/verification-tools/portable.test.mjs']


def verify_committed_inputs(root, head, inputs):
    """Bind the entire candidate inventory to committed Git blobs, not just root bytes."""
    assert re.fullmatch(r'[0-9a-f]{40}', head)
    names = sorted(inputs)
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts
               and '\n' not in name and '\r' not in name for name in names)
    query = ''.join(f'{head}:{name}\n' for name in names).encode()
    result = subprocess.run(['git', 'cat-file', '--batch'], cwd=root, input=query,
                            stdout=subprocess.PIPE, check=True)
    stream = io.BytesIO(result.stdout)
    for name in names:
        header = stream.readline().split()
        assert len(header) == 3 and header[1] == b'blob', (name, header)
        size = int(header[2])
        data = stream.read(size)
        assert len(data) == size and stream.read(1) == b'\n'
        assert hashlib.sha256(data).hexdigest() == inputs[name], name
    assert stream.read() == b''


def validate_release(p, *, stamp):
    """Read-only gates. A running, failed, incomplete or mismatched v4 raises."""
    root = p.parents[2]
    sha = lambda data: hashlib.sha256(data).hexdigest()
    read = lambda name: json.loads((p / name).read_text())
    candidate = read('candidate-manifest-v8.json')
    inputs = candidate['inputs']
    assert candidate['all_inputs_committed'] is True and candidate['input_count'] == len(inputs) == 718
    verify_committed_inputs(root, candidate['head_sha'], inputs)
    clean = read('clean-checkout-v4.json')
    capture = read('npm-test-clean-v4-receipt.json')
    assert clean['status'] == 'PASSED' and clean['npm_test_exit_code'] == 0
    assert clean['archive_only'] and not clean['historical_work_directories_copied']
    assert not clean['node_modules_symlink'] and clean['committed_source_inputs_verified'] == len(inputs) == 718
    assert clean['head'] == candidate['head_sha'] and clean['source_inputs'] == inputs
    assert clean['source_changes'] == [] and capture['exit_code'] == 0
    assert capture['source_sha256'] == capture['source_after_sha256'] == inputs
    assert capture['source_changed_during_run'] == capture['bundle_changed_during_run'] == []
    assert all(sha((root / name).read_bytes()) == digest for name, digest in inputs.items())
    browser_proofs = verify_release_browsers(p)
    log_bytes = (p / 'npm-test-clean-v4.log').read_bytes()
    assert sha(log_bytes) == capture['log_sha256']
    log = log_bytes.decode()
    assert 'UI warning classification: 122/122; 0 source errors; 0 unclassified; 0 stale.' in log

    def section(name, following):
        begin = log.index('> ui-foundation@0.0.0 ' + name + '\n')
        end = log.index('> ui-foundation@0.0.0 ' + following + '\n', begin)
        return log[begin:end]

    units = {}
    sequence = [('test:config', 'test:generation', 72), ('test:generation', 'test:static', 23),
                ('test:static', 'test:model', 518), ('test:model', 'test:ui', 247)]
    for name, following, expected in sequence:
        part = section(name, following)
        count = lambda key: int(re.findall(r'^[ℹ#] ' + key + r' (\d+)\s*$', part, re.M)[-1])
        data = {key: count(key) for key in ['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo']}
        assert data['tests'] == data['pass'] == expected, (name, data)
        assert all(data[key] == 0 for key in ['fail', 'cancelled', 'skipped', 'todo']), (name, data)
        units[name] = data

    ui_log = section('test:ui', 'test:svg-paint')
    assert re.search(r'^Running 1903 tests using 2 workers\s*$', ui_log, re.M)
    rows = re.findall(r'^\s+✓\s+(\d+) \[chromium\] › (.+)$', ui_log, re.M)
    assert len(rows) == len({int(row[0]) for row in rows}) == 1903
    assert {int(row[0]) for row in rows} == set(range(1, 1904))
    assert re.search(r'^\s+1903 passed \([^)]+\)\s*$', ui_log, re.M)
    assert not re.search(r'^\s+[✘×]|^\s+\d+ (failed|skipped|flaky)', ui_log, re.M)

    checkout = Path(clean['checkout'])
    assert checkout.name.startswith('ui-foundation-release-v4-')
    assert not (checkout / 'node_modules').is_symlink()
    svg_dir = checkout / 'test-results/svg-paint'
    svg_execution = json.loads((svg_dir / 'execution.json').read_text())
    svg = json.loads((svg_dir / 'candidate-paint-native.json').read_text())
    svg_inputs = json.loads((svg_dir / 'source-input.json').read_text())
    assert svg_execution['successful'] and svg_execution['sourceUnchanged'] and svg_execution['ownServerClosed']
    assert len(svg_execution['steps']) == 6 and all(step['code'] == 0 for step in svg_execution['steps'])
    assert svg_execution['nativeContract']['requiredScenarios'] == svg_execution['nativeContract']['recordedScenarios'] == 34
    assert svg_execution['nativeContract']['allSuccessful'] and svg['allExpected']
    assert len(svg['rows']) == 34 and all(row['passed'] is True and row['errors'] == [] for row in svg['rows'])
    scenario_keys = ['profile', 'width', 'direction', 'locale', 'precision', 'data']
    assert len({json.dumps([row[key] for key in scenario_keys], sort_keys=True) for row in svg['rows']}) == 34
    assert len(svg_inputs['sourceFiles']) == 229 and len(svg_inputs['installed']) == 50
    for file in svg_inputs['sourceFiles']:
        assert sha((checkout / file['path']).read_bytes()) == file['sha256']
    with socket.socket() as probe:
        probe.settimeout(1)
        assert probe.connect_ex(('127.0.0.1', clean['fixture_port'])) != 0, 'Normal UI listener remains open.'

    bundle = {str(file.relative_to(checkout)): sha(file.read_bytes())
              for file in sorted((checkout / 'dist/fixture-app').rglob('*')) if file.is_file()}
    native = read('cross-browser-radio-v12-receipt.json')
    runtime = read('cross-browser-runtime-v9-receipt.json')
    assert len(bundle) == 309
    assert bundle == capture['bundle_sha256'] == capture['bundle_after_sha256']
    assert bundle == native['bundle_sha256'] == native['bundle_after_sha256']
    assert bundle == runtime['bundle_sha256'] == runtime['bundle_after_sha256']
    assert bundle['dist/fixture-app/main.js'] == clean['fixture_bundle_sha256']
    for receipt in [native, runtime]:
        assert receipt['exit_code'] == 0
        assert receipt['source_changed_during_run'] == receipt['bundle_changed_during_run'] == []
        assert receipt['source_sha256'] == receipt['source_after_sha256']

    verification = read('verification-tools-final-v2-receipt.json')
    assert verification['exit_code'] == 0
    assert verification['source_sha256'] == verification['source_after_sha256'] == inputs
    assert verification['source_changed_during_run'] == verification['bundle_changed_during_run'] == []
    verification_log = (p / 'verification-tools-final-v2.log').read_bytes()
    assert sha(verification_log) == verification['log_sha256']
    verification_counts = {key: int(re.findall(r'^[ℹ#] ' + key + r' (\d+)\s*$', verification_log.decode(), re.M)[-1])
                           for key in ['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo']}
    assert verification_counts == {'tests': 65, 'pass': 65, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}

    summary = {
        'schema_version': 1, 'created_utc': stamp, 'status': 'PASSED',
        'scope': 'Actual complete npm test from a committed git archive with a private copy of pinned dependencies. No main-checkout node_modules symlink; no historical working directories. Finite tested behavior only.',
        'implementation_head': clean['head'], 'command': clean['command'],
        'candidate_manifest': 'candidate-manifest-v8.json', 'candidate_manifest_sha256': sha((p / 'candidate-manifest-v8.json').read_bytes()),
        'committed_git_blob_inputs_verified': len(inputs),
        'started_at': clean['started_at'], 'completed_at': clean['completed_at'],
        'source_inputs': len(inputs), 'source_changes': [], 'root_source_changes': [], 'root_bundle_changes': [],
        'dependencies': clean['dev_dependencies'], 'warning_gate': {'reviewed': 122, 'total': 122, 'source_errors': 0, 'unclassified': 0, 'stale': 0},
        'typecheck': {'tools': 'PASSED', 'angular': 'PASSED', 'ui_media': 'PASSED', 'ui_runtime': 'PASSED'},
        'unit_suites': units,
        'normal_ui': {'engine': 'chromium', 'tests': 1903, 'passed': 1903, 'failed': 0, 'skipped': 0, 'flaky': 0, 'retries': 0, 'workers': 2, 'recorded_success_rows': len(rows), 'owned_listener_closed': True},
        'svg_public_consumer': {'tests': 34, 'passed': 34, 'distinct_scenarios': 34, 'runtime_errors': 0, 'canonical_steps': 6, 'all_steps_exit_zero': True, 'source_unchanged': True, 'owned_server_closed': True, 'inventoried_files': 229, 'pinned_dependencies': 50,
            'execution_sha256': sha((svg_dir / 'execution.json').read_bytes()), 'native_result_sha256': sha((svg_dir / 'candidate-paint-native.json').read_bytes()), 'source_inventory_sha256': sha((svg_dir / 'source-input.json').read_bytes())},
        'verification_tools': {'command': ['npm', 'run', 'test:verification'], 'tests': 65, 'passed': 65, 'failed': 0, 'receipt_sha256': sha((p / 'verification-tools-final-v2-receipt.json').read_bytes())},
        'normal_log_sha256': sha(log_bytes), 'capture_receipt_sha256': sha((p / 'npm-test-clean-v4-receipt.json').read_bytes()),
        'clean_receipt_sha256': sha((p / 'clean-checkout-v4.json').read_bytes()),
        'compiled_files': len(bundle), 'fixture_main_sha256': bundle['dist/fixture-app/main.js'],
        'limits': ['No claim of universal runtime dataflow or CSS cascade completeness.', 'No claim of complete visual quality, real IME, mobile, assistive technology or physical Safari acceptance.', 'Historical failed and interrupted runs remain separate records.'],
    }

    native_changes = [name for name in sorted(native['source_sha256'].keys() | inputs.keys()) if native['source_sha256'].get(name) != inputs.get(name)]
    assert native_changes == NATIVE_CHANGES
    assert candidate['source_changes_after_native180'] == [
        {'file': name, 'before': native['source_sha256'].get(name), 'after': inputs.get(name)}
        for name in native_changes]
    runtime_changes = [name for name in sorted(runtime['source_sha256'].keys() | inputs.keys()) if runtime['source_sha256'].get(name) != inputs.get(name)]
    assert runtime_changes == RUNTIME_CHANGES
    runtime_paths = [name for name in inputs if name.startswith('tests/cross-browser/')]
    runtime_paths += ['playwright.cross-browser.config.ts', 'scripts/run-cross-browser.mjs', 'package.json', 'package-lock.json',
                      'tests/ui/code-editor-native.spec.ts', 'tests/ui/code-editor-native.ts', 'tests/ui/css-override-test.ts',
                      'tests/ui/runtime-lifecycle.spec.ts', 'tests/ui/runtime-lifecycle.ts']
    assert all(runtime['source_sha256'][name] == inputs[name] for name in runtime_paths)
    bridge = {
        'schema_version': 1, 'created_utc': stamp,
        'scope': 'Explicit source and all-asset byte comparison. This reuses earlier bounded executions and does not claim they were rerun at the publication head.',
        'final_source_head': candidate['head_sha'], 'final_source_inputs': len(inputs),
        'normal_clean_execution_head': clean['head'], 'normal_source_inputs_identical': True,
        'candidate_manifest': 'candidate-manifest-v8.json', 'candidate_manifest_sha256': sha((p / 'candidate-manifest-v8.json').read_bytes()),
        'committed_git_blob_inputs_verified': len(inputs),
        'native180': {'execution_head': '469e142750a4edb5fdb995e3c2542d481774da50', 'source_inputs': len(native['source_sha256']), 'guarded_build': 'PASSED', 'native': f"{browser_proofs['native180']['passed']}/{browser_proofs['native180']['tests']} PASSED", 'validated_run': browser_proofs['native180'], 'source_changes_to_final': native_changes, 'application_fixture_and_cross_browser_driver_unchanged': True, 'receipt_sha256': sha((p / 'cross-browser-radio-v12-receipt.json').read_bytes())},
        'runtime48': {'execution_head': '20761f986c6480546ddf405235b1ddf4faa8b405', 'source_inputs': len(runtime['source_sha256']), 'build_in_that_execution': 'NOT_RUN; diagnostic build preceded it', 'native': f"{browser_proofs['runtime48']['passed']}/{browser_proofs['runtime48']['tests']} PASSED", 'validated_run': browser_proofs['runtime48'], 'source_changes_to_final': runtime_changes, 'direct_drivers_and_helpers_unchanged': {name: inputs[name] for name in sorted(runtime_paths)}, 'receipt_sha256': sha((p / 'cross-browser-runtime-v9-receipt.json').read_bytes())},
        'compiled_bundle': {'files': len(bundle), 'all_309_files_byte_identical_across_runtime48_native180_final_normal': True, 'main_sha256': bundle['dist/fixture-app/main.js'], 'files_sha256': bundle},
        'limits': ['Headless three-engine executions are finite tests, not universal runtime or physical browser acceptance.', 'Post-burst DOM controls separately exercise waiting and rejection; all 54 observations in native180 were initially ready.'],
    }
    return summary, bridge


def main():
    p = Path(__file__).resolve().parent
    assert not any((p / name).exists() for name in OUTPUT_NAMES), 'Use a new version; do not replace sealed results.'
    stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    summary, bridge = validate_release(p, stamp=stamp)
    for name, value in zip(OUTPUT_NAMES, [summary, bridge]):
        with (p / name).open('x') as output:
            output.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': summary['status'], 'head': summary['implementation_head'],
        'units': {name: data['pass'] for name, data in summary['unit_suites'].items()},
        'ui': 1903, 'svg': 34, 'verification_tools': 65, 'compiled_assets_equal': 309}))


if __name__ == '__main__':
    main()
