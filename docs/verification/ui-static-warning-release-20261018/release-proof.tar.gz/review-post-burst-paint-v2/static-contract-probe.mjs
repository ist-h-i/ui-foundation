import ts from 'typescript';
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import vm from 'node:vm';
import path from 'node:path';

const root=process.cwd(),out=path.dirname(new URL(import.meta.url).pathname),frozen=path.join(out,'frozen');
const base='c19aa1137a1ca281e433d4d96b56f27e45099cd8',correctionBase='2b46a4487a08e069bcae74fd98f62f4899789fa6';
const source=name=>readFileSync(path.join(frozen,name),'utf8');
const fromGit=(sha,name)=>execFileSync('git',['show',sha+':'+name],{encoding:'utf8'});
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const parse=(name,text)=>ts.createSourceFile(name,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
const oldSource=parse('baseline.ts',fromGit(base,'tests/ui/virtual-fast-tab.spec.ts')),newText=source('tests/ui/virtual-fast-tab.spec.ts'),newSource=parse('current.ts',newText);
function all(node,predicate,result=[]){if(predicate(node))result.push(node);ts.forEachChild(node,child=>{all(child,predicate,result);});return result;}
const declaration=(tree,name)=>all(tree,node=>(ts.isFunctionDeclaration(node)||ts.isVariableDeclaration(node))&&node.name?.getText(tree)===name)[0];
const printer=ts.createPrinter({removeComments:true});
const print=(node,tree)=>printer.printNode(ts.EmitHint.Unspecified,node,tree);
const results={status:'PASS',base,correctionBase,sourceSha256:sha(newText),helperSha256:sha(source('tests/ui/post-burst-paint.ts'))};
results.byteIdenticalNativeHelpers=[];
for(const name of ['snapshot','tab','flush','disposeProbe','nativeScrollReference','nativeNestedSequence']){
 assert.equal(declaration(newSource,name).getText(newSource),declaration(oldSource,name).getText(oldSource),name);
 results.byteIdenticalNativeHelpers.push(name);
}
results.byteIdenticalProbeDeclarations=[];
for(const name of ['paint','read','keydown','keyup']){
 const old=all(declaration(oldSource,'installProbe'),node=>ts.isVariableDeclaration(node)&&node.name.getText(oldSource)===name)[0];
 const current=all(declaration(newSource,'installProbe'),node=>ts.isVariableDeclaration(node)&&node.name.getText(newSource)===name)[0];
 assert.equal(current.getText(newSource),old.getText(oldSource),name);
 results.byteIdenticalProbeDeclarations.push(name);
}
const testStatements=tree=>tree.statements.filter(node=>all(node,child=>ts.isCallExpression(child)&&ts.isIdentifier(child.expression)&&child.expression.text==='test').length);
function withoutNewIdentityArgument(node){
 const transformed=ts.transform(node,[context=>root=>{
  const visit=child=>ts.isCallExpression(child)&&ts.isIdentifier(child.expression)&&child.expression.text==='geometry'&&child.arguments.length===5
   ?ts.factory.updateCallExpression(child,child.expression,child.typeArguments,child.arguments.slice(0,4))
   :ts.visitEachChild(child,visit,context);
  return ts.visitNode(root,visit);
 }]);
 return transformed;
}
const oldTests=testStatements(oldSource),newTests=testStatements(newSource);
results.originalApplicationDeclarations=[];
for(const old of oldTests){
 const transformedMatches=newTests.filter(current=>{const transformed=withoutNewIdentityArgument(current);try{return print(transformed.transformed[0],newSource)===print(old,oldSource);}finally{transformed.dispose();}});
 assert.equal(transformedMatches.length,1,'original test declaration preserved');
 results.originalApplicationDeclarations.push({baselineLine:oldSource.getLineAndCharacterOfPosition(old.getStart(oldSource)).line+1,currentLine:newSource.getLineAndCharacterOfPosition(transformedMatches[0].getStart(newSource)).line+1});
}
assert.equal(oldTests.length,4);
const geometrySuffix=(tree)=>declaration(tree,'geometry').getText(tree).slice(declaration(tree,'geometry').getText(tree).indexOf('expect(metric.range.start'));
assert.equal(geometrySuffix(newSource),geometrySuffix(oldSource));results.exactGeometryAssertionSuffix='BYTE_IDENTICAL';
const matrix=declaration(newSource,'rows');assert(matrix);
results.sameInstanceMixedNativeKeys={contexts:4,rows:64,list:4*(1+64*2+1+64*2+2),table:4*(1+64*4+1+64*4+2)};
assert.equal(results.sameInstanceMixedNativeKeys.list,1040);assert.equal(results.sameInstanceMixedNativeKeys.table,2064);

function register(text,name){
 const cases=[];const test=(title,fn)=>{assert.equal(typeof title,'string');cases.push({title,body:String(fn)});};
 const missing=()=>{throw Error('unexpected top-level execution');};
 const contexts=[{name:'A'},{name:'B'},{name:'C'},{name:'D'}];
 const imports={'./css-override-test':{test,expect:missing,contexts},'./runtime-lifecycle':{},'./post-burst-paint':{}};
 const code=ts.transpileModule(text,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 vm.runInNewContext(code,{exports:{},require:id=>{assert(id in imports,id);return imports[id];}},{filename:name});
 return cases;
}
const suite=['virtual-radio.spec.ts','virtual-sparse-tab.spec.ts','virtual-fast-tab.spec.ts'];
results.expandedRegistrations={};const oldTitles=[],newTitles=[];
for(const file of suite){
 const name='tests/ui/'+file,before=fromGit(base,name),current=file==='virtual-fast-tab.spec.ts'?newText:readFileSync(name,'utf8');
 if(file!=='virtual-fast-tab.spec.ts')assert.equal(current,before,'other suite source untouched: '+file);
 const oldCases=register(before,name),newCases=register(current,name);
 results.expandedRegistrations[file]={base:oldCases.length,current:newCases.length,currentSha256:sha(current)};
 oldTitles.push(...oldCases.map(test=>test.title));newTitles.push(...newCases.map(test=>test.title));
}
assert.equal(new Set(newTitles).size,newTitles.length,'unique test titles');
assert(oldTitles.every(title=>newTitles.includes(title)),'original cases retained');
results.originalPerEngineCases=oldTitles.length;results.currentPerEngineCases=newTitles.length;results.totalSupportedThreeEngineCases=newTitles.length*3;
assert.equal(oldTitles.length,40);assert.equal(newTitles.length,60);assert.equal(results.totalSupportedThreeEngineCases,180);
results.newControls=newTitles.filter(title=>!oldTitles.includes(title));assert.equal(results.newControls.length,20);assert(results.newControls.every(title=>title.startsWith('post-burst paint observer:')));
results.onlySkipFixmeCalls=all(newSource,node=>ts.isCallExpression(node)&&ts.isPropertyAccessExpression(node.expression)&&['only','skip','fixme','fail'].includes(node.expression.name.text)).map(node=>node.getText(newSource));assert.deepEqual(results.onlySkipFixmeCalls,[]);
results.imports=newSource.statements.filter(ts.isImportDeclaration).map(node=>node.moduleSpecifier.text);assert(!results.imports.some(value=>/verification|output|historical/.test(value)));

const rules=declaration(newSource,'fastTabIdentityRules').initializer;
results.identityRules=Object.fromEntries(rules.properties.map(property=>[property.name.text,property.initializer.elements.map(value=>value.text)]));
assert.deepEqual(results.identityRules,{targetAttributes:['id','data-fast-nested','data-fast-boundary','data-fast-control','role','aria-colindex','aria-posinset','aria-rowindex','data-virtual-row-key'],ancestorAttributes:['aria-posinset','aria-rowindex','data-virtual-row-key'],classTokens:['ui-virtual-row']});
const helperText=source('tests/ui/post-burst-paint.ts'),helper=parse('helper.ts',helperText);
assert.equal(helper.parseDiagnostics.length,0);assert.equal(newSource.parseDiagnostics.length,0);
results.helperForbiddenCalls=all(helper,node=>ts.isCallExpression(node)&&ts.isPropertyAccessExpression(node.expression)&&/^(focus|blur|scroll|scrollTo|scrollBy|scrollIntoView|setAttribute|removeAttribute|append|appendChild|remove|replaceWith|replaceChild|insertBefore|preventDefault|dispatchEvent)$/.test(node.expression.name.text)).map(node=>node.getText(helper));assert.deepEqual(results.helperForbiddenCalls,[]);
results.helperPropertyAssignments=all(helper,node=>ts.isBinaryExpression(node)&&node.operatorToken.kind>=ts.SyntaxKind.FirstAssignment&&node.operatorToken.kind<=ts.SyntaxKind.LastAssignment&&(ts.isPropertyAccessExpression(node.left)||ts.isElementAccessExpression(node.left))).map(node=>node.left.getText(helper));assert.deepEqual(results.helperPropertyAssignments,['window.__observePostBurstPaint']);
assert(helperText.indexOf('const initial=sample()')<helperText.indexOf('await new Promise'));results.initialSampleBeforeFirstAwait=true;
assert(helperText.includes('structuredClone(read())'));assert(helperText.includes('inspectMutations(mutations.takeRecords())'));

const oldLedger=JSON.parse(fromGit(base,'docs/ui-warning-reviews.json')),newLedger=JSON.parse(source('docs/ui-warning-reviews.json'));
const oldRefs=oldLedger.reviews.flatMap(row=>row.evidence),newRefs=newLedger.reviews.flatMap(row=>row.evidence);
results.ledger={baseRefs:oldRefs.length,currentRefs:newRefs.length,baseFiles:new Set(oldRefs.map(item=>item.file)).size,currentFiles:new Set(newRefs.map(item=>item.file)).size,changedReviews:[]};
const expected=structuredClone(oldLedger);
for(const row of expected.reviews){
 const referenced=row.evidence.filter(item=>item.file==='tests/ui/virtual-fast-tab.spec.ts');
 for(const item of referenced){item.sha256=results.sourceSha256;const current=newLedger.reviews.find(value=>value.id===row.id),direct=current.evidence.filter(value=>value.file==='tests/ui/post-burst-paint.ts');assert.equal(direct.length,1);assert.equal(direct[0].sha256,results.helperSha256);assert.equal(direct[0].anchor,'export function installPostBurstPaintObserver(){');row.evidence.push(direct[0]);results.ledger.changedReviews.push(row.id);}
}
assert.deepEqual(newLedger,expected,'ledger only two spec hashes + two direct helper references');assert.equal(results.ledger.changedReviews.length,2);
results.ledger.producerUnknown=newLedger.reviews.filter(item=>item.producer_static_status==='Unknown').length;
results.ledger.universalUnknown=newLedger.reviews.filter(item=>item.universal_runtime_status==='Unknown').length;
assert.equal(results.ledger.producerUnknown,122);assert.equal(results.ledger.universalUnknown,122);assert.equal(newRefs.length,908);assert.equal(results.ledger.currentFiles,92);
const options={noEmit:true,types:[],strict:true,target:ts.ScriptTarget.ES2022,lib:['lib.es2022.d.ts','lib.dom.d.ts'],module:ts.ModuleKind.ESNext};
const program=ts.createProgram([path.join(frozen,'tests/ui/post-burst-paint.ts')],options),diagnostics=ts.getPreEmitDiagnostics(program);
results.isolatedHelperTypecheckDiagnostics=diagnostics.map(item=>ts.flattenDiagnosticMessageText(item.messageText,' '));assert.equal(diagnostics.length,0);
writeFileSync(path.join(out,'static-contract-result.json'),JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify({status:results.status,helpers:results.byteIdenticalNativeHelpers.length,probeDeclarations:results.byteIdenticalProbeDeclarations.length,applicationDeclarations:results.originalApplicationDeclarations.length,originalPerEngineCases:oldTitles.length,newControls:results.newControls.length,currentSupportedCases:results.totalSupportedThreeEngineCases,ledger:results.ledger,isolatedTypecheckDiagnostics:diagnostics.length}));
