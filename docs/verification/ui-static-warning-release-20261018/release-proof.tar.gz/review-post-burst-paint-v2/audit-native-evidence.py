from pathlib import Path
import json, hashlib, base64, collections

out=Path(__file__).resolve().parent
p=out.parent
sha=lambda value:hashlib.sha256(value).hexdigest()
paths=['post-burst-controls-v2/results.json','post-burst-controls-v2/run-receipt.json','post-burst-controls-v2-receipt.json']
documents={name:json.loads((p/name).read_text()) for name in paths}
raw=documents[paths[0]]
run=documents[paths[1]]
receipt=documents[paths[2]]
manifest=json.loads((p/'review-post-burst-paint-v2-snapshot.json').read_text())
assert receipt['exit_code']==0
assert receipt['source_changed_during_run']==[] and receipt['bundle_changed_during_run']==[]
assert run['native']=={'code':0,'signal':None} and run['serverClosed'] is True
assert run['build'].startswith('NOT RUN')
for name in ['tests/ui/post-burst-paint.ts','tests/ui/virtual-fast-tab.spec.ts']:
 assert receipt['source_sha256'][name]==manifest['files'][name]
 assert receipt['source_after_sha256'][name]==manifest['files'][name]
assert run['explicitPlaywrightFilters']==['--grep=post-burst paint observer:']
for project in raw['config']['projects']:
 assert project['retries']==0 and project['repeatEach']==1
assert raw['stats']['expected']==60 and raw['stats']['unexpected']==0 and raw['stats']['skipped']==0 and raw['stats']['flaky']==0
assert raw['errors']==[]
registered=json.loads((out/'static-contract-result.json').read_text())['newControls']
cases=[]
def visit(suite):
 for spec in suite.get('specs',[]):
  assert spec['title'] in registered
  for test in spec['tests']:
   assert test['status']=='expected' and test['expectedStatus']=='passed'
   assert len(test['results'])==1
   result=test['results'][0]
   assert result['retry']==0 and result['status']=='passed' and not result['errors']
   matches=[attachment for attachment in result['attachments'] if attachment['name'].startswith('post-burst-paint-control-')]
   assert len(matches)==1
   attachment=matches[0]
   control=attachment['name'].removeprefix('post-burst-paint-control-')
   observation=json.loads(base64.b64decode(attachment['body']))
   expected='timeout' if control.startswith('persistent-') else 'target-changed' if control.startswith('restored-') or control in ['changed-focus','returned-focus','replaced-target','changed-identity'] else 'ready'
   assert observation['outcome']==expected
   assert observation['initial']['measurementError'] is None and observation['final']['measurementError'] is None
   assert observation['initial']['ready']==(control=='ready')
   assert observation['final']['ready']==(not control.startswith('persistent-'))
   if control=='ready':
    assert observation['attempts']==1 and observation['initial']==observation['final']
   elif control.startswith('persistent-'):
    assert observation['elapsedMs']>=observation['timeoutMs'] and observation['attempts']>1 and observation['targetIssue'] is None
   if control.startswith('restored-'):
    history=observation['producerIdentityHistory']
    assert len(history)==3 and history[0]!=history[1] and history[0]==history[2]
    assert observation['final']['sameTarget'] and observation['final']['connected']
    assert observation['final']['pinnedIdentity']==observation['initialIdentity'] and observation['final']['activeIdentity']==observation['initialIdentity']
    assert 'identity' in observation['targetIssue']
   cases.append({'engine':test['projectName'],'title':spec['title'],'control':control,'outcome':observation['outcome'],'initialReady':observation['initial']['ready'],'finalReady':observation['final']['ready'],'attempts':observation['attempts'],'elapsedMs':observation['elapsedMs'],'timeoutMs':observation['timeoutMs'],'targetIssue':observation['targetIssue'],'sameTarget':observation['final']['sameTarget'],'connected':observation['final']['connected'],'producerIdentityHistory':observation.get('producerIdentityHistory',[])})
 for child in suite.get('suites',[]):visit(child)
for suite in raw['suites']:visit(suite)
assert len(cases)==60
by_engine=collections.Counter(case['engine'] for case in cases)
assert by_engine=={'chromium':20,'firefox':20,'webkit':20}
for engine in by_engine:assert len({case['title'] for case in cases if case['engine']==engine})==20
result={'status':'PASS','scope':'Readback of main-executed native inline-DOM controls, with explicit grep; not the unfiltered supported application suite or a new build.','artifactSha256':{name:sha((p/name).read_bytes()) for name in paths},'cases':cases,'engineCounts':dict(by_engine),'stats':raw['stats'],'build':run['build'],'native':run['native'],'serverClosed':run['serverClosed'],'bundleSha256':run['bundleSha256'],'sourceInputs':len(receipt['source_sha256']),'sourceDrift':receipt['source_changed_during_run'],'bundleDrift':receipt['bundle_changed_during_run'],'command':receipt['command']}
(out/'native-control-evidence-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:result[key] for key in ['status','engineCounts','build','native','serverClosed','bundleSha256','sourceInputs','sourceDrift','bundleDrift']}))
