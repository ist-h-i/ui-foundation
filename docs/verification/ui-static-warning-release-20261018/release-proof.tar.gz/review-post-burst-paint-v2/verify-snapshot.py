from pathlib import Path
import sys,json,hashlib,tarfile,subprocess

out=Path(__file__).resolve().parent
root=Path.cwd()
p=out.parent
phase=sys.argv[1] if len(sys.argv)>1 else 'final'
sha=lambda value:hashlib.sha256(value).hexdigest()
wrapper_expected={
 'review-post-burst-paint-v2-snapshot.json':'7a178ff00dfe8732d21ec74bede5eaf84f47f71ab584b746dcd41e1b8c9a9391',
 'review-post-burst-paint-v2.tar':'8dd7807d5193cf03d969de08081baa1f7048b0dadb852d348a8949d0165ad012',
 'review-post-burst-paint-v2.patch':'77c8337846ae8ca25a0d93bebe0f90916baf1be317a22a69ee11d17a90998fa7',
}
snapshot=json.loads((p/'review-post-burst-paint-v2-snapshot.json').read_text())
wrappers={name:{'expected':expected,'actual':sha((p/name).read_bytes()),'match':sha((p/name).read_bytes())==expected} for name,expected in wrapper_expected.items()}
files=[]
with tarfile.open(p/'review-post-burst-paint-v2.tar') as archive:
 names=[member.name for member in archive.getmembers() if member.isfile()]
 extras=sorted(set(names)-set(snapshot['files']))
 for name,expected in snapshot['files'].items():
  live=sha((root/name).read_bytes())
  member=archive.extractfile(name)
  tar=sha(member.read()) if member else None
  frozen=sha((out/'frozen'/name).read_bytes())
  files.append({'path':name,'expected':expected,'live':live,'tar':tar,'frozen':frozen,'live_match':live==expected,'tar_match':tar==expected,'frozen_match':frozen==expected})
result={'phase':phase,'base':snapshot['base_sha'],'correction_base':snapshot['correction_base_sha'],'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),'file_count':len(files),'wrappers':wrappers,'tar_entry_count':len(names),'tar_duplicates':sorted({name for name in names if names.count(name)>1}),'tar_extra_files':extras,'files':files,'all_match':all(value['match'] for value in wrappers.values()) and all(value['live_match'] and value['tar_match'] and value['frozen_match'] for value in files)}
(out/(phase+'-snapshot-verification.json')).write_text(json.dumps(result,indent=2)+'\n')
assert result['all_match'] and len(files)==26 and not result['tar_duplicates']
print(json.dumps({key:result[key] for key in ['phase','head','branch','file_count','tar_entry_count','tar_duplicates','tar_extra_files','all_match']}))
