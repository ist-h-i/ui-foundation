import ts from 'typescript';
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import vm from 'node:vm';
import path from 'node:path';
import {createHash} from 'node:crypto';

// A finite algorithm probe. This does not model browser rendering or native
// MutationObserver scheduling; actual native controls are reviewed separately.
const out=path.dirname(new URL(import.meta.url).pathname);
const current=readFileSync(path.join(out,'frozen/tests/ui/post-burst-paint.ts'),'utf8');
const baseline=execFileSync('git',['show','2b46a4487a08e069bcae74fd98f62f4899789fa6:tests/ui/post-burst-paint.ts'],{encoding:'utf8'});
const rules=JSON.parse(readFileSync(path.join(out,'static-contract-result.json'),'utf8')).identityRules;
const sha=value=>createHash('sha256').update(value).digest('hex');

async function run(text,scenario,delivery){
 let now=0,next=0,readCalls=0,identifyCalls=0;
 const observers=new Set(),listeners=new Map(),frames=new Map(),timers=new Map();
 const pending=(type,target,extra)=>{for(const observer of observers){const options=observer.options;if(!options)continue;if(type==='attributes'&&(!options.attributes||options.attributeFilter&&!options.attributeFilter.includes(extra.attributeName)))continue;if(type==='childList'&&!options.childList)continue;observer.records.push({type,target,...extra});}};
 class Element {
  constructor(attrs={},parent=null,tagName='DIV'){this.attrs=new Map(Object.entries(attrs));this.parentElement=parent;this.tagName=tagName;this.isConnected=true;this.classList={contains:token=>new Set((this.getAttribute('class')??'').split(/[\t\n\f\r ]+/).filter(Boolean)).has(token)};}
  getAttribute(name){return this.attrs.get(name)??null;}
  setAttribute(name,value){const oldValue=this.getAttribute(name);this.attrs.set(name,String(value));pending('attributes',this,{attributeName:name,oldValue});}
  removeAttribute(name){const oldValue=this.getAttribute(name);this.attrs.delete(name);pending('attributes',this,{attributeName:name,oldValue});}
  contains(element){for(let current=element;current;current=current.parentElement)if(current===this)return true;return false;}
  closest(){for(let current=this;current;current=current.parentElement)if(current.classList.contains('ui-virtual-row')||current.getAttribute('data-virtual-row-key')!==null)return current;return null;}
  get id(){return this.getAttribute('id')??'';}
 }
 const html=new Element(),body=new Element({},html),viewport=new Element({'aria-posinset':'5','aria-rowindex':'6'},body),row=new Element({'class':'paint-row ui-virtual-row','aria-posinset':'1','aria-rowindex':'2','data-virtual-row-key':'row-a'},viewport),target=new Element({'id':'paint-target'},row,'INPUT'),other=new Element({'id':'paint-other'},row,'INPUT');
 const state={metric:{ready:scenario==='already-ready',nested:{version:0}}},document={activeElement:target,
  addEventListener(name,handler){const entries=listeners.get(name)??new Set();entries.add(handler);listeners.set(name,entries);},
  removeEventListener(name,handler){listeners.get(name)?.delete(handler);}
 };
 class MutationObserver {
  constructor(callback){this.callback=callback;this.records=[];this.options=null;observers.add(this);}
  observe(_target,options){this.options=options;}
  takeRecords(){return this.records.splice(0);}
  disconnect(){this.records=[];this.options=null;observers.delete(this);}
 }
 const window={},context={exports:{},window,document,MutationObserver,Element,structuredClone,Error,performance:{now:()=>now},
  setTimeout:(callback,delay)=>{const id=++next;timers.set(id,{callback,due:now+delay});return id;},clearTimeout:id=>timers.delete(id),
  requestAnimationFrame:callback=>{const id=++next;frames.set(id,callback);return id;},cancelAnimationFrame:id=>frames.delete(id),
 };
 const code=ts.transpileModule(text,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 vm.runInNewContext(code,context,{filename:'pinned-post-burst-paint.js'});context.exports.installPostBurstPaintObserver();
 const history=[],changeDefinitions={
  'restored-target-id':{element:target,name:'id',value:'other-target',identify:element=>element.id},
  'restored-target-control':{element:target,name:'data-fast-control',initial:'main',value:'tail',identify:element=>'control:'+element.getAttribute('data-fast-control')},
  'restored-target-role':{element:target,name:'role',initial:'cell',value:'button',identify:element=>element.getAttribute('role')==='cell'?'cell1':'control:'+element.tagName},
  'restored-target-column':{element:target,name:'aria-colindex',initial:'1',value:'2',identify:element=>'cell'+element.getAttribute('aria-colindex')},
  'restored-target-boundary':{element:target,name:'data-fast-boundary',initial:'before',value:'after',identify:element=>element.getAttribute('data-fast-boundary')??element.id},
  'restored-target-nested':{element:target,name:'data-fast-nested',initial:'0',value:'1',identify:element=>'nested:'+element.getAttribute('data-fast-nested')+':main'},
  'restored-ancestor-position':{element:row,name:'aria-posinset',value:'2',identify:element=>'row:'+(Number(element.closest().getAttribute('aria-posinset'))-1)+':main'},
  'restored-ancestor-rowindex':{element:row,name:'aria-rowindex',value:'3',identify:element=>'row:'+(Number(element.closest().getAttribute('aria-rowindex'))-2)+':main'},
  'restored-ancestor-key':{element:row,name:'data-virtual-row-key',value:null,identify:element=>'row:'+(Number(element.closest().getAttribute('aria-posinset'))-1)+':main'},
  'restored-ancestor-class':{element:row,name:'class',value:'paint-row',identify:element=>'row:'+(Number(element.closest().getAttribute('aria-posinset'))-1)+':main'},
 };
 const change=changeDefinitions[scenario];
 if(change?.initial!==undefined)change.element.attrs.set(change.name,change.initial);
 if(scenario==='restored-ancestor-key'){viewport.attrs.set('class','ui-virtual-row');row.attrs.set('class','paint-row');}
 if(scenario==='restored-ancestor-class'){viewport.attrs.set('class','ui-virtual-row');row.attrs.delete('data-virtual-row-key');}
 const rawIdentify=change?.identify??(element=>element?.id??'null');
 const identify=element=>{identifyCalls++;if(scenario==='identify-throws'&&identifyCalls===3)throw Error('identify failed');return rawIdentify(element);};
 const initialExpected=rawIdentify(target);
 let result,error,done=false;
 const promise=window.__observePostBurstPaint({expectedIdentity:initialExpected,identify,identityRules:rules,timeoutMs:scenario==='raf-suspended-timeout'?32:1000,
  read:()=>{readCalls++;if(scenario==='read-throws')throw Error('read failed');return state.metric;},
  isReady:metric=>{if(scenario==='isReady-throws')throw Error('isReady failed');return metric.ready;},
 });
 promise.then(value=>{result=value;done=true;},value=>{error=value.message;done=true;});
 if(change){const before=change.element.getAttribute(change.name);history.push(rawIdentify(target));if(change.value===null)change.element.removeAttribute(change.name);else change.element.setAttribute(change.name,change.value);history.push(rawIdentify(target));if(before===null)change.element.removeAttribute(change.name);else change.element.setAttribute(change.name,before);history.push(rawIdentify(target));state.metric.ready=true;state.metric.nested.version=1;}
 if(scenario==='cosmetic-style'){target.setAttribute('class','cosmetic\u00a0ui-virtual-row');target.setAttribute('class','cosmetic\u00a0ui-virtual-row paint-ready');row.setAttribute('class','paint-row ui-virtual-row paint-complete');target.setAttribute('style','top:12px');target.setAttribute('aria-label','completed');state.metric.ready=true;}
 if(scenario==='removed-ancestor-restored'){pending('childList',body,{removedNodes:[row]});state.metric.ready=true;}
 if(scenario==='returned-focus'){for(const event of ['focusout','focusin','focusout','focusin']){const eventTarget=event==='focusout'?(document.activeElement===target?target:other):(document.activeElement===target?other:target);if(event==='focusin')document.activeElement=eventTarget;for(const handler of listeners.get(event)??[])handler({target:eventTarget});}document.activeElement=target;state.metric.ready=true;}
 const options=[...observers].map(observer=>observer.options);
 let delivered=0,drives=0;
 for(;!done&&drives<20;drives++){
  if(delivery==='callback')for(const observer of observers){const records=observer.takeRecords();if(records.length){delivered+=records.length;observer.callback(records);}}
  await Promise.resolve();await Promise.resolve();if(done)break;
  if(scenario!=='raf-suspended-timeout'&&frames.size){now+=16;const [id,callback]=frames.entries().next().value;frames.delete(id);callback(now);}
  else if(timers.size){const [id,timer]=[...timers].sort((a,b)=>a[1].due-b[1].due)[0];timers.delete(id);now=timer.due;timer.callback();}
  else throw Error('no scheduled work before completion: '+scenario);
  await Promise.resolve();await Promise.resolve();
 }
 assert(done,'finite algorithm probe terminated: '+scenario);await promise.catch(()=>{});
 const cleanup={listeners:[...listeners.values()].reduce((n,set)=>n+set.size,0),observers:observers.size,frames:frames.size,timers:timers.size};
 assert.deepEqual(cleanup,{listeners:0,observers:0,frames:0,timers:0},'cleanup '+scenario);
 return {scenario,delivery,outcome:result?.outcome??'rejected',error:error??null,initialReady:result?.initial.ready??null,finalReady:result?.final.ready??null,attempts:result?.attempts??null,targetIssue:result?.targetIssue??null,history,readCalls,options,delivered,cleanup,detachedInitial:result?result.initial.metric?.nested.version===0:null};
}
const names=['restored-target-id','restored-target-control','restored-target-role','restored-target-column','restored-target-boundary','restored-target-nested','restored-ancestor-position','restored-ancestor-rowindex','restored-ancestor-key','restored-ancestor-class'];
const comparisons=[];
for(const delivery of ['callback','takeRecords'])for(const scenario of names){
 const old=await run(baseline,scenario,delivery),corrected=await run(current,scenario,delivery);
 assert.equal(old.outcome,'ready','baseline counterexample '+scenario);assert.equal(corrected.outcome,'target-changed','corrected '+scenario);assert.equal(corrected.initialReady,false);assert.equal(corrected.finalReady,true);assert.equal(corrected.detachedInitial,true);assert.notEqual(corrected.history[0],corrected.history[1]);assert.equal(corrected.history[0],corrected.history[2]);comparisons.push({old,corrected});
}
const extra=[];
for(const scenario of ['already-ready','cosmetic-style','raf-suspended-timeout','read-throws','isReady-throws','identify-throws','removed-ancestor-restored','returned-focus']){
 const result=await run(current,scenario,'takeRecords');
 const expected={'already-ready':'ready','cosmetic-style':'ready','raf-suspended-timeout':'timeout','read-throws':'measurement-failed','isReady-throws':'measurement-failed','identify-throws':'rejected','removed-ancestor-restored':'target-changed','returned-focus':'target-changed'}[scenario];assert.equal(result.outcome,expected,scenario);extra.push(result);
}
const result={status:'PASS',scope:'Finite mocked algorithm and cleanup checks only; not native DOM, rendering, keyboard, application or cross-engine acceptance.',baselineSha256:sha(baseline),correctedSha256:sha(current),comparisons,extra};
writeFileSync(path.join(out,'identity-history-result.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:result.status,oldCounterexamples:comparisons.length,correctedHistoryRejections:comparisons.length,deliveryModes:['callback','takeRecords'],extra:extra.map(value=>({scenario:value.scenario,outcome:value.outcome})),allCleanupZero:true}));
