# WebKit terminal virtual-list investigation

2026-10-18. Investigation target: `feat/ui-static-warning-release`, HEAD `c19aa1137a1ca281e433d4d96b56f27e45099cd8`.

## Conclusion and boundary

The frozen broad run contains a real immediate visibility failure: focus reaches input 999, but WebKit's viewport is temporarily 249 CSS pixels above its settled terminal scroll position. The range, DOM, row size, application padding, and CDK transform agree at that instant. This is not explained by the hit-test inset, scrollbar gutter, a missing final row, a wrong fixed row height, or a second CDK offset.

The trace later shows the scroll position correcting while the window/padding/spacer stay unchanged. A single authorized three-arm diagnostic also observes transient native scroll movements in the application. Its scroll-call provenance records no JavaScript scrolling or logical-position rebase during the C burst/correction. A subsequent fixed native-only scheduling experiment shows the same failure category without application callbacks or window mutations: input 999 is immediately offscreen, then becomes visible when native scrolling catches up.

Native scrolling is therefore sufficient for the **immediate-offscreen / later-visible category**. The exact original 249px intermediate position and hypothesized completed centering of row 997 were not reproduced by the controlled native experiment; the observed 997 position differs, so that specific hypothesis is **UNSUPPORTED**. A permanent product defect, exact scheduling cause, and final acceptance/fix policy remain **UNRESOLVED**. Diagnostic passes do not replace the frozen broad failure. The v2 scheduling attempt failed setup before any Tab because the reused HTML retained a closed-server stylesheet URL. Its causal treatment is **NOT_RUN / UNKNOWN**; v3 is a separately authorized origin-only harness repair with its own retained result. No automatic retry occurred.

No product, original test, generated source, or Git state was changed by this investigator. Only the owned diagnostic folders and this report were created. No production/deployment operation was performed.

## Frozen inputs and raw evidence

All hashes below are SHA-256.

| Input | Hash |
| --- | --- |
| `tests/ui/virtual-fast-tab.spec.ts` | `bd6657b953083ca945c00792ab58dbada533ea704612c3a3cf0f7951b014f616` |
| `templates/angular/virtual-scroll.ts` and generated counterpart | `826eaf798b70dad85a8221d1105a0ce8ef040be52ef803ba93d8d7fca4332c08` |
| `templates/angular/virtual-list.ts` | `25098fbd360d94ef17eaa6e4bcafd7cec87fe0196403456d282946281f8b96de` |
| `templates/angular/virtual-rows.ts` | `1336cf776a0952ae3c0c3bd5c81ca7e8c872d3ee2be6bea2fa9f07e1f2c240ee` |
| `templates/angular/collection-model.ts` | `357816b840d0337710c84d9204fdc165a15325d2b074a88d1373360cd7c71863` |
| `tests/ui/css-override-test.ts` | `87879619c19ecc8eb2b2acd65db71e08803cf61701887982b8abcaf69d085641` |
| Local CDK `fesm2022/scrolling.mjs` | `b08bd13e3f76034695114a19e015b34c255336f49ce2960cfe03190db0478b37` |
| Guarded `dist/fixture-app/main.js` | `b381a2a994a883ec91cc2c8856cd5d9f9b37715b8a8d46d88711f54f7ae7c27a` |
| Broad raw `cross-browser-radio-v10/results.json` | `8792f0452a1c9394a26228788bc7ababa128eea474b4f772389063e89cf0c7a9` |

The broad result is 119 passed / 1 failed: Chromium 40, Firefox 40, WebKit 39 passed and this one failure. Retries, skips, and flaky results are zero. The build exited 0; the native suite exited 1. These are distinct outcomes.

Frozen failure directory:
`cross-browser-radio-v10/artifacts/virtual-fast-tab-fast-nati-b674a-s-never-exit-before-row-999-webkit/`

| Artifact | Hash |
| --- | --- |
| `trace.zip` | `7221c1776582f2c00070fb9c413e32a9d3b3ffbe755438845882a6563fa09200` |
| `error-context.md` | `7578b80c7eedfb4607d464f23b96234b953b6aa986feefe5f6a313a11a1de15d` |
| `test-failed-1.png` | `e919298e541b550423ef7e986dde7204f3f49282a7596651f7703154644f624a` |
| ZIP `1-trace.trace` | `ec572d21831c0feb9bdbef276014cc3e36027ac9042cad1796ab4cc627085a2c` |
| ZIP `test.trace` | `14ebc164168d0947d31e1eb04935eec6781c93afcfd7aa9ae550a2522df7ecf4` |
| ZIP immediate keyup attachment `2b02a518aef9a86fe94ce96e5b7eda8f03250299` | `b04cfef7ed39508f347c8effc17fa8e03031e71d8d173be25aba2fd8da9673cf` |

The archived test source has the same `bd6657...` hash as the checkout. The broad and diagnostic receipts preserve the complete 716-source / 309-bundle manifests; they did not drift. The frozen failure ZIP was rehashed before and after both diagnostics and remained identical.

## Exact failed sequence

The case begins at test line 88. It creates 1000 projected input rows with viewport height 360, default measured item height, overscan 2, then uses the same instance in D followed by C. D is dense/1280px/100%/RTL/reduced motion; C is guided/320px/200%/LTR/no motion preference. `End` and setup/profile changes settle; the terminal Tab burst does not.

At C, the settled End range is `[994,1000)`. The keyup recorder confirms uncancelled trusted native traversal from the external anchor to the viewport and every input 994 through 999. Every keyup has a bounded public range and bounded DOM. The test fails only in the post-burst geometry helper, actual current source line 107, before it can record the normal C metric or Tab out.

The raw metric is still recoverable from `1-trace.trace`, `call@186` after/result. Decoding Playwright's serialized value yields this canonical JSON hash (sorted keys, UTF-8, compact separators): `6c7740af72996ec3ad9e1ebb1c903b6aef9beaca39554158f89c008d89071ec1`.

| Metric at failure | Actual |
| --- | --- |
| Public range and DOM | `[993,1000)`, exactly rows 993..999 |
| Measured/fixed row heights | All 160 |
| Application leading padding | 158880 = 993 × 160 |
| CDK wrapper Y transform | 0 |
| Viewport content Y | 231.375 .. 589.375; height 358 |
| Active input | row 999, Y 690.375 .. 770.375; height 80 |
| Active paint result | false, empty intersection/hit list |
| First visible row | row 996, Y 198.375 .. 358.375; paint true |
| Viewport scrollTop | 159393, raw snapshot and rect-derived values agree |
| Terminal maximum | 160000 − 358 = 159642 |

This is a 101px gap between active.top and viewport.bottom, not a fractional-pixel edge problem.

The relevant raw snapshot timeline is below. Timestamps are trace monotonic milliseconds. Snapshot subtree references were resolved using the local Playwright postorder-node/reference contract (`coreBundle.js:5198-5214,5546-5552`); unchanged references are not mistaken for missing DOM.

| Point | Timestamp | scrollTop | Window padding / rows |
| --- | --- | --- | --- |
| D→C setup settled, `call@152 after` | 268364.903 | 159075 | 158560 / 991..999 |
| C End, `call@158 after` | 268376.902 | 159642 | preceding window pending |
| End settlement, `call@160 after` | 268414.761 | 159642 | 159040 / 994..999 |
| Tab to 995, `call@174 after` | 268439.455 | 159642 | 158880 / 993..999 |
| Tab to 996, `call@176 after` | 268443.308 | 159642 | 159040 / 994..999 |
| Tab to 997, `call@178 after` | 268456.306 | 159393 | 159040 / 994..999 |
| Tab to 998, `call@180 after` | 268461.672 | 159393 | 158880 / 993..999 |
| Tab to 999, `call@182 after` | 268465.397 | 159393 | 158880 / 993..999 |
| Immutable geometry, `call@186 after` | 268480.475 | 159393 | 158880 / 993..999 |
| Before probe disposal, `call@188 before` | 268488.093 | 159642 | 158880 / 993..999 |

The last correction happens with unchanged padding, row set, row height, and 160000px spacer. At 159393, the row 997 input is exactly centered: its Y is 370.375..450.375, center 410.375, the same as the 358px viewport center. Restoring 159642 places input 999 at 441.375..521.375.

The saved PNG and final screencast (268504.344) are later than the failed measurement and show input 999 visible. They establish the later view only; they do not invalidate the earlier failed metric.

## Source and callback ordering

* `virtual-list.ts:33` delegates Tab to `prepareTab`; it does not cancel native Tab or focus a projected control. `End` calls the explicit instant index-scrolling API.
* `virtual-scroll.ts:66-96` synchronously prepares the bounded window, calls the component's `detectChanges`, and then lets the browser perform default Tab. The non-radio path calls `update()` even when later terminal inputs already exist.
* `virtual-scroll.ts:151-173` builds indices and owned leading padding, updates the public range, and retains the active row within the bound. It does not directly write scrollTop. For the observed terminal steps it alternates the leading window between 993 and 994 while preserving each logical row's absolute content coordinate.
* `virtual-rows.ts:22-32` removes/inserts keyed views and applies row gaps during that local detection. The test's real projected row is a flex label/input (`runtime-reassessment-virtual.ts:7-14`).
* CDK subscribes to scroll through `auditTime(0, animationFrameScheduler)` (`scrolling.mjs:574,660-664`). Range publication is synchronous, while CDK's change-detection bookkeeping is scheduled (`715-724,813-840`). A range mutation and a native scroll event therefore need not have the same completion boundary.
* `virtual-list.ts:36-38` observes measured row/viewport changes and rebases logical position when geometry changes. `CollectionScrollPosition.rebase` returns null for unchanged geometry (`collection-model.ts:49-60`). This was a plausible alternative source of a late explicit scroll and was instrumented rather than assumed absent.
* `focus.ts` and `collection-runtime.ts` only restore fallbacks for disappearance/disabled owned controls; the observed active projected input stays connected. The frozen identity sequence supplies no evidence for fallback focus in this failure.

## v1: one fixed three-arm diagnostic

Artifacts: [summary](webkit-fast-terminal-diagnostic-v1/diagnostic-summary.json), [raw results](webkit-fast-terminal-diagnostic-v1/results.json), [receipt](webkit-fast-terminal-diagnostic-v1/run-receipt.json), [copy provenance](webkit-fast-terminal-diagnostic-v1/copy-provenance.json).

Command: `node docs/verification/ui-static-warning-release-20261018/webkit-fast-terminal-diagnostic-v1/run.mjs`.

This diagnostic explicitly used **BUILD NOT_RUN**, the guarded existing bundle above, WebKit 26.6 / Playwright 1.63.0, Desktop Safari settings and the repository Cocoa keyboard launcher. One worker, retries 0, repeatEach 1, three declared arms executed once. Exit 0; 3 passed, 0 skipped/flaky. Owned origin `127.0.0.1:64049` closed in the runner's finally block; exec session 82674 completed. HEAD, all source/bundle manifests, harness, frozen ZIP stayed identical before/after.

| Arm | Actual result | Trusted native keys | Immediate C / native terminal result |
| --- | --- | --- | --- |
| 01 exact original body/helpers; import paths relocated only | passed once | 21 Tab + 2 End; 21 trusted uncancelled Tab keyups | Input 999 at 441.375..521.375 |
| 02 same body with scroll-call/MO provenance and pre-assert immutable metric | passed once | 21 Tab + 2 End; 21 trusted uncancelled Tab keyups | scrollTop 159642; input 999 at 441.375..521.375 |
| 03 native listener-free terminal clone | reference validation passed once | 7 trusted uncancelled Tab; 0 End | immediate and deferred scrollTop 159642; same input rect |

Arm 01 is byte-identical to the original spec after reversing the two relative-import relocations. The full original body/reference helpers are preserved. Its raw trace transiently shows scrollTop 159073 during traversal and later returns to 159642 before its geometry check.

Arm 02 delegates the original native scrolling methods/setter unchanged; records call parameters, times, stacks, public ranges, style mutations, strategy callbacks, and native scroll event identities; and does not add per-key layout reads, polling, RAF, or delays. It preserves all original assertions. It saves the immediate geometry before assertions and defers any further frame observation until after the burst. The instrumentation can affect event-loop timing; the non-reproduction of the unmodified arm means no causal claim can be based on comparing pass/fail alone.

Arm 02 raw trace transiently reproduces **159393** as well. Its complete journal has JavaScript scroll writes only for D End, the D→C geometry rebase (159105), and C End. No JS `scroll*`, scrollTop-setter, viewport-scroll, component-scroll, or rebase call occurs during the C burst or before the immediate geometry. The last C keyup is at page time 2363; the native scroll event at 2388 precedes `onContentScrolled` at 2389 and geometry at 2392. The range/padding already remain `[993,1000)` / 158880. This makes a direct late product scroll/rebase write unsupported for this occurrence. It leaves native behavior triggered or timed by the product's DOM updates as a live hypothesis.

Arm 02's finally read is after the original test successfully Tabs to the external after-button. Its deferred finally geometry is therefore **not** an additional row-999 acceptance result.

Arm 03's clone preserves the complete rendered DOM/CSS scoping attributes, projected values, inherited guided profile/tokens, 200% root font, LTR, no motion preference, 320×1000 viewport, 360px border-box viewport, 358px client height, 160000px spacer, padding 159040, initial scrollTop 159642, and rows 994..999. Exact source/native structural fingerprints match both at setup and after the native burst. It has zero scripts, no application runtime, zero inline handlers, and requests only the stylesheet. The diagnostic identity recorder does not move focus or cancel keys. No native scroll event was captured, and both immediate/deferred terminal metrics remain identical.

This static clone begins from a rendered C snapshot of the D→C source. It does not reproduce the source's per-key window mutations or WebKit's internal scheduling history. Its seven-key burst can finish within one rendering opportunity; it cannot disprove an intermediate focus-scroll commit when product work spans a frame.

## v2: fixed native scheduling control, setup failed

Artifacts: [summary](webkit-fast-terminal-diagnostic-v2/diagnostic-summary.json), [raw results](webkit-fast-terminal-diagnostic-v2/results.json), [receipt](webkit-fast-terminal-diagnostic-v2/run-receipt.json), [declared protocol](webkit-fast-terminal-diagnostic-v2/protocol.json).

The authorized hypothesis was: native focus requests may coalesce in a short static burst, whereas an intermediate row 997 request may commit when a rendering opportunity occurs. The fixed protocol specified five uninterrupted Tabs through row 997, exactly one diagnostic two-RAF boundary there, then the final two Tabs and geometry in the first subsequent browser evaluate. This was explicitly a scheduling experiment, not application acceptance, and no 159393 scroll position was to be written.

One case was attempted with retries/repeatEach 0/1 and BUILD NOT_RUN. It failed the exact setup fingerprint before the first Tab. The immutable blueprint retained an absolute stylesheet/base URL pointing to the already closed v1 port 64049; v2 owned port 64134. The missing stylesheet changed fonts, tokens, padding, and row/input geometry. The fixture also correctly failed on its browser console resource error. Reusing the old asset origin was an investigator harness error, not product evidence.

Actual key count **0**. The row 997 boundary, final two keys, immediate/deferred comparison, and scheduling hypothesis are **NOT_RUN / UNKNOWN**. Exit 1, one unexpected setup failure, zero retries/skips/flaky. The owned v2 server closed; exec session 1650 completed. HEAD, 716 source hashes, 309 bundle hashes, v2 harness, reused blueprint/helper, and frozen failure evidence did not drift. No rerun or harness mutation followed this failed attempt.

## v3: origin-only harness repair and one native scheduling experiment

Artifacts: [summary](webkit-fast-terminal-diagnostic-v3/diagnostic-summary.json), [raw results](webkit-fast-terminal-diagnostic-v3/results.json), [receipt](webkit-fast-terminal-diagnostic-v3/run-receipt.json), [origin repair](webkit-fast-terminal-diagnostic-v3/origin-repair.json), [stylesheet byte proof](webkit-fast-terminal-diagnostic-v3/stylesheet-byte-proof.json).

The parent separately authorized a fresh v3 after v2's setup failure. V1 and v2 stayed unchanged. V3 changes exactly two origin strings in a transformed copy: `base.href` at HTML string index 84 and `stylesheet.href` at index 335 (UTF-16 code units), from `http://127.0.0.1:64049` to the new owned `http://127.0.0.1:64181`. Reversing these two substitutions exactly recovers the source HTML. The immutable v1 blueprint keeps hash `001c97e9...`; transformed HTML hash is `08d4093ab5f0ded7ac01b5910f4577b2c7f842b627680cb4c9cb44e7c0f86bc7`. No token, CSS, DOM geometry, or scrolling value was changed to make the fingerprint pass.

Before any keys, fetching the new server's stylesheet returns 200 and 136273 bytes, hash `fc240658b9995b83293a4b0de48e88a20e26334146d96351e034fe1caede1459`, equal to the guarded 309-file bundle manifest. Both prior server ports refuse connections and both prior receipts record closure. Native setup and post-burst structural fingerprints exactly equal the immutable C source fingerprint. There are zero application scripts, no runtime, zero inline handlers, and one stylesheet request.

One fixed WebKit 26.6 / Playwright 1.63.0 case ran once, one worker, retries 0, repeatEach 1, BUILD NOT_RUN. Protocol integrity passed; exit 0. This result **does not assert immediate target visibility**: visibility is recorded as an immutable experimental observation. All seven Tab keyups are trusted and uncancelled, visit viewport then rows 994..999, and retain the same bounded six-row DOM. No native application acceptance was substituted.

The declared sequence was: five uninterrupted Tabs through input 997; exactly one diagnostic two-RAF boundary; then two uninterrupted Tabs to inputs 998 and 999. The first browser evaluate after those last two keys is `call@47`, the immutable immediate geometry sample. No JavaScript scroll write occurred after initial setup.

| Observation | Page time | scrollTop | Active input Y | Viewport Y |
| --- | --- | --- | --- | --- |
| After the declared 997 boundary | 405 (RAF timestamps 371,404) | **159241** | 997: 522.375..602.375 | 231.375..589.375 |
| First evaluate after final two keys | **413** | **159241** | 999: **842.375..922.375**, entirely offscreen | 231.375..589.375 |
| Separate deferred observation | 474 | **159642** | 999: **441.375..521.375**, visible | 231.375..589.375 |

The predicted completed 997-center offset was 159393. Actual boundary offset 159241 and active center 562.375 do not match the viewport center 410.375. Thus `boundaryCentered997=false`; the precise completed-centering hypothesis is **UNSUPPORTED**, with no adjustment or extra run. Nevertheless, immediate-offscreen and later terminal correction occur with no application scripts, handlers, range changes, or padding mutations. This independently demonstrates native sufficiency for that broader category. It does not show that all details of the original 249px position have the same explanation or rule out application work affecting when the original oracle runs.

The owned v3 server closed in finally; exec session 20804 completed. Source/head/bundle/harness/reused-input manifests and frozen failure evidence remain unchanged. No further native run was performed.

## Falsifiable interpretation and safe next choices

| Hypothesis | Current evidence | Status |
| --- | --- | --- |
| Geometry failure is only hit-test/gutter/clip rounding | Raw scroll and active rect both show a 249px movement and completely offscreen target | Falsified for frozen failure |
| Missing terminal DOM, bad fixed heights, padding/range mismatch, doubled CDK offset | Exact metric and trace agree; first visible row is painted | Falsified for frozen failure |
| Geometry rebase or explicit product scroll directly causes the observed late correction | No such call during the instrumented C movement/correction; original failure has no call interceptor | Unsupported for instrumented occurrence; original call provenance unmeasured |
| Native scrolling can produce an immediately offscreen final input and later correct it without app callbacks | V3 exact-geometry native reference does so, after the predeclared scheduling boundary | Verified for this category and controlled sequence |
| The original 159393 offset is a completed native centering of row 997 with the same scheduling path | Original geometry is consistent; v3 actual 997 offset is 159241, not 159393 | Specific completed-centering hypothesis UNSUPPORTED |
| Product window mutation is necessary for the broad immediate-offscreen/later-visible category | V3 has no such mutations and still exhibits that category | Falsified for the category; exact original timing remains UNKNOWN |

The scheduling control is complete with the boundaries above. No additional native run is implied by this report. The current native evidence is enough to reject a blanket claim that every post-keyboard-IPC geometry read must already show the final focused native input, but it is not an acceptance decision for the application.

A narrowly scoped test-policy option is now supported for evaluation: distinguish the immutable immediate native-scroll sample from the post-burst observable painted result, retaining every uninterrupted per-key identity/range/DOM assertion and the full geometry/hit-test requirements. This changes the oracle's synchronization boundary and needs the parent's explicit acceptance decision and independent review; it must not relabel the frozen failure. A separate product option, if future evidence finds harmful mutations, is avoiding unnecessary terminal-window replacement when a subsequent native stop already exists, followed by review of native order, sparse controls/radios, bounded ranges/DOM, recycling, and free scrolling. Neither option was implemented or accepted by this investigator. No weaker geometry tolerance, skipped assertion, retry, sleep, or per-key pacing was introduced.

## Diagnostic artifact digests

| File | SHA-256 |
| --- | --- |
| v1 `diagnostic-summary.json` | `cd6684f2b5f594a4020d98960986caa94361efa02eccbf00517a061a3f28bf2d` |
| v1 `run-receipt.json` | `afe84439a99629da57772a0f4b35ad4841c229569496ac938f3bd3d866f5976c` |
| v1 `results.json` | `3adfaac22f77a180991a96ed25b1c27e3c644a810d9df4ecb9f31443c26b7864` |
| v1 `native-blueprint.json` | `001c97e93f1842a39876973d1796e8681143498cfda899175666d3591150cbea` |
| v1 exact-arm trace | `5c081be9dbc2c4dee5337864826b5a50e4c9d68491fd6599c296d69a483a3822` |
| v1 instrumented-arm trace | `09b2dc80c31f3cba0b172a20af4d18f79642243e14cfacec2d14485f003d08d3` |
| v1 native-arm trace | `4e5c6a2cb314055fd9dbc3383380d6ddf4ce83ef8d44d1cb0450c09b6116915b` |
| v2 `run-receipt.json` | `c3b8b0d4fde3bfbf00e25a113a9f7780d1d23043c7cc6c8400a0e173bcab34df` |
| v2 `results.json` | `ce9f58015a27ea9b1f57c0cdd86ebff82ac94c9fece92e62e2168248c2269f7e` |
| v2 native scheduling trace | `798dcfaa906fa2f795980f07c5bcc7c83aca75a1a09ef992b9a75b4c62e04376` |
| v3 `diagnostic-summary.json` | `edb0eb8ba8c3e1625dfc227a1ba43d81a65dcef40ec9bb91a2808040375bdb8a` |
| v3 `run-receipt.json` | `a31e3d28a09cec04d12b55e8d0279c841c09b62ec6a68c94861b6c8875407ffd` |
| v3 `results.json` | `6d79bbd57c216933cd7fb8ddc79abb6502a8574d9ff63e40f368926680e039b0` |
| v3 native scheduling trace | `231350436f86ffdb730cfaf2f143298fb7d7ea4918528d8d86b25d8105f247af` |

No independent reviewer or subagent was invoked by this investigator. The parent owns acceptance, any product fix, independent review, ledger reconciliation, and further authorized verification. No worktree was created; existing shared worktrees and unrelated artifacts were preserved.

All source/head/bundle identity and no-drift statements in this report refer to the frozen **c19aa113 diagnostic execution intervals**, not future live-checkout state. After these experiments and their final hash readback, the parent ended the source freeze and assigned a separate worker to post-burst paint test/helper changes. Those later edits and their acceptance/review belong to the parent workflow; the diagnostic manifests must not be presented as verification of a later source head.
