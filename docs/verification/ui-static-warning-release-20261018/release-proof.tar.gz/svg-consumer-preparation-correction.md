# SVGコンシューマーの準備入力の修正

対象は `469e142750a4edb5fdb995e3c2542d481774da50`（branch `feat/ui-static-warning-release`）をbaseとする未コミット変更。主担当が統合、独立レビュー、全体検証、公開操作を担当する。

## 原因と修正

正本YAMLは `checks.tsconfig: tsconfig.json`、`checks.source_roots: [tests/fixture-app, templates/angular]`、334件の例外を指定している。元のSVG隔離準備は `tests/fixture-app/app.css` だけをコピーし、rootのtsconfigと残りのfixtureソースを欠いていた。コンシューマーfixtureには `tsconfig.consumer.json` があり、rootのtsconfigを提供しない。

これは設定からの推測だけでなく、抽出した元の準備処理を実行した一時ツリーで、`tsconfig.json` と `tests/fixture-app/actions-catalog.ts` の読み取りがともにENOENTになることで確認した。canonical-check自体は実行していないため、その終了状態は未確認。

準備処理を `scripts/verification/prepare-svg-consumer.mjs` に抽出し、runnerと回帰テストで共有した。コピー・inventory対象をfixture-app全体とrootのtsconfigへ広げた。設定、例外、部品テンプレート、コンシューマー、台帳は変更していない。

root入力のSHA-256とbytes、コピー後の完全一致、固定バージョンの依存確認、終了時のsource不変確認を維持した。runnerのsource-input記録以降はbaseとバイト一致し、canonical sync/check/idempotent/dry-run、公開consumer build、34件それぞれのnative結果・distinctness・成功assertion、filter環境変数の除去、所有serverの終了処理を維持した。

## 回帰と検証

追加は1つの親テストと3つのsubtest。実際の準備関数で作った一時ツリーに対して、正本YAMLから参照を読み、tsconfig、全source root、全例外のfile anchorの実ファイル・inventory・SHA-256・bytesを照合する。公開コンシューマーfixtureの全ファイルも完全一致を確認する。テスト後の一時ツリーは削除する。

| コマンド | 終了 | 結果 |
|---|---:|---|
| `node --test --test-name-pattern='SVG consumer preparation' tests/verification-tools/portable.test.mjs`（元のコピー集合） | 1 | 2つの入力欠落を再現。親込み4結果、pass 1 / fail 3。 |
| 同コマンド（修正後） | 0 | 親込み4結果、pass 4 / fail 0。 |
| 3変更ファイルの `node --check` と `git diff --check` | 0 | 構文・whitespace検査に成功。 |
| runnerのsource-input記録以降をbaseと比較 | 0 | execution tail完全一致。 |

ログは `svg-consumer-preparation-red.log` と `svg-consumer-preparation-green.log`、コマンド・設定・hashの機械可読記録は `svg-consumer-preparation-receipt.json` に保存した。

## 固定した変更ソース

| ファイル | SHA-256 |
|---|---|
| `scripts/test-svg-paint.mjs` | `c9690e445f8b10833134f88f4e1e94260e711cabcd0eaf29f6aeea12f6978f2d` |
| `scripts/verification/prepare-svg-consumer.mjs` | `458694bd4fff465f7fc5769435a1874ac5a94fa9579f6fbcb15443db349b342b` |
| `tests/verification-tools/portable.test.mjs` | `68b3e1ba666b2757e03643280b9906c676d39ba07ff8993c6f2d4ae67a0bfb15` |

## 未実行と引き継ぎ

canonical sync/check/idempotent/dry-run、公開consumer build、native 34件、通常npm test、test:verification全件は `NOT_RUN`。本作業ではブラウザー起動、build、依存インストール、commit、push、mergeを実行していない。

主担当がこのsource snapshotをfresh reviewerへ渡し、source固定後に通常npm testと実際のSVG 34件受入を直列実行する。ここでの合格は入力準備のfilesystem回帰と構文・保存契約の範囲であり、native描画やbuildの成功を意味しない。
