"""Package an explicit, hash-indexed subset of this task's verification records.

Historical failures stay failures. This archive is evidence, never a test input.
Run once after current acceptance and review have completed.
"""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tarfile
from browser_run_proof import verify_release_browsers

here = Path(__file__).resolve().parent
root = here.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
archive = here / 'release-proof.tar.gz'
index = here / 'release-proof-index.json'
assert not archive.exists() and not index.exists(), 'Use a fresh version; never replace sealed evidence.'
native_run, expected_text = sys.argv[1:]
assert re.fullmatch(r'cross-browser-radio-v[0-9]+', native_run)
expected = int(expected_text)
assert expected >= 120
clean = json.loads((here / 'clean-checkout-v3.json').read_text())
assert clean['status'] == 'PASSED' and clean['npm_test_exit_code'] == 0
assert clean['source_changes'] == []
candidate = json.loads((here / 'candidate-manifest-v7.json').read_text())
assert clean['head'] == candidate['head_sha'] and clean['source_inputs'] == candidate['inputs']
capture = json.loads((here / 'npm-test-clean-v3-receipt.json').read_text())
assert capture['exit_code'] == 0
assert capture['source_changed_during_run'] == [] and capture['bundle_changed_during_run'] == []
assert capture['source_sha256'] == capture['source_after_sha256'] == candidate['inputs']
native_capture = json.loads((here / (native_run + '-receipt.json')).read_text())
assert native_capture['exit_code'] == 0
assert native_capture['source_changed_during_run'] == [] and native_capture['bundle_changed_during_run'] == []
assert native_capture['source_sha256'] == native_capture['source_after_sha256']
# After the guarded application run, only this unrelated SVG preparation driver,
# its helper and filesystem regression changed. Scope reuse must be explicit.
native_sources = native_capture['source_sha256']
changed = {name for name in native_sources.keys() | candidate['inputs'].keys()
           if native_sources.get(name) != candidate['inputs'].get(name)}
assert changed == {'scripts/test-svg-paint.mjs', 'scripts/verification/prepare-svg-consumer.mjs',
                   'tests/verification-tools/portable.test.mjs'}
native = json.loads((here / native_run / 'run-receipt.json').read_text())
assert native['build']['code'] == native['native']['code'] == 0 and native['serverClosed']
assert native['explicitPlaywrightFilters'] == [] and native['engines'] == ['chromium', 'firefox', 'webkit']
browser_proofs = verify_release_browsers(here)
assert native_run == 'cross-browser-radio-v12' and expected == browser_proofs['native180']['tests']
bridge = json.loads((here / 'final-scope-bridge.json').read_text())
assert all(bridge[name]['validated_run'] == proof for name, proof in browser_proofs.items())

selected = {}
def add(path, name=None):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), str(path)
    name = name or path.relative_to(here).as_posix()
    assert not name.startswith('/') and '..' not in Path(name).parts and name not in selected
    selected[name] = path.read_bytes()

names = [
    'run.py', 'run-clean-checkout-v3.py', 'curate-release-proof.py', 'finalize-release-results.py',
    'browser_run_proof.py', 'test-browser-run-proof.py', 'browser-run-proof-tests.log', 'browser-run-proof-tests-receipt.json',
    'browser-run-proof-scope-red.log', 'browser-run-proof-scope-red-receipt.json', 'browser-run-proof-scope-red-source.json',
    'browser-run-proof-scope-green.log', 'browser-run-proof-scope-green-receipt.json', 'browser-run-proof-scope-green-source.json',
    'browser-run-proof-root-red.log', 'browser-run-proof-root-red-receipt.json', 'browser-run-proof-root-red-source.json',
    'browser-run-proof-root-green.log', 'browser-run-proof-root-green-receipt.json', 'browser-run-proof-root-green-source.json',
    'run-existing-bundle.mjs', 'review-evidence-recipe-v1.md', 'review-evidence-recipe-v2.md', 'review-evidence-recipe-v3.md', 'review-evidence-recipe-v4.md',
    'review-evidence-recipe-v2-snapshot.json', 'review-evidence-recipe-v2.patch', 'review-evidence-recipe-v2-probes.json',
    'review-evidence-recipe-v3-snapshot.json', 'review-evidence-recipe-v3.patch', 'review-evidence-recipe-v3-probes.json',
    'review-evidence-recipe-v1/finalize-release-results.py', 'review-evidence-recipe-v1/curate-release-proof.py',
    'npm-test-clean-v3.log', 'npm-test-clean-v3-receipt.json', 'clean-checkout-v3.json',
    'normal-v3-summary.json', 'candidate-manifest-v6.json', 'candidate-manifest-v7.json',
    'final-scope-bridge.json',
    native_run + '.log', native_run + '-receipt.json', native_run + '-summary.json',
    'cross-browser-runtime-summary.json', 'cross-browser-runtime-v9.log',
    'cross-browser-runtime-v9-receipt.json', 'normal-build-bundle-link.json',
    'ui-corrected-contracts-v1.log', 'ui-corrected-contracts-v1-receipt.json',
    'verification-tools.log', 'verification-tools-receipt.json',
    'verification-tools-final.log', 'verification-tools-final-receipt.json',
    'host-key-identity-focused-final.log', 'host-key-identity-focused-final-receipt.json',
    'editor-input-model-v9.log', 'editor-input-model-v9-receipt.json',
    'dependency-versions-current.json',
    'classification-evidence-v7.json',
    'post-burst-controls-v2.log', 'post-burst-controls-v2-receipt.json',
    'post-burst-controls-v2-summary.json',
    'review-checker-v4.md', 'review-runtime-v3.md', 'review-warning-v1.md',
    'review-editor-v3.md', 'review-test-corrections-v1.md',
    'review-fast-tab-budget-v1.md', 'review-post-burst-paint-v1.md', 'review-post-burst-paint-v2.md',
    'review-svg-preparation-v1.md', 'review-svg-preparation-v1-snapshot.json',
    'review-svg-preparation-v1.patch', 'svg-consumer-preparation-correction.md',
    'svg-consumer-preparation-receipt.json', 'svg-consumer-preparation-red.log',
    'svg-consumer-preparation-green.log',
    'review-checker-v4-snapshot.json', 'review-runtime-v3-typed-snapshot.json',
    'review-editor-v3-snapshot.json', 'review-test-corrections-v1-snapshot.json',
    'review-fast-tab-budget-v1-snapshot.json', 'review-post-burst-paint-v1-snapshot.json',
    'review-post-burst-paint-v2-snapshot.json',
    'review-test-corrections-v1.patch', 'review-fast-tab-budget-v1.patch',
    'review-post-burst-paint-v1.patch', 'review-post-burst-paint-v2.patch',
    'review-adjudication-f85544ca.json', 'review-adjudication-20761f98.json',
    'review-adjudication-469e1427.json',
    'review-adjudication-88a72c2a.json',
    'review-fix-readjudication-v5.json', 'review-fix-readjudication-v6.json',
    'review-fix-readjudication-v7.json', 'review-fix-readjudication-v8.json',
    'p2-geometry-test-correction.md', 'palette-close-investigation.md',
    'fast-tab-timeout-investigation.md', 'post-burst-paint-correction.md', 'post-burst-paint-identity-correction.md',
    'webkit-fast-terminal-investigation.md',
    'npm-test-clean-v2.log', 'npm-test-clean-v2-receipt.json',
    'clean-checkout-v2.json', 'normal-v2-failure-summary.json',
    'cross-browser-radio-v10.log', 'cross-browser-radio-v10-receipt.json',
    'cross-browser-radio-v10-summary.json',
    'cross-browser-radio-v11.log', 'cross-browser-radio-v11-receipt.json',
    'cross-browser-radio-v11-interruption.json', 'cross-browser-radio-v11/run-receipt.json',
]
for name in names:
    add(here / name)
for directory in ['cross-browser-radio-v10', native_run, 'cross-browser-runtime-v9', 'post-burst-controls-v2']:
    add(here / directory / 'results.json')
    add(here / directory / 'run-receipt.json')
    # Passing attachments are embedded in JSON; retain raw failed traces/PNGs/context.
    for path in sorted((here / directory / 'artifacts').rglob('*')):
        if path.is_file() and path.suffix in ['.zip', '.png', '.md']:
            add(path)
for directory in ['webkit-fast-terminal-diagnostic-v1', 'webkit-fast-terminal-diagnostic-v2', 'webkit-fast-terminal-diagnostic-v3']:
    for path in sorted((here / directory).rglob('*')):
        if path.is_file() and path.suffix in ['.json', '.md', '.mjs', '.ts', '.html', '.zip', '.png']:
            add(path)
for directory in ['review-post-burst-paint-v1', 'review-post-burst-paint-v2', 'review-svg-preparation-v1']:
    for path in sorted((here / directory).rglob('*')):
        if path.is_file() and path.suffix in ['.json', '.mjs', '.py']:
            add(path)

# The normal suite's final public-consumer stage has its own raw 34-scenario
# assertion and source inventory; retain those records separately from UI logs.
clean_root = Path(clean['checkout'])
assert clean_root.name.startswith('ui-foundation-release-v3-')
svg_root = clean_root / 'test-results/svg-paint'
svg_execution = json.loads((svg_root / 'execution.json').read_text())
assert svg_execution['successful'] and svg_execution['ownServerClosed']
svg_result = json.loads((svg_root / 'candidate-paint-native.json').read_text())
assert len(svg_result['rows']) == 34 and svg_result['allExpected']
assert all(row['passed'] and row['errors'] == [] for row in svg_result['rows'])
for path in sorted(svg_root.rglob('*')):
    if path.is_file() and path.suffix in ['.json', '.log', '.exit']:
        add(path, 'normal-v3-svg/' + path.relative_to(svg_root).as_posix())

# Preserve the twelve original normal-suite failure artifacts, copied only from
# this task's explicitly identified private archive. No other temp tree is read.
old = json.loads((here / 'clean-checkout-v2.json').read_text())
old_root = Path(old['checkout'])
assert old_root.name.startswith('ui-foundation-release-v2-')
for path in sorted((old_root / 'test-results').rglob('*')):
    if path.is_file() and path.suffix in ['.zip', '.png', '.md']:
        add(path, 'historical-normal-v2/' + path.relative_to(old_root).as_posix())

manifest = {
    'schema_version': 1,
    'scope': 'Selected primary logs, receipts, source identities, independent reports and historical failure/control artifacts. Not all historical local files. Not a runtime fixture. Passed and failed run statuses remain distinct.',
    'implementation_head': clean['head'],
    'entries': {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in sorted(selected.items())},
}
manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
with archive.open('xb') as destination:
    with gzip.GzipFile(filename='', mode='wb', fileobj=destination, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as tar:
            for name, data in [*sorted(selected.items()), ('CONTENTS.json', manifest_bytes)]:
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mtime = 0
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
manifest.update({'archive': archive.name, 'archive_sha256': sha(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
                 'embedded_contents_sha256': sha(manifest_bytes)})
index.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'files': len(selected), 'archive_bytes': archive.stat().st_size, 'archive_sha256': manifest['archive_sha256']}))
