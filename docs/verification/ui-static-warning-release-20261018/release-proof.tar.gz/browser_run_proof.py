"""Fail-closed validation of this release's completed browser records."""
from collections import Counter
from datetime import datetime, timedelta
from hashlib import sha256
import json
import math
from pathlib import PurePosixPath

ENGINES = ['chromium', 'firefox', 'webkit']
# Trusted repository context for these particular historical executions. This is
# supplied independently of the raw reporter JSON. Original captures derived
# their ROOT from the reviewed run.py location and did not record a cwd field.
RECORDED_SOURCE_ROOT = '/Users/inouehiroshi/Documents/GitHub/ui-foundation'

def validate_browser_records(*, capture, raw, execution, summary, expected, per_engine,
                             suite, test_scope, implementation_head, build_required,
                             raw_hash, capture_hash, log_hash, recorded_source_root):
    assert capture['exit_code'] == 0
    assert capture['source_changed_during_run'] == capture['bundle_changed_during_run'] == []
    assert capture['source_sha256'] == capture['source_after_sha256']
    assert capture['bundle_sha256'] == capture['bundle_after_sha256']
    assert capture['log_sha256'] == log_hash
    assert summary['raw_result_sha256'] == raw_hash
    assert summary['capture_receipt_sha256'] == capture_hash
    assert summary['implementation_head'] == implementation_head
    if 'log_sha256' in summary:
        assert summary['log_sha256'] == log_hash
    assert execution['suite'] == suite and execution['testScope'] == test_scope
    assert execution['engines'] == ENGINES and execution['explicitPlaywrightFilters'] == []
    assert execution['native'] == {'code': 0, 'signal': None} and execution['serverClosed'] is True
    if build_required:
        assert execution['build'] == {'code': 0, 'signal': None}
    else:
        assert execution['build'] == 'NOT RUN: local diagnostic of the explicit existing compiled fixture'
    assert execution['bundleSha256'] == capture['bundle_sha256']['dist/fixture-app/main.js']
    assert raw['errors'] == []
    config = raw['config']
    execution_root = PurePosixPath(recorded_source_root)
    assert execution_root.is_absolute() and '..' not in execution_root.parts
    assert config['configFile'] == str(execution_root / 'playwright.cross-browser.config.ts')
    expected_dir = str(execution_root / test_scope['testDir'])
    expected_files = set(test_scope['testMatch'])
    assert config['rootDir'] == expected_dir
    assert config.get('testDir', expected_dir) == expected_dir
    assert config.get('testMatch', test_scope['testMatch']) == test_scope['testMatch']
    assert config['shard'] is None and config['grep'] == {} and config['grepInvert'] is None
    assert config.get('tags') in (None, [])
    assert config['workers'] == 1 and config['forbidOnly'] is True
    assert config['version'] == execution['playwright']
    argv = config['argv']
    assert len(argv) == 5 and PurePosixPath(argv[0]).name == 'node'
    assert argv[1] == str(execution_root / 'node_modules/playwright/cli.js')
    assert argv[2:] == ['test', '-c', 'playwright.cross-browser.config.ts']
    assert [project['name'] for project in config['projects']] == ENGINES
    for project in config['projects']:
        assert project['retries'] == 0 and project['repeatEach'] == 1
        assert project['testDir'] == expected_dir and project['testMatch'] == test_scope['testMatch']
        assert project['testIgnore'] == []
        assert project.get('grep') is None and project.get('grepInvert') is None
    stats = raw['stats']
    assert stats == summary['stats']
    assert stats['expected'] == expected == per_engine * len(ENGINES)
    assert all(stats[key] == 0 for key in ['unexpected', 'skipped', 'flaky'])
    assert math.isfinite(stats['duration']) and stats['duration'] > 0
    start = datetime.fromisoformat(stats['startTime'].replace('Z', '+00:00'))
    end = start + timedelta(milliseconds=stats['duration'])
    execution_start = datetime.fromisoformat(execution['startedAtUtc'].replace('Z', '+00:00'))
    execution_end = datetime.fromisoformat(execution['completedAtUtc'].replace('Z', '+00:00'))
    assert capture['started_unix'] <= execution_start.timestamp() <= start.timestamp()
    assert end <= execution_end and execution_end.timestamp() <= capture['finished_unix']

    entries = []
    def walk(node):
        if 'file' in node:
            assert node['file'] in expected_files
        for child in node.get('suites', []):
            walk(child)
        for spec in node.get('specs', []):
            assert spec['ok'] is True and spec['file'] in expected_files
            for test in spec['tests']:
                assert test['expectedStatus'] == 'passed' and test['status'] == 'expected'
                assert len(test['results']) == 1
                attempt = test['results'][0]
                assert attempt['status'] == 'passed' and attempt['retry'] == 0 and attempt['errors'] == []
                identity = (spec['file'], spec['line'], spec['column'], spec['title'])
                entries.append((test['projectName'], identity))
    walk(raw)
    assert len(entries) == len(set(entries)) == expected
    counts = Counter(engine for engine, _ in entries)
    assert dict(counts) == {engine: per_engine for engine in ENGINES}
    catalogs = [{identity for engine, identity in entries if engine == target} for target in ENGINES]
    assert all(catalog == catalogs[0] for catalog in catalogs)
    assert {identity[0] for identity in catalogs[0]} == expected_files
    return {'tests': len(entries), 'passed': len(entries), 'by_engine': dict(counts),
            'unexpected': stats['unexpected'], 'skipped': stats['skipped'], 'flaky': stats['flaky'], 'retries': 0,
            'suite': suite, 'test_scope': test_scope, 'build': execution['build'],
            'recorded_source_root': recorded_source_root,
            'root_binding': 'Explicit trusted task repository context; original capture has no cwd field.',
            'native_exit_code': execution['native']['code'], 'server_closed': execution['serverClosed'],
            'started_at': execution['startedAtUtc'], 'completed_at': execution['completedAtUtc'],
            'raw_result_sha256': raw_hash, 'capture_receipt_sha256': capture_hash, 'log_sha256': log_hash}

def verify_browser_run(directory, *, run_name, summary_name, expected, per_engine,
                       suite, test_scope, implementation_head, build_required,
                       recorded_source_root=RECORDED_SOURCE_ROOT):
    def data(name):
        path = directory / name
        assert path.is_file() and not path.is_symlink(), str(path)
        return path.read_bytes()
    capture_bytes = data(run_name + '-receipt.json')
    raw_bytes = data(run_name + '/results.json')
    execution_bytes = data(run_name + '/run-receipt.json')
    summary_bytes = data(summary_name)
    capture, raw, execution, summary = [json.loads(value) for value in
                                      [capture_bytes, raw_bytes, execution_bytes, summary_bytes]]
    proof = validate_browser_records(capture=capture, raw=raw, execution=execution, summary=summary,
        expected=expected, per_engine=per_engine, suite=suite, test_scope=test_scope,
        implementation_head=implementation_head, build_required=build_required,
        recorded_source_root=recorded_source_root,
        raw_hash=sha256(raw_bytes).hexdigest(), capture_hash=sha256(capture_bytes).hexdigest(),
        log_hash=sha256(data(run_name + '.log')).hexdigest())
    if 'harnessSha256' in execution:
        assert execution['harnessSha256'] == sha256(data('run-existing-bundle.mjs')).hexdigest()
    proof['internal_receipt_sha256'] = sha256(execution_bytes).hexdigest()
    proof['summary_sha256'] = sha256(summary_bytes).hexdigest()
    return proof

def verify_release_browsers(directory):
    runtime = verify_browser_run(directory, run_name='cross-browser-runtime-v9',
        summary_name='cross-browser-runtime-summary.json', expected=48, per_engine=16, suite='runtime',
        test_scope={'testDir': 'tests/cross-browser', 'testMatch': ['runtime-cross-browser.spec.ts']},
        implementation_head='20761f986c6480546ddf405235b1ddf4faa8b405', build_required=False)
    native = verify_browser_run(directory, run_name='cross-browser-radio-v12',
        summary_name='cross-browser-radio-v12-summary.json', expected=180, per_engine=60, suite='virtual-radio',
        test_scope={'testDir': 'tests/ui', 'testMatch': ['virtual-radio.spec.ts', 'virtual-sparse-tab.spec.ts', 'virtual-fast-tab.spec.ts']},
        implementation_head='469e142750a4edb5fdb995e3c2542d481774da50', build_required=True)
    return {'runtime48': runtime, 'native180': native}
