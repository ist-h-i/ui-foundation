# Post-burst paint observation correction

Source is frozen as an uncommitted snapshot on branch `feat/ui-static-warning-release`, base and current HEAD `c19aa1137a1ca281e433d4d96b56f27e45099cd8`. This worker made no commit, browser run, build, generated-source change, ledger change, or external publication. The parent owns integration, independent review, and acceptance execution.

| Owned source | SHA-256 |
| --- | --- |
| `tests/ui/virtual-fast-tab.spec.ts` | `9c92e334585b2cbadc04dcdb7aac894e053987e7ad1162c320ed8598de79db26` |
| `tests/ui/post-burst-paint.ts` | `aaa05618b63103591284cd33559c2dc57c4fee7f85dcdfbe15356fc557a932ee` |

## Behavior and boundary

The correction changes only the explicit post-burst paint observation. Its browser-side observer synchronously clones the FIRST actual metric before its first await. It pins the initial active DOM object and identity, checks that identity against the immediately preceding validated keyup, and records the initial and final metrics, sample count, elapsed time, bound, outcome, and target issue before assertions. Focus leaving and returning before a later sample still fails through focus events; removal, replacement, disconnection, and a changed logical identity also fail. The observer only reads geometry/identity and observes events/mutations; it does not write DOM, focus, scroll, or application state.

The application readiness bound is 1000 ms, observed at rendering opportunities with a deadline timer when RAF is suspended. This is a finite test observation budget with margin over the recorded native deferred-completion category; it is not an inferred browser completion guarantee or an explanation of the original 249 px position. Success still requires the exact original viewport intersection and owned nine-point paint checks. All original range, DOM-row correspondence, fixed-height/window-offset 1 px tolerances, CDK zero-offset, and final paint assertions remain unchanged. The final metric also records actual `scrollTop`.

Every original native key loop, same-instance A→B→C→D progression, 1040/2064 mixed-control count, default delivery, keyup capture, trusted/order/direction/cancellation checks, and per-key range/live-DOM bounds remains unchanged. No per-key layout read, frame wait, poll, or delay was added. No test timeout, driver, supported suite selection, or tsconfig include changed. The setup-only installer import is resolved from the committed test source.

The frozen original failure and the diagnostic v1/v2/v3 artifacts were not modified or rerun. This correction does not relabel that original failure, establish its exact cause, or establish universal runtime safety.

## Regression controls

Nine cases were added to the existing `virtual-fast-tab.spec.ts`, keeping them in the supported cross-browser suite. They use inline, self-contained native DOM, measured rectangles and `elementFromPoint`; they have no historical artifact, application runtime, or diagnostic blueprint dependency. Deterministic producer transitions run in a microtask queued after the observer has synchronously cloned its first sample. Producer mutations are confined to these controls and are separate from the read-only observer and application acceptance.

| Control | Required oracle result |
| --- | --- |
| Initially visible and hit-owned | `ready`, exactly one sample |
| Initially offscreen, producer completes | Preserve offscreen FIRST metric; same pinned target becomes `ready` |
| Initially occluded, producer uncovers | Preserve failed FIRST hit ownership; same pinned target becomes `ready` |
| Persistently offscreen | `timeout`, final target remains offscreen |
| Persistently occluded | `timeout`, final visible rectangle still has unowned hit points |
| Focus changes to another painted input | `target-changed`, despite painted final geometry |
| Focus leaves then returns before next frame | `target-changed`, despite the original DOM target being active and painted again |
| Target replaced by a painted same-ID clone | `target-changed`, despite matching final logical identity |
| Same DOM object changes logical identity | `target-changed`, despite connection, focus, and painted geometry |

Persistent controls use a 100 ms negative-test bound; completion and focus-history controls retain 1000 ms. No producer uses wall-clock timing. The fast file expands from five application cases to fourteen cases; the parent's supported broad matrix is expected to expand from 120 to 147 without filtering the original cases.

## Small checks actually executed

Environment: existing checkout above, Node `v24.19.0`, existing dependencies. No installation or dependency change.

* `node_modules/.bin/tsc -p tsconfig.ui-runtime.json` — exit 0, no diagnostics. The imported helper is included without changing tsconfig.
* Read-only `node --input-type=module` inline TypeScript AST/source contract probe — exit 0. Exact output:

```json
{
  "status": "PASS",
  "base": "c19aa1137a1ca281e433d4d96b56f27e45099cd8",
  "unchangedFunctions": 6,
  "unchangedProbeMembers": 4,
  "unchangedNativeTestBodies": 4,
  "exactGeometryAssertions": "BYTE_IDENTICAL",
  "geometryCallSites": 3,
  "expandedApplicationCases": 5,
  "addedObserverControlCases": 9,
  "expandedFastFileCases": 14,
  "observerForbiddenCalls": 0,
  "observerPropertyWrites": 0,
  "newTimeoutOverrides": 0,
  "browser": "NOT_RUN"
}
```

The probe byte-compared `snapshot`, `tab`, `flush`, `disposeProbe`, `nativeScrollReference`, `nativeNestedSequence`, and the probe's `paint`/`read`/`keydown`/`keyup`; canonicalized the four existing native test declarations after removing only the new fifth geometry identity argument; byte-compared all existing geometry assertion statements; and scanned the observer AST for focus/scroll/DOM mutation calls and property assignment writes. These finite static checks do not prove rendered behavior.

An earlier version of this one-off AST probe exited 1 because it printed baseline nodes against the current source file, corrupting its own expected text. It had already passed the six function/four probe-member comparisons. The probe was corrected to use each node's own source; no implementation change or browser retry was involved.

* `git diff --check -- tests/ui/virtual-fast-tab.spec.ts tests/ui/post-burst-paint.ts` — exit 0, no output. The new helper was also parsed by TypeScript and by the AST probe.

**Browser acceptance, all nine DOM controls, Chromium/Firefox/WebKit, normal suite, build, and independent review: NOT_RUN by this worker.** The parent will execute the guarded 147-case broad suite and normal verification against the integrated candidate, and arrange a fresh reviewer. No subagent or worktree was created by this worker; unrelated changes and artifacts were preserved.
