"""Positive and negative controls for the publication-only record validator."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from browser_run_proof import RECORDED_SOURCE_ROOT, validate_browser_records, verify_browser_run, verify_release_browsers

P = Path(__file__).resolve().parent

class BrowserRecordControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        load = lambda name: json.loads((P / name).read_text())
        cls.records = {
            'capture': load('cross-browser-runtime-v9-receipt.json'),
            'raw': load('cross-browser-runtime-v9/results.json'),
            'execution': load('cross-browser-runtime-v9/run-receipt.json'),
            'summary': load('cross-browser-runtime-summary.json'),
            'expected': 48, 'per_engine': 16, 'suite': 'runtime',
            'test_scope': {'testDir': 'tests/cross-browser', 'testMatch': ['runtime-cross-browser.spec.ts']},
            'implementation_head': '20761f986c6480546ddf405235b1ddf4faa8b405', 'build_required': False,
            'recorded_source_root': RECORDED_SOURCE_ROOT,
            'raw_hash': sha256((P / 'cross-browser-runtime-v9/results.json').read_bytes()).hexdigest(),
            'capture_hash': sha256((P / 'cross-browser-runtime-v9-receipt.json').read_bytes()).hexdigest(),
            'log_hash': sha256((P / 'cross-browser-runtime-v9.log').read_bytes()).hexdigest(),
        }

    def reject(self, mutation):
        records = deepcopy(self.records)
        mutation(records)
        with self.assertRaises((AssertionError, KeyError)):
            validate_browser_records(**records)

    def reject_raw_file(self, mutation):
        with tempfile.TemporaryDirectory(prefix='ui-record-scope-') as directory:
            target = Path(directory)
            (target / 'cross-browser-runtime-v9').mkdir()
            for name in ['cross-browser-runtime-v9-receipt.json', 'cross-browser-runtime-v9/results.json',
                         'cross-browser-runtime-v9/run-receipt.json', 'cross-browser-runtime-v9.log',
                         'run-existing-bundle.mjs', 'cross-browser-runtime-summary.json']:
                shutil.copy2(P / name, target / name)
            raw = json.loads((target / 'cross-browser-runtime-v9/results.json').read_text())
            mutation(raw)
            raw_bytes = (json.dumps(raw) + '\n').encode()
            (target / 'cross-browser-runtime-v9/results.json').write_bytes(raw_bytes)
            summary = json.loads((target / 'cross-browser-runtime-summary.json').read_text())
            summary['raw_result_sha256'] = sha256(raw_bytes).hexdigest()
            (target / 'cross-browser-runtime-summary.json').write_text(json.dumps(summary) + '\n')
            with self.assertRaises(AssertionError):
                verify_browser_run(target, run_name='cross-browser-runtime-v9',
                    summary_name='cross-browser-runtime-summary.json', expected=48, per_engine=16, suite='runtime',
                    test_scope={'testDir': 'tests/cross-browser', 'testMatch': ['runtime-cross-browser.spec.ts']},
                    implementation_head='20761f986c6480546ddf405235b1ddf4faa8b405', build_required=False)

    @staticmethod
    def first_spec(raw):
        if raw.get('specs'):
            return raw['specs'][0]
        return BrowserRecordControls.first_spec(raw['suites'][0])

    def test_actual_raw_runtime48_and_native180(self):
        proofs = verify_release_browsers(P)
        self.assertEqual({name: proof['passed'] for name, proof in proofs.items()}, {'runtime48': 48, 'native180': 180})

    def test_missing_raw_files_rejected(self):
        with tempfile.TemporaryDirectory(prefix='ui-record-proof-') as directory:
            with self.assertRaises(AssertionError):
                verify_release_browsers(Path(directory))

    def test_filtered_run_rejected(self):
        self.reject(lambda r: r['execution'].update(explicitPlaywrightFilters=['--grep=one']))

    def test_wrong_scope_rejected(self):
        self.reject(lambda r: r['execution'].update(testScope={'testDir': 'tests/cross-browser', 'testMatch': ['other.spec.ts']}))

    def test_missing_attempt_rejected(self):
        self.reject(lambda r: self.first_spec(r['raw'])['tests'][0].update(results=[]))

    def test_partial_case_list_rejected(self):
        self.reject(lambda r: self.first_spec(r['raw'])['tests'].pop())

    def test_duplicate_case_rejected(self):
        self.reject(lambda r: self.first_spec(r['raw'])['tests'].append(deepcopy(self.first_spec(r['raw'])['tests'][0])))

    def test_failed_attempt_rejected(self):
        self.reject(lambda r: self.first_spec(r['raw'])['tests'][0]['results'][0].update(status='failed'))

    def test_expected_failure_rejected(self):
        self.reject(lambda r: self.first_spec(r['raw'])['tests'][0].update(expectedStatus='failed'))

    def test_retry_rejected(self):
        self.reject(lambda r: self.first_spec(r['raw'])['tests'][0]['results'][0].update(retry=1))

    def test_wrong_engine_rejected(self):
        self.reject(lambda r: self.first_spec(r['raw'])['tests'][0].update(projectName='firefox'))

    def test_global_error_rejected(self):
        self.reject(lambda r: r['raw'].update(errors=[{'message': 'controlled error'}]))

    def test_attempt_error_rejected(self):
        self.reject(lambda r: self.first_spec(r['raw'])['tests'][0]['results'][0].update(errors=[{'message': 'controlled error'}]))

    def test_bad_totals_rejected(self):
        def mutate(r):
            r['raw']['stats']['expected'] = r['summary']['stats']['expected'] = 47
        self.reject(mutate)

    def test_skip_flaky_and_unexpected_rejected(self):
        for key in ['skipped', 'flaky', 'unexpected']:
            with self.subTest(key=key):
                def mutate(r):
                    r['raw']['stats'][key] = r['summary']['stats'][key] = 1
                self.reject(mutate)

    def test_stale_raw_execution_time_rejected(self):
        def mutate(r):
            r['raw']['stats']['startTime'] = r['summary']['stats']['startTime'] = '2026-10-17T09:11:32.073Z'
        self.reject(mutate)

    def test_stale_summary_hashes_rejected(self):
        for key in ['raw_result_sha256', 'capture_receipt_sha256', 'log_sha256']:
            with self.subTest(key=key):
                self.reject(lambda r: r['summary'].update({key: '0' * 64}))

    def test_server_left_open_rejected(self):
        self.reject(lambda r: r['execution'].update(serverClosed=False))

    def test_nonzero_native_exit_rejected(self):
        self.reject(lambda r: r['execution']['native'].update(code=1))

    def test_nonzero_capture_exit_rejected(self):
        self.reject(lambda r: r['capture'].update(exit_code=1))

    def test_changed_sources_rejected(self):
        self.reject(lambda r: r['capture'].update(source_changed_during_run=['controlled.ts']))

    def test_not_run_build_is_never_promoted(self):
        self.reject(lambda r: r['execution'].update(build={'code': 0, 'signal': None}))

    def test_raw_root_dir_mismatch_rejected(self):
        self.reject_raw_file(lambda raw: raw['config'].update(rootDir='/unrelated/tests/cross-browser'))

    def test_raw_project_dir_mismatch_rejected(self):
        self.reject_raw_file(lambda raw: raw['config']['projects'][0].update(testDir='/unrelated/tests/cross-browser'))

    def test_raw_match_mismatch_rejected(self):
        self.reject_raw_file(lambda raw: raw['config']['projects'][0].update(testMatch=['unrelated.spec.ts']))

    def test_raw_spec_file_mismatch_rejected(self):
        self.reject_raw_file(lambda raw: self.first_spec(raw).update(file='unrelated.spec.ts'))

    def test_raw_suite_file_mismatch_rejected(self):
        self.reject_raw_file(lambda raw: raw['suites'][0].update(file='unrelated.spec.ts'))

    def test_raw_argv_filter_rejected(self):
        self.reject_raw_file(lambda raw: raw['config']['argv'].append('--grep=one'))

    def test_raw_argv_named_file_rejected(self):
        self.reject_raw_file(lambda raw: raw['config']['argv'].append('unrelated.spec.ts'))

    def test_raw_config_file_mismatch_rejected(self):
        self.reject_raw_file(lambda raw: raw['config'].update(configFile='/unrelated/config.ts'))

    def test_raw_shard_rejected(self):
        self.reject_raw_file(lambda raw: raw['config'].update(shard={'current': 1, 'total': 2}))

    def test_raw_repeat_rejected(self):
        self.reject_raw_file(lambda raw: raw['config']['projects'][0].update(repeatEach=2))

    def test_raw_ignore_rejected(self):
        self.reject_raw_file(lambda raw: raw['config']['projects'][0].update(testIgnore=['ignored.spec.ts']))

    def test_raw_grep_invert_rejected(self):
        self.reject_raw_file(lambda raw: raw['config'].update(grepInvert={}))

    def test_raw_all_checkout_roots_mismatch_rejected(self):
        def mutate(raw):
            original = str(Path(raw['config']['configFile']).parent)
            def replace(value):
                if isinstance(value, dict):
                    return {key: replace(child) for key, child in value.items()}
                if isinstance(value, list):
                    return [replace(child) for child in value]
                if isinstance(value, str):
                    return value.replace(original, '/unrelated/ui-foundation-copy')
                return value
            raw['config'] = replace(raw['config'])
        self.reject_raw_file(mutate)

if __name__ == '__main__':
    unittest.main(verbosity=2)
