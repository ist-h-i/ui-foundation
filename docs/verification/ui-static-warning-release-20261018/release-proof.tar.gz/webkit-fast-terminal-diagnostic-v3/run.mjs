import {spawn,spawnSync} from 'node:child_process';
import {createServer} from 'node:http';
import {connect} from 'node:net';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {resolve,dirname,extname,sep} from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const root=process.cwd(),dir=dirname(fileURLToPath(import.meta.url)),require=createRequire(import.meta.url),receiptPath=resolve(dir,'run-receipt.json');
const priorPath=resolve(dir,'../cross-browser-radio-v10-receipt.json'),prior=JSON.parse(await readFile(priorPath,'utf8'));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
try{await readFile(receiptPath);throw Error('Existing diagnostic receipt: fixed sequence must not rerun.');}catch(error){if(error.code!=='ENOENT')throw error;}
const manifest=async paths=>Object.fromEntries(await Promise.all(paths.map(async path=>[path,sha(await readFile(resolve(root,path)))])));
const head=()=>spawnSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).stdout.trim();
const previousServers=[];
for(const version of ['v1','v2']){const priorReceipt=JSON.parse(await readFile(resolve(dir,'../webkit-fast-terminal-diagnostic-'+version+'/run-receipt.json'),'utf8'));const url=new URL(priorReceipt.origin);const probe=await new Promise(done=>{const socket=connect({host:url.hostname,port:Number(url.port)});socket.setTimeout(1000);socket.once('connect',()=>{socket.destroy();done({listening:true});});socket.once('error',error=>done({listening:false,error:error.code}));socket.once('timeout',()=>{socket.destroy();done({listening:null,error:'timeout'});});});previousServers.push({version,origin:priorReceipt.origin,receiptServerClosed:priorReceipt.serverClosed,probe});}
await writeFile(resolve(dir,'previous-server-probe.json'),JSON.stringify(previousServers,null,2)+'\n');
if(previousServers.some(server=>!server.receiptServerClosed||server.probe.listening!==false||server.probe.error!=='ECONNREFUSED'))throw Error('Prior server closure not confirmed: stopped before launch.');
const sourceBefore=await manifest(Object.keys(prior.source_sha256)),bundleBefore=await manifest(Object.keys(prior.bundle_sha256));
const failureEvidencePath='docs/verification/ui-static-warning-release-20261018/cross-browser-radio-v10/artifacts/virtual-fast-tab-fast-nati-b674a-s-never-exit-before-row-999-webkit/trace.zip';
const failureEvidenceBefore=await manifest([failureEvidencePath]);
if(failureEvidenceBefore[failureEvidencePath]!=='7221c1776582f2c00070fb9c413e32a9d3b3ffbe755438845882a6563fa09200')throw Error('Frozen failure evidence drift: stopped before launch.');
const drift=(expected,actual)=>Object.keys(expected).filter(path=>expected[path]!==actual[path]);
const harnessPaths=(await readdir(dir)).filter(path=>/\.(?:ts|mjs|json)$/.test(path)).map(path=>resolve(dir,path));
const harnessBefore=await manifest(harnessPaths);
const reusedPaths=['docs/verification/ui-static-warning-release-20261018/webkit-fast-terminal-diagnostic-v1/native-blueprint.json','docs/verification/ui-static-warning-release-20261018/webkit-fast-terminal-diagnostic-v1/instrumentation.ts'];
const reusedBefore=await manifest(reusedPaths);
if(reusedBefore[reusedPaths[0]]!=='001c97e93f1842a39876973d1796e8681143498cfda899175666d3591150cbea'||reusedBefore[reusedPaths[1]]!=='f321379700b4bb39d6a26527e7ddc4ef0a0d0e4f758dbd1d35bda73f34f1c532')throw Error('Reused immutable blueprint/helper drift.');
const receipt={startedAtUtc:new Date().toISOString(),headBefore:head(),build:{status:'NOT_RUN',reason:'Authorized diagnostic uses existing compiled guarded fixture'},priorGuardedReceipt:priorPath,priorGuardedReceiptSha256:sha(await readFile(priorPath)),priorGuardedRawSha256:'8792f0452a1c9394a26228788bc7ababa128eea474b4f772389063e89cf0c7a9',expectedHead:'c19aa1137a1ca281e433d4d96b56f27e45099cd8',expectedBundle:'b381a2a994a883ec91cc2c8856cd5d9f9b37715b8a8d46d88711f54f7ae7c27a',sourceBefore,bundleBefore,harnessBefore,reusedBefore,previousServers,failureEvidenceBefore,sourceDriftBefore:drift(prior.source_sha256,sourceBefore),bundleDriftBefore:drift(prior.bundle_sha256,bundleBefore),playwright:require('@playwright/test/package.json').version,engine:'webkit',armsDeclared:['native-only fixed scheduling boundary after997; uninterrupted keys in both groups'],workers:1,retries:0,repeatEach:1,native:'NOT_RUN',serverClosed:false};
const save=()=>writeFile(receiptPath,JSON.stringify(receipt,null,2)+'\n');await save();
if(receipt.headBefore!==receipt.expectedHead||receipt.sourceDriftBefore.length||receipt.bundleDriftBefore.length||bundleBefore['dist/fixture-app/main.js']!==receipt.expectedBundle)throw Error('Source/head/bundle drift: diagnostic stopped before launch.');
const serveRoot=resolve(root,'dist/fixture-app'),mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.woff2':'font/woff2'};
const server=createServer(async(request,response)=>{try{const pathname=decodeURIComponent(new URL(request.url,'http://127.0.0.1').pathname);if(pathname==='/favicon.ico'){response.writeHead(204).end();return;}const path=resolve(serveRoot,'.'+(pathname==='/'||pathname.startsWith('/catalog')?'/index.html':pathname));if(!path.startsWith(serveRoot+sep)){response.writeHead(403).end();return;}response.writeHead(200,{'Content-Type':mime[extname(path)]??'application/octet-stream','Cache-Control':'no-store'}).end(await readFile(path));}catch{response.writeHead(404).end('Not found');}});
try{
 await new Promise((done,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',done);});receipt.origin='http://127.0.0.1:'+server.address().port;await save();
 const cli=resolve(dirname(require.resolve('playwright/package.json')),'cli.js'),args=[cli,'test','-c',resolve(dir,'playwright.config.ts')];receipt.command=[process.execPath,...args];await save();
 receipt.native=await new Promise((done,reject)=>{const child=spawn(process.execPath,args,{cwd:root,env:{...process.env,CI:'1',NODE_PATH:'',UI_WEBKIT_DIAGNOSTIC_URL:receipt.origin,UI_WEBKIT_DIAGNOSTIC_DIR:dir},stdio:'inherit'});child.once('error',reject);child.once('exit',(code,signal)=>done({code,signal}));});process.exitCode=receipt.native.code??1;
}finally{
 server.closeAllConnections();await new Promise(done=>server.close(done));receipt.serverClosed=true;receipt.headAfter=head();receipt.sourceAfter=await manifest(Object.keys(sourceBefore));receipt.bundleAfter=await manifest(Object.keys(bundleBefore));receipt.harnessAfter=await manifest(harnessPaths);receipt.reusedAfter=await manifest(reusedPaths);receipt.reusedDriftAfter=drift(reusedBefore,receipt.reusedAfter);receipt.failureEvidenceAfter=await manifest([failureEvidencePath]);receipt.sourceDriftAfter=drift(sourceBefore,receipt.sourceAfter);receipt.bundleDriftAfter=drift(bundleBefore,receipt.bundleAfter);receipt.harnessDriftAfter=drift(harnessBefore,receipt.harnessAfter);receipt.completedAtUtc=new Date().toISOString();await save();
}
