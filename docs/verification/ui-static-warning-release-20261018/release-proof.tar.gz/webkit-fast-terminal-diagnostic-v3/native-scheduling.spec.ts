import {test,expect,record} from '../../../../tests/ui/css-override-test';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {fingerprintInPage} from '../webkit-fast-terminal-diagnostic-v1/instrumentation';

test('native scheduling terminal C: one fixed frame boundary after row 997',async({page,browser})=>{
 await record('native-engine',{browserVersion:browser.version(),engine:'webkit',worker:1,retries:0,build:'NOT_RUN'});
 const blueprintBytes=await readFile(resolve(process.env.UI_WEBKIT_DIAGNOSTIC_DIR!,'../webkit-fast-terminal-diagnostic-v1/native-blueprint.json'));
 const blueprint=JSON.parse(blueprintBytes.toString('utf8')),oldOrigin=new URL(blueprint.url).origin,newOrigin=process.env.UI_WEBKIT_DIAGNOSTIC_URL!,digest=(bytes:any)=>createHash('sha256').update(bytes).digest('hex');
 const oldBase='<base href="'+oldOrigin+'/catalog/static-runtime">',oldStyles='<link rel="stylesheet" href="'+oldOrigin+'/styles.css">',newBase=oldBase.replace(oldOrigin,newOrigin),newStyles=oldStyles.replace(oldOrigin,newOrigin);
 const positions=[...blueprint.html.matchAll(new RegExp(oldOrigin.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'g'))].map(match=>match.index);
 expect(digest(blueprintBytes)).toBe('001c97e93f1842a39876973d1796e8681143498cfda899175666d3591150cbea');expect(positions).toHaveLength(2);expect(blueprint.html.split(oldBase)).toHaveLength(2);expect(blueprint.html.split(oldStyles)).toHaveLength(2);expect(blueprint.html.includes(newOrigin)).toBe(false);
 const transformedHtml=blueprint.html.replace(oldBase,newBase).replace(oldStyles,newStyles),originOnlyReversible=transformedHtml.replace(newBase,oldBase).replace(newStyles,oldStyles)===blueprint.html;
 expect(originOnlyReversible).toBe(true);
 const repair={oldOrigin,newOrigin,occurrenceCount:positions.length,locations:[{field:'base.href',index:positions[0]},{field:'stylesheet.href',index:positions[1]}],originalBlueprintSha256:digest(blueprintBytes),originalHtmlSha256:digest(blueprint.html),transformedHtmlSha256:digest(transformedHtml),originOnlyReversible,changedCssOrDomGeometry:false};
 await writeFile(resolve(process.env.UI_WEBKIT_DIAGNOSTIC_DIR!,'transformed-native-reference.html'),transformedHtml);await writeFile(resolve(process.env.UI_WEBKIT_DIAGNOSTIC_DIR!,'origin-repair.json'),JSON.stringify(repair,null,2)+'\n');await record('native-origin-repair',repair);
 const response=await fetch(newOrigin+'/styles.css'),stylesBytes=Buffer.from(await response.arrayBuffer()),expectedStylesSha256='fc240658b9995b83293a4b0de48e88a20e26334146d96351e034fe1caede1459',cssProof={url:newOrigin+'/styles.css',status:response.status,byteLength:stylesBytes.length,sha256:digest(stylesBytes),expectedStylesSha256,source:'cross-browser-radio-v10-receipt.json bundle_sha256 dist/fixture-app/styles.css'};
 await writeFile(resolve(process.env.UI_WEBKIT_DIAGNOSTIC_DIR!,'stylesheet-byte-proof.json'),JSON.stringify(cssProof,null,2)+'\n');await record('native-css-byte-proof',cssProof);expect(response.ok).toBe(true);expect(cssProof.sha256).toBe(expectedStylesSha256);
 const network:{url:string;type:string}[]=[];page.on('request',request=>network.push({url:request.url(),type:request.resourceType()}));
 await page.setViewportSize({width:320,height:1000});await page.emulateMedia({reducedMotion:'no-preference'});
 await page.setContent(transformedHtml,{waitUntil:'load'});
 await page.evaluate(blueprint=>{const element=document.querySelector<HTMLElement>('[data-runtime-id] cdk-virtual-scroll-viewport')!;element.scrollTop=blueprint.scrollTop;element.scrollLeft=blueprint.scrollLeft;document.scrollingElement!.scrollTop=blueprint.documentScrollTop;},blueprint);
 // Setup may settle. The key burst below contains only trusted keyboard IPC.
 await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));
 const setup=await page.evaluate(fingerprintInPage);await record('native-source-fingerprint',blueprint.fingerprint);await record('native-setup-fingerprint',setup);
 expect(setup,'listener-free native clone exactly preserves source geometry, CSS and environment').toEqual(blueprint.fingerprint);
 const integrity=await page.evaluate(()=>({scripts:document.scripts.length,applicationRuntime:typeof(window as any).__runtime,inlineHandlers:[...document.querySelectorAll('*')].flatMap(node=>node.getAttributeNames().filter(name=>/^on/i.test(name))),scrollTop:document.querySelector<HTMLElement>('cdk-virtual-scroll-viewport')!.scrollTop}));
 await record('native-integrity',{...integrity,network,browserVersion:browser.version()});expect(integrity.scripts).toBe(0);expect(integrity.applicationRuntime).toBe('undefined');expect(integrity.inlineHandlers).toEqual([]);expect(network.filter(request=>request.type==='script')).toEqual([]);expect(integrity.scrollTop).toBe(blueprint.scrollTop);
 await page.evaluate(()=>{
  const viewport=document.querySelector<HTMLElement>('cdk-virtual-scroll-viewport')!,events:any[]=[],scrolls:any[]=[];
  const identify=(node:Element|null)=>node===viewport?'viewport':node?.closest('[data-ui-virtual-index]')?'row:'+node.closest('[data-ui-virtual-index]')!.getAttribute('data-ui-virtual-index')+':main':node?.id??node?.tagName??null;
  let key:any=null,keyEvent:KeyboardEvent|null=null;
  document.addEventListener('keydown',event=>{if(event.key==='Tab'){keyEvent=event;key={time:performance.now(),active:identify(document.activeElement),trusted:event.isTrusted,shift:event.shiftKey};}},true);
  document.addEventListener('keyup',event=>{if(event.key==='Tab')events.push({time:performance.now(),active:identify(document.activeElement),key:{...key,cancelled:keyEvent!.defaultPrevented},dom:[...viewport.querySelectorAll('[data-ui-virtual-index]')].map(row=>Number(row.getAttribute('data-ui-virtual-index')))});},true);
  viewport.addEventListener('scroll',event=>scrolls.push({time:performance.now(),eventTime:event.timeStamp,trusted:event.isTrusted}),{passive:true});
  (window as any).__nativeTerminal={events,scrolls};
 });
 const sample=()=>page.evaluate(()=>{const element=document.querySelector<HTMLElement>('cdk-virtual-scroll-viewport')!,active=document.activeElement as HTMLElement,box=active.getBoundingClientRect(),viewport=element.getBoundingClientRect();return {time:performance.now(),scrollTop:element.scrollTop,max:element.scrollHeight-element.clientHeight,active:active.getAttribute('aria-label'),activeBox:box.toJSON(),viewport:{top:viewport.top+element.clientTop,bottom:viewport.top+element.clientTop+element.clientHeight},events:[...(window as any).__nativeTerminal.events],scrolls:[...(window as any).__nativeTerminal.scrolls]};});
 await page.locator('#runtime-anchor').focus();
 await page.keyboard.press('Tab');
 for(const row of blueprint.fingerprint.rows.slice(0,4))await page.keyboard.press('Tab');
 // Scheduling experiment only: exactly one declared rendering boundary after 997.
 const boundary=await page.evaluate(()=>new Promise<any>(resolve=>{const started=performance.now();requestAnimationFrame(firstFrame=>requestAnimationFrame(secondFrame=>{const element=document.querySelector<HTMLElement>('cdk-virtual-scroll-viewport')!,active=document.activeElement as HTMLElement,box=active.getBoundingClientRect(),viewport=element.getBoundingClientRect();resolve({started,firstFrame,secondFrame,time:performance.now(),scrollTop:element.scrollTop,max:element.scrollHeight-element.clientHeight,active:active.getAttribute('aria-label'),activeBox:box.toJSON(),viewport:{top:viewport.top+element.clientTop,bottom:viewport.top+element.clientTop+element.clientHeight},scrolls:[...(window as any).__nativeTerminal.scrolls]});}));}));
 const centeredRow=blueprint.fingerprint.rows.find((row:any)=>row.index===997),expectedCenteredScroll=centeredRow.rect.contentTop+centeredRow.input.rect.top+centeredRow.input.rect.height/2-blueprint.fingerprint.viewport.clientHeight/2;
 const boundaryCentered997=boundary.active==='再検証入力 997'&&boundary.scrollTop===expectedCenteredScroll&&(boundary.activeBox.top+boundary.activeBox.bottom)/2===(boundary.viewport.top+boundary.viewport.bottom)/2;
 await record('native-declared-997-boundary',{...boundary,expectedCenteredScroll,boundaryCentered997,acceptance:false});
 for(const row of blueprint.fingerprint.rows.slice(4))await page.keyboard.press('Tab');
 // FIRST browser evaluate after the final two keys: immutable immediate geometry.

 const immediate=await sample();await record('native-immutable-immediate',immediate);
 const after=await page.evaluate(fingerprintInPage);await record('native-post-burst-fingerprint',after);
 expect(after,'source-equivalent structural geometry remains unchanged after the native burst').toEqual(blueprint.fingerprint);
 const expected=['viewport',...blueprint.fingerprint.rows.map((row:any)=>'row:'+row.index+':main')];
 expect(immediate.events).toHaveLength(expected.length);
 for(const [index,active]of expected.entries()){const event=immediate.events[index];expect(event.active).toBe(active);expect(event.key.trusted).toBe(true);expect(event.key.cancelled).toBe(false);expect(event.key.shift).toBe(false);expect(event.dom).toEqual(blueprint.fingerprint.rows.map((row:any)=>row.index));expect(event.dom.length).toBeLessThanOrEqual(blueprint.limit);}
 await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));
 const deferred=await sample();await record('native-two-post-burst-frames',deferred);
 await record('native-classification',{referenceValid:true,expectedKeys:expected.length,observedKeys:immediate.events.length,immediateVisible:immediate.activeBox.top<immediate.viewport.bottom&&immediate.activeBox.bottom>immediate.viewport.top,deferredVisible:deferred.activeBox.top<deferred.viewport.bottom&&deferred.activeBox.bottom>deferred.viewport.top,visibilityIsObservationOnly:true,sourceFailureRemainsUnchanged:true,controlledSchedulingExperiment:true,unpacedApplicationAcceptance:false,boundaryCentered997,expectedCenteredScroll,immediateOffscreenThenDeferredVisible:!(immediate.activeBox.top<immediate.viewport.bottom&&immediate.activeBox.bottom>immediate.viewport.top)&&deferred.activeBox.top<deferred.viewport.bottom&&deferred.activeBox.bottom>deferred.viewport.top});
});
