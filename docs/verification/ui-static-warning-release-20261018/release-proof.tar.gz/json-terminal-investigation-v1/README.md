# R161 B JsonViewer terminal diagnostic — prepared, NOT_RUN

Preparation only: `node --check diagnose.mjs` exited 0. No browser, build, UI test, package installation, Git mutation, or existing evidence modification was performed by this preparer. Main owns execution after the normal UI process has fully exited.

Pinned repository: `/Users/inouehiroshi/Documents/GitHub/ui-foundation`; branch `feat/ui-static-warning-release`; base `b4aea63f67447dda1cabcf2da749617aa39c2d6f`; HEAD `88a72c2a94f6649a935d764166d83fe6d45b2758`. `inputs.sha256.json` identifies the source contracts and existing compiled bundle. Build is explicitly `NOT_RUN`; any pin mismatch stops before browser launch.

| File | SHA256 |
| --- | --- |
| `diagnose.mjs` | `16b1fc660e0cb10a665acca8bb2162e55fe801d1d98e01441623c3ff31fe8ffe` |
| `inputs.sha256.json` | `67ca4bdf6132f079ef0804dd6a650bad263c362e510c46cd227c597c4cf67391` |
| existing `dist/fixture-app/main.js` | `b381a2a994a883ec91cc2c8856cd5d9f9b37715b8a8d46d88711f54f7ae7c27a` |

Run once from the repository root, optionally setting `JSON_TERMINAL_TRACE=1` for three traces without screenshots:

```sh
node docs/verification/ui-static-warning-release-20261018/json-terminal-investigation-v1/diagnose.mjs
```

The script creates an exclusive `run.claim.json`; it refuses any subsequent invocation, including after an incomplete attempt. Do not delete the claim to retry. Output uses a new `run-<timestamp>-<uuid>/` directory, exclusive file creation, `raw.json`, append-only `journal.jsonl`, the serialized `native-dom-clone.html`, and optional per-arm traces. Existing evidence is never overwritten.

The fixed order is:

1. Actual unchanged compiled fixture, original scroll action sequence.
2. Scripts-free native DOM clone of the same rendered/styled fixture, original scroll action sequence. Full document structure, Angular style attributes, style tags and stylesheet links are retained; script elements and inline handlers are removed. A separate browser context and `script-src 'none'` CSP keep document/application scripts absent. The harness verifies no `__runtime`, no script elements, no inline handlers, and matching text, rows, computed styles and geometry before starting. Automation evaluation remains enabled to observe and drive native DOM.
3. Fresh actual fixture, same action sequence with one proposed gate: after the original `scrollTop > 0` poll, poll `abs(scrollHeight - clientHeight - scrollTop) <= 1` before the existing explicit maximum writes.

Each arm uses one instance for 3 then 5 columns, once each, at dense/320×1000/font 200%/RTL/reduced-motion B. The action order and options from `tests/ui/static-runtime-reassessment-layout.spec.ts:208` are preserved: native anchor click and trusted Tab focus, End, positive-position poll, explicit maxima, last-cell `scrollIntoView({block:'end',inline:'end'})`, horizontal `scrollBy({behavior:'instant'})`, two RAFs, then the first endpoint measurement. The original minimum-width checks, last text, focus-ring checks and four endpoint predicates remain, including the original 1 px containment tolerance. A failed predicate is recorded rather than filtering out the arm or retrying it. The update/search tail after the scroll loop is outside this diagnostic.

This is an instrumented action-order replay. RAF geometry/event sampling begins before End, so it may perturb timing; it is not an uninstrumented exact replay. After the immutable first two-RAF measurement, a bounded 1500 ms read-only RAF interval continues to observe motion. It never scrolls, replaces that measurement, waits after each key, changes CSS/app scrolling policies, or selects a later successful frame. Raw samples contain timestamps, scrollTop/max, endpoint/viewport rectangles, root position, focus, scroll behavior, trusted key/focus events and browser/runtime errors. The script records both legacy failures and non-reproduction honestly; neither a passing gate nor native-clone agreement establishes an exact cause.

The harness uses only existing local `@playwright/test` and installed Chromium (`channel:'chromium'`), starts its own ephemeral HTTP listener on `127.0.0.1`, checks pins again afterward, and closes its contexts/browser/server in `finally`. It handles only its own resources, with a 180 s overall deadline and bounded polls/observations. Exit 0 means all six first measurements were recorded with clean infrastructure/runtime checks; endpoint assertion outcomes remain separate in `assertionSummary`. Exit 2 means refused/incomplete/error. Syntax checking alone does not establish runtime correctness or any browser outcome.
