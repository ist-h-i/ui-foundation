import {createHash, randomUUID} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {appendFileSync, mkdirSync, openSync, closeSync, readFileSync, writeFileSync} from 'node:fs';
import {readFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {dirname, extname, resolve, sep} from 'node:path';
import {fileURLToPath} from 'node:url';

// Standalone diagnostic: no test(), build, package installation, retry, or CSS policy patch.
const here = dirname(fileURLToPath(import.meta.url));
const repository = resolve(here, '../../../..');
const contract = JSON.parse(readFileSync(resolve(here, 'inputs.sha256.json'), 'utf8'));
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const source = JSON.stringify(Object.fromEntries(Array.from({length: 24}, (_, i) => ['申請項目' + i, '保持する長文 ' + i + ' ABCDEFGHIJ '.repeat(6)])));
const contextB = {name: 'B', profile: 'dense', width: 320, height: 1000, font: '200%', dir: 'rtl', motion: 'reduce'};
const limits = {totalMs: 180_000, actionMs: 10_000, pollMs: 5_000, postMeasurementMs: 1_500, rafSamplesPerCase: 1_200, tabs: 40};
const armContracts = [
  {id: 'actual-original', fixture: 'actual', terminalGate: false},
  {id: 'native-clone-original', fixture: 'native-dom-clone', terminalGate: false},
  {id: 'actual-end-terminal-gate', fixture: 'actual', terminalGate: true},
];
const result = {
  schemaVersion: 1, kind: 'R161-B-JsonViewer-terminal-diagnostic', startedAt: new Date().toISOString(),
  build: 'NOT_RUN', browserRunsBeforeInvocation: 'NOT_RUN_BY_THIS_SCRIPT', contract, context: contextB, limits,
  scriptSha256: sha256(readFileSync(fileURLToPath(import.meta.url))),
  inputManifestSha256: sha256(readFileSync(resolve(here, 'inputs.sha256.json'))),
  sourceSha256: sha256(Buffer.from(source)), columns: [3, 5], arms: [], errors: [],
  operationalStatus: 'NOT_STARTED', assertionSummary: null, cleanup: {},
  interpretation: [
    'The FIRST measurement after the original two RAFs is immutable evidence, even if failed or not reproduced.',
    'Later RAF samples are observation only; no replacement measurement, rerun, or success selection occurs.',
    'Native clone removes document/application scripts and runtime, while automation evaluation still observes and drives native DOM.',
    'Read-only geometry/event/RAF instrumentation and optional tracing can affect timing; this is a bounded diagnostic, not the normal test run.',
    'A non-reproduction or a matching native-clone outcome does not identify an exact cause.',
    'Exit zero means all six cases were recorded; consult strict assertions separately. The original update/search tail is outside this scroll diagnostic.',
  ],
};
let browser, server, journalFd, runDirectory, cancelled = false;
let nativeClone = null;
let expect;
const contexts = new Set();
const serializeError = error => ({name: error?.name ?? 'Error', message: error?.message ?? String(error), stack: error?.stack ?? null});
const journal = (type, data) => {
  if (journalFd !== undefined) appendFileSync(journalFd, JSON.stringify({at: new Date().toISOString(), type, data}) + '\n');
};
function assertActive() {if (cancelled) throw new Error('Diagnostic cancelled; no further arms may start');}
function recordAssertion(target, name, assertion) {
  try {assertion();target.assertions.push({name, passed: true});}
  catch (error) {target.assertions.push({name, passed: false, error: serializeError(error)});}
}
function inputSnapshot() {
  const files = {};
  for (const [name, expected] of Object.entries(contract.files)) {
    const actual = sha256(readFileSync(resolve(repository, name)));
    files[name] = {expected, actual, matches: actual === expected};
  }
  return {
    repository,
    head: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: repository, encoding: 'utf8'}).trim(),
    branch: execFileSync('git', ['branch', '--show-current'], {cwd: repository, encoding: 'utf8'}).trim(),
    files,
  };
}
function requirePinned(snapshot) {
  if (snapshot.repository !== contract.repository || snapshot.head !== contract.head || snapshot.branch !== contract.branch ||
      Object.values(snapshot.files).some(file => !file.matches)) throw new Error('Pinned repository/head/branch/input mismatch; build and browser execution refused');
}
async function startServer() {
  const root = resolve(repository, 'dist/fixture-app');
  const mime = {'.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.woff': 'font/woff', '.woff2': 'font/woff2', '.wasm': 'application/wasm', '.png': 'image/png'};
  result.serverRequests = [];
  server = createServer(async (request, response) => {
    try {
      const pathname = decodeURIComponent(new URL(request.url, 'http://127.0.0.1').pathname);
      result.serverRequests.push({at: new Date().toISOString(), method: request.method, pathname});
      if (pathname === '/favicon.ico') {response.writeHead(204).end();return;}
      if (pathname === '/native-dom-clone.html') {
        if (nativeClone === null) {response.writeHead(404).end('Clone not prepared');return;}
        response.writeHead(200, {'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store',
          'Content-Security-Policy': "default-src 'self' data: blob:; script-src 'none'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'none'; object-src 'none'; frame-src 'none'"});
        response.end(nativeClone);return;
      }
      const relative = pathname === '/' || pathname === '/catalog' || pathname.startsWith('/catalog/') ? '/index.html' : pathname;
      const candidate = resolve(root, '.' + relative);
      if (!candidate.startsWith(root + sep)) {response.writeHead(403).end();return;}
      const body = await readFile(candidate);
      response.writeHead(200, {'Content-Type': mime[extname(candidate)] ?? 'application/octet-stream', 'Cache-Control': 'no-store'});
      response.end(body);
    } catch (error) {response.writeHead(404).end('Not found');journal('server-read-error', serializeError(error));}
  });
  await new Promise((resolveListening, reject) => {server.once('error', reject);server.listen(0, '127.0.0.1', resolveListening);});
  const address = server.address();
  if (typeof address !== 'object' || !address) throw new Error('Owned server did not return a TCP address');
  result.server = {host: '127.0.0.1', port: address.port, owned: true, root};
  return `http://127.0.0.1:${address.port}`;
}
async function settle(page) {
  await page.evaluate(() => new Promise(resolveFrame => requestAnimationFrame(() => requestAnimationFrame(resolveFrame))));
}
function attachErrors(page, arm, label) {
  const entries = [];
  arm.pages ??= [];arm.pages.push({label, errors: entries});
  page.on('pageerror', error => entries.push({kind: 'pageerror', ...serializeError(error)}));
  page.on('console', message => {if (message.type() === 'error' || message.type() === 'warning') entries.push({kind: 'console-' + message.type(), text: message.text()});});
  page.on('requestfailed', request => entries.push({kind: 'requestfailed', url: request.url(), failure: request.failure()}));
  return entries;
}
async function newContext(device) {
  assertActive();
  const browserContext = await browser.newContext({...device});
  contexts.add(browserContext);browserContext.setDefaultTimeout(limits.actionMs);browserContext.setDefaultNavigationTimeout(30_000);
  return browserContext;
}
async function prepareActual(page, origin) {
  await page.goto(origin + '/catalog/static-runtime');
  await expect.poll(() => page.evaluate(() => typeof window.__runtime?.create), {timeout: limits.pollMs}).toBe('function');
  await page.setViewportSize({width: contextB.width, height: contextB.height});
  await page.emulateMedia({reducedMotion: contextB.motion});
  await page.evaluate(c => {
    document.documentElement.style.fontSize = c.font;document.documentElement.dir = c.dir;
    const main = document.querySelector('main');main.setAttribute('data-ui-profile', c.profile);main.style.padding = '0';
  }, contextB);
  await settle(page);
  await page.locator('#runtime-slot').evaluate(slot => {slot.style.padding = 'calc(var(--ui-border-focus) + var(--ui-border-focus-offset))';slot.style.boxSizing = 'border-box';});
  await settle(page);
  const id = await page.evaluate(source => window.__runtime.create('JsonViewer', {label: '実consumerの階層', source}), source);
  const node = page.locator(`[data-runtime-id="${id}"]`);
  await expect(node.locator('tbody tr').last().locator('td').last()).toContainText('保持する長文 23');
  return {id, node, viewport: node.getByRole('region', {name: '実consumerの階層の階層', exact: true}), table: node.locator('table.ui-specialist-data-table')};
}
async function layoutSnapshot(page, fixture) {
  return fixture.node.evaluate(node => {
    const region = node.querySelector('.ui-specialist-scroll'), table = node.querySelector('table'), code = node.querySelector('tbody tr:last-child td:last-child code');
    const properties = ['direction', 'font-size', 'font-family', 'line-height', 'width', 'height', 'min-width', 'max-height', 'overflow-x', 'overflow-y', 'scroll-behavior', 'padding-left', 'padding-right', 'padding-top', 'padding-bottom', 'box-sizing', '--ui-size-table-viewport', '--ui-specialist-columns'];
    const item = el => ({box: el.getBoundingClientRect().toJSON(), clientWidth: el.clientWidth, clientHeight: el.clientHeight, scrollWidth: el.scrollWidth, scrollHeight: el.scrollHeight,
      style: Object.fromEntries(properties.map(property => [property, getComputedStyle(el).getPropertyValue(property)]))});
    return {host: item(node), region: item(region), table: item(table), code: item(code),
      root: {fontSize: getComputedStyle(document.documentElement).fontSize, direction: document.documentElement.dir, profile: document.querySelector('main').getAttribute('data-ui-profile'), scrollX, scrollY, innerWidth, innerHeight},
      rows: table.tBodies[0].rows.length, text: table.textContent, scriptCount: document.scripts.length, runtimeType: typeof window.__runtime,
      inlineEventAttributes: [...document.querySelectorAll('*')].flatMap(el => [...el.attributes].filter(a => /^on/i.test(a.name)).map(a => ({tag: el.tagName, name: a.name}))),
      stylesheets: [...document.styleSheets].map(sheet => ({href: sheet.href, rules: [...sheet.cssRules].map(rule => rule.cssText).join('\n')}))};
  });
}
async function prepareClone(origin, device, arm) {
  const seedContext = await newContext(device), seed = await seedContext.newPage();
  attachErrors(seed, arm, 'clone-source-actual');
  try {
    const fixture = await prepareActual(seed, origin);
    arm.cloneSourceBefore = await layoutSnapshot(seed, fixture);
    const serialized = await seed.evaluate(() => {
      const documentCopy = document.documentElement.cloneNode(true);
      const scripts = [...documentCopy.querySelectorAll('script')];scripts.forEach(script => script.remove());
      const removedHandlers = [];
      for (const element of documentCopy.querySelectorAll('*')) for (const attribute of [...element.attributes]) {
        if (/^on/i.test(attribute.name)) {removedHandlers.push({tag: element.tagName, name: attribute.name});element.removeAttribute(attribute.name);}
        if (/^(href|src)$/i.test(attribute.name) && /^javascript:/i.test(attribute.value)) throw new Error('Unexpected script URL in native clone source');
      }
      if (documentCopy.querySelector('iframe,object,embed,meta[http-equiv="refresh"]')) throw new Error('Unexpected active document surface in native clone source');
      return {html: '<!doctype html>\n' + documentCopy.outerHTML, removedScripts: scripts.length, removedHandlers};
    });
    nativeClone = serialized.html;
    arm.cloneSerialization = {...serialized, html: undefined, sha256: sha256(Buffer.from(nativeClone)), sourceRuntimeId: fixture.id};
    writeFileSync(resolve(runDirectory, 'native-dom-clone.html'), nativeClone, {flag: 'wx'});
    arm.cloneSourceRuntimeBeforeDestroy = await seed.evaluate(id => window.__runtime.inspect(id), fixture.id);
    await seed.evaluate(id => window.__runtime.destroy(id), fixture.id);
    arm.cloneSourceRuntimeAfterDestroy = await seed.evaluate(id => window.__runtime.inspect(id), fixture.id);
    const browserContext = await newContext(device), page = await browserContext.newPage();
    attachErrors(page, arm, 'native-clone');
    await page.setViewportSize({width: contextB.width, height: contextB.height});await page.emulateMedia({reducedMotion: contextB.motion});
    const response = await page.goto(origin + '/native-dom-clone.html');
    arm.cloneCsp = response.headers()['content-security-policy'];await settle(page);
    const node = page.locator(`[data-runtime-id="${fixture.id}"]`);
    const cloneFixture = {id: fixture.id, node, viewport: node.getByRole('region', {name: '実consumerの階層の階層', exact: true}), table: node.locator('table.ui-specialist-data-table')};
    arm.cloneBefore = await layoutSnapshot(page, cloneFixture);
    recordAssertion(arm, 'native clone has no document scripts', () => expect(arm.cloneBefore.scriptCount).toBe(0));
    recordAssertion(arm, 'native clone has no __runtime', () => expect(arm.cloneBefore.runtimeType).toBe('undefined'));
    recordAssertion(arm, 'native clone has no inline event handlers', () => expect(arm.cloneBefore.inlineEventAttributes).toEqual([]));
    recordAssertion(arm, 'native clone text/rows/root/styles match source', () => {
      for (const key of ['text', 'rows', 'root']) expect(arm.cloneBefore[key]).toEqual(arm.cloneSourceBefore[key]);
      expect(arm.cloneBefore.stylesheets).toEqual(arm.cloneSourceBefore.stylesheets);
    });
    for (const name of ['host', 'region', 'table', 'code']) recordAssertion(arm, 'native clone ' + name + ' layout/style matches source', () => {
      const actual = arm.cloneBefore[name], expected = arm.cloneSourceBefore[name];
      expect(actual.style).toEqual(expected.style);
      for (const key of ['clientWidth', 'clientHeight', 'scrollWidth', 'scrollHeight']) expect(actual[key]).toBe(expected[key]);
      for (const key of ['left', 'right', 'top', 'bottom', 'width', 'height']) expect(Math.abs(actual.box[key] - expected.box[key])).toBeLessThanOrEqual(1);
    });
    if (arm.assertions.some(assertion => !assertion.passed)) throw new Error('Native clone equivalence/precondition failed; native sequence is not comparable');
    return {page, browserContext, fixture: cloneFixture};
  } finally {await seedContext.close();contexts.delete(seedContext);}
}
async function installObservation(page, fixture) {
  await fixture.viewport.evaluate(viewport => {
    const state = {current: null, cases: {}, rafId: 0};
    function read() {
      const cell = viewport.querySelector('tbody tr:last-child td:last-child'), text = cell.querySelector('code').firstChild, range = document.createRange();
      range.setStart(text, Math.max(0, text.textContent.length - 1));range.setEnd(text, text.textContent.length);
      return {now: performance.now(), scrollTop: viewport.scrollTop, scrollLeft: viewport.scrollLeft,
        scrollHeight: viewport.scrollHeight, clientHeight: viewport.clientHeight, max: viewport.scrollHeight - viewport.clientHeight,
        remaining: viewport.scrollHeight - viewport.clientHeight - viewport.scrollTop, scrollWidth: viewport.scrollWidth, clientWidth: viewport.clientWidth,
        endpoint: range.getBoundingClientRect().toJSON(), viewport: viewport.getBoundingClientRect().toJSON(),
        root: {x: scrollX, y: scrollY}, focused: document.activeElement === viewport,
        scrollBehavior: getComputedStyle(viewport).scrollBehavior};
    }
    state.begin = key => {state.current = key;state.cases[key] = {events: [], samples: [], marks: []};};
    state.mark = label => {const entry = state.cases[state.current];if (entry) entry.marks.push({label, ...read()});};
    state.start = maxSamples => {
      const key = state.current, entry = state.cases[key];entry.started = performance.now();state.mark('before-End');
      const frame = timestamp => {if (state.current !== key || entry.stopped || entry.samples.length >= maxSamples) return;
        entry.samples.push({rafTimestamp: timestamp, elapsed: performance.now() - entry.started, ...read()});state.rafId = requestAnimationFrame(frame);};
      state.rafId = requestAnimationFrame(frame);
    };
    state.stop = () => {const entry = state.cases[state.current];entry.stopped = performance.now();cancelAnimationFrame(state.rafId);state.mark('observation-finished');return entry;};
    for (const type of ['keydown', 'keyup', 'focusin', 'scroll', 'scrollend']) document.addEventListener(type, event => {
      const entry = state.cases[state.current];if (!entry || entry.events.length >= 1_000) return;
      if ((type === 'scroll' || type === 'scrollend') && event.target !== viewport) return;
      entry.events.push({type, key: event.key ?? null, trusted: event.isTrusted, now: performance.now(), targetIsRegion: event.target === viewport,
        tag: event.target?.tagName ?? null, id: event.target?.id ?? null, role: event.target?.getAttribute?.('role') ?? null, scrollTop: viewport.scrollTop, max: viewport.scrollHeight - viewport.clientHeight});
    }, {capture: true, passive: true});
    window.__jsonTerminalInvestigation = state;
  });
}
async function ring(node) {
  const value = await node.evaluate(el => {
    const style = getComputedStyle(el), box = el.getBoundingClientRect();
    const reach = Math.max(0, parseFloat(style.outlineWidth) + parseFloat(style.outlineOffset));
    const clip = {left: 0, top: 0, right: innerWidth, bottom: innerHeight};const ancestors = [];
    for (let parent = el.parentElement; parent; parent = parent.parentElement) {
      const s = getComputedStyle(parent), r = parent.getBoundingClientRect();
      if (/auto|scroll|hidden|clip/.test(s.overflowX)) {clip.left = Math.max(clip.left, r.left + parent.clientLeft);clip.right = Math.min(clip.right, r.left + parent.clientLeft + parent.clientWidth);}
      if (/auto|scroll|hidden|clip/.test(s.overflowY)) {clip.top = Math.max(clip.top, r.top + parent.clientTop);clip.bottom = Math.min(clip.bottom, r.top + parent.clientTop + parent.clientHeight);}
      if (/auto|scroll|hidden|clip/.test(s.overflowX + ' ' + s.overflowY)) ancestors.push({tag: parent.tagName, class: parent.className, overflowX: s.overflowX, overflowY: s.overflowY, box: r.toJSON(), clientWidth: parent.clientWidth, clientHeight: parent.clientHeight});
    }
    const hit = document.elementFromPoint(box.x + box.width / 2, box.y + box.height / 2);
    return {focus: el.matches(':focus-visible'), width: parseFloat(style.outlineWidth), style: style.outlineStyle, color: style.outlineColor,
      offset: parseFloat(style.outlineOffset), extent: reach, hit: hit === el || !!hit && el.contains(hit), box: box.toJSON(), clip, ancestors,
      inside: box.left - reach >= clip.left - 1 && box.right + reach <= clip.right + 1 && box.top - reach >= clip.top - 1 && box.bottom + reach <= clip.bottom + 1};
  });
  return value;
}
async function nativeFocus(page, node, caseResult) {
  await page.locator('#runtime-anchor').click();caseResult.tabs = 0;
  for (let step = 0; step < limits.tabs; step++) {await page.keyboard.press('Tab');caseResult.tabs++;if (await node.evaluate(el => el === document.activeElement)) break;}
  await expect(node).toBeFocused();caseResult.focusRing = await ring(node);
  recordAssertion(caseResult, 'native Tab focus ring (original predicates)', () => {
    const value = caseResult.focusRing;expect(value.focus).toBe(true);expect(value.width).toBeGreaterThan(0);expect(value.style).not.toBe('none');
    expect(value.color).not.toBe('rgba(0, 0, 0, 0)');expect(value.hit).toBe(true);expect(value.inside).toBe(true);
  });
}
async function runColumn(page, fixture, arm, columns) {
  const caseResult = {columns, assertions: [], errors: [], first2RafMeasurement: null, observation: null, execution: 'STARTED'};
  arm.cases.push(caseResult);journal('case-started', {arm: arm.id, columns});
  try {
    await page.evaluate(key => window.__jsonTerminalInvestigation.begin(key), arm.id + '-' + columns);
    await fixture.table.evaluate((el, columns) => el.style.setProperty('--ui-specialist-columns', String(columns), 'important'), columns);
    await fixture.node.evaluate(el => el.style.inlineSize = '240px');await settle(page);
    const dimensions = await fixture.table.evaluate(el => {
      const style = getComputedStyle(el), parent = el.parentElement, unit = document.createElement('span');
      unit.style.cssText = 'position:absolute;visibility:hidden;inline-size:max(var(--ui-size-table-column-min),calc(8em + var(--ui-space-table-x) * 2));';
      el.append(unit);const minimum = unit.getBoundingClientRect().width;unit.remove();
      return {minimum, width: el.getBoundingClientRect().width, minWidth: parseFloat(style.minWidth), client: parent.clientWidth, scroll: parent.scrollWidth};
    });
    caseResult.dimensions = dimensions;
    recordAssertion(caseResult, 'original table minimum and horizontal overflow predicates', () => {
      expect(Math.abs(dimensions.minWidth - dimensions.minimum * columns)).toBeLessThanOrEqual(1);
      expect(dimensions.width).toBeGreaterThanOrEqual(dimensions.minWidth - 1);expect(dimensions.scroll).toBeGreaterThan(dimensions.client);
    });
    await nativeFocus(page, fixture.viewport, caseResult);
    await page.evaluate(maxSamples => window.__jsonTerminalInvestigation.start(maxSamples), limits.rafSamplesPerCase);
    await fixture.viewport.press('End');
    caseResult.endPositivePoll = [];
    await expect.poll(async () => {
      const value = await fixture.viewport.evaluate(el => ({now: performance.now(), scrollTop: el.scrollTop, max: el.scrollHeight - el.clientHeight}));
      caseResult.endPositivePoll.push(value);return value.scrollTop;
    }, {timeout: limits.pollMs}).toBeGreaterThan(0);
    if (arm.terminalGate) {
      caseResult.endTerminalPoll = [];
      await expect.poll(async () => {
        const value = await fixture.viewport.evaluate(el => ({now: performance.now(), scrollTop: el.scrollTop, max: el.scrollHeight - el.clientHeight, distance: Math.abs(el.scrollHeight - el.clientHeight - el.scrollTop)}));
        caseResult.endTerminalPoll.push(value);return value.distance;
      }, {timeout: limits.pollMs}).toBeLessThanOrEqual(1);
    }
    // These writes and the following endpoint correction preserve the original order and options.
    caseResult.explicitMaxWrite = await fixture.viewport.evaluate(el => {
      el.scrollLeft = getComputedStyle(el).direction === 'rtl' ? -el.scrollWidth : el.scrollWidth;el.scrollTop = el.scrollHeight;
      window.__jsonTerminalInvestigation.mark('explicit-max-write');return {now: performance.now(), scrollTop: el.scrollTop, scrollLeft: el.scrollLeft, max: el.scrollHeight - el.clientHeight};
    });
    const last = fixture.node.locator('tbody tr').last().locator('td').last();await expect(last).toContainText('保持する長文 23');
    caseResult.endpointCorrection = await last.evaluate(el => {
      el.scrollIntoView({block: 'end', inline: 'end'});
      const text = el.querySelector('code').firstChild, range = document.createRange();
      range.setStart(text, Math.max(0, (text.textContent?.length ?? 1) - 1));range.setEnd(text, text.textContent.length);
      const endpoint = range.getBoundingClientRect(), viewport = el.closest('.ui-specialist-scroll'), view = viewport.getBoundingClientRect();
      const left = endpoint.right > view.right ? endpoint.right - view.right + 2 : endpoint.left < view.left ? endpoint.left - view.left - 2 : 0;
      viewport.scrollBy({left, behavior: 'instant'});window.__jsonTerminalInvestigation.mark('after-scrollIntoView-and-horizontal-correction');
      return {left, now: performance.now(), scrollTop: viewport.scrollTop, scrollLeft: viewport.scrollLeft, max: viewport.scrollHeight - viewport.clientHeight};
    });
    await settle(page);
    // This is the first and only assertion measurement. Do not replace it with later samples.
    caseResult.first2RafMeasurement = await last.evaluate(el => {
      const text = el.querySelector('code').firstChild, range = document.createRange();range.setStart(text, Math.max(0, text.textContent.length - 1));range.setEnd(text, text.textContent.length);
      const viewport = el.closest('.ui-specialist-scroll');return {last: range.getBoundingClientRect().toJSON(), view: viewport.getBoundingClientRect().toJSON(),
        now: performance.now(), scrollTop: viewport.scrollTop, scrollLeft: viewport.scrollLeft, scrollHeight: viewport.scrollHeight, clientHeight: viewport.clientHeight, max: viewport.scrollHeight - viewport.clientHeight};
    });
    const end = caseResult.first2RafMeasurement;
    recordAssertion(caseResult, 'endpoint width > 0 (original)', () => expect(end.last.width).toBeGreaterThan(0));
    recordAssertion(caseResult, 'endpoint bottom <= viewport bottom + 1px (original)', () => expect(end.last.bottom).toBeLessThanOrEqual(end.view.bottom + 1));
    recordAssertion(caseResult, 'endpoint right <= viewport right + 1px (original)', () => expect(end.last.right).toBeLessThanOrEqual(end.view.right + 1));
    recordAssertion(caseResult, 'endpoint left >= viewport left - 1px (original)', () => expect(end.last.left).toBeGreaterThanOrEqual(end.view.left - 1));
    journal('first-two-raf-result', {arm: arm.id, columns, first2RafMeasurement: end, assertions: caseResult.assertions});
    // Earlier RAF sampling began before End. Continue observation after freezing the first result;
    // this read-only post-measurement interval never drives another scroll or replaces the result.
    await page.evaluate(ms => new Promise(resolveObservation => {
      const started = performance.now();let complete = false;
      const finish = () => {if (!complete) {complete = true;clearTimeout(bound);resolveObservation();}};
      const observe = () => {if (complete) return;if (performance.now() - started >= ms) finish();else requestAnimationFrame(observe);};
      const bound = setTimeout(finish, ms + 500);requestAnimationFrame(observe);
    }), limits.postMeasurementMs);
    caseResult.execution = 'FIRST_MEASUREMENT_RECORDED';
  } catch (error) {caseResult.errors.push(serializeError(error));caseResult.execution = 'INCOMPLETE';}
  finally {
    try {caseResult.observation = await page.evaluate(() => window.__jsonTerminalInvestigation.stop());}
    catch (error) {caseResult.errors.push({phase: 'observation-cleanup', ...serializeError(error)});}
    const events = caseResult.observation?.events ?? [];
    recordAssertion(caseResult, 'trusted End keydown delivered to focused region', () => {
      expect(events.some(event => event.type === 'keydown' && event.key === 'End' && event.trusted && event.targetIsRegion)).toBe(true);
    });
    recordAssertion(caseResult, 'trusted Tab and native focus events reached region', () => {
      expect(events.some(event => event.type === 'keydown' && event.key === 'Tab' && event.trusted)).toBe(true);
      expect(events.some(event => event.type === 'focusin' && event.trusted && event.targetIsRegion)).toBe(true);
    });
    journal('case-finished', {arm: arm.id, ...caseResult});
  }
}
async function runArm(origin, device, armContract) {
  assertActive();
  const arm = {...armContract, startedAt: new Date().toISOString(), cases: [], assertions: [], pages: [], errors: [], trace: 'NOT_REQUESTED', execution: 'STARTED'};
  result.arms.push(arm);journal('arm-started', armContract);
  let page, fixture, browserContext, tracing = false;
  try {
    if (arm.fixture === 'native-dom-clone') ({page, fixture, browserContext} = await prepareClone(origin, device, arm));
    else {browserContext = await newContext(device);page = await browserContext.newPage();attachErrors(page, arm, 'actual');
      if (process.env.JSON_TERMINAL_TRACE === '1') {await browserContext.tracing.start({screenshots: false, snapshots: true, sources: true});tracing = true;}
      fixture = await prepareActual(page, origin);}
    if (arm.fixture === 'native-dom-clone' && process.env.JSON_TERMINAL_TRACE === '1') {await browserContext.tracing.start({screenshots: false, snapshots: true, sources: true});tracing = true;}
    arm.initial = await layoutSnapshot(page, fixture);
    await installObservation(page, fixture);
    for (const columns of [3, 5]) {assertActive();await runColumn(page, fixture, arm, columns);}
    arm.final = await layoutSnapshot(page, fixture);
    if (arm.fixture === 'actual') {
      arm.runtimeBeforeDestroy = await page.evaluate(id => window.__runtime.inspect(id), fixture.id);
      await page.evaluate(id => window.__runtime.destroy(id), fixture.id);await settle(page);
      arm.runtimeAfterDestroy = await page.evaluate(id => window.__runtime.inspect(id), fixture.id);
      recordAssertion(arm, 'runtime errors empty before/after destroy', () => {expect(arm.runtimeBeforeDestroy.errors).toEqual([]);expect(arm.runtimeAfterDestroy.errors).toEqual([]);expect(arm.runtimeAfterDestroy.events).toEqual(arm.runtimeBeforeDestroy.events);expect(arm.runtimeAfterDestroy.applicationErrors).toEqual([]);});
    } else {
      recordAssertion(arm, 'native clone still has no runtime or document scripts', () => {expect(arm.final.runtimeType).toBe('undefined');expect(arm.final.scriptCount).toBe(0);});
    }
    arm.execution = arm.cases.length === 2 && arm.cases.every(entry => entry.execution === 'FIRST_MEASUREMENT_RECORDED') ? 'ALL_ONCE_ONLY_MEASUREMENTS_RECORDED' : 'INCOMPLETE';
  } catch (error) {arm.errors.push(serializeError(error));arm.execution = 'INCOMPLETE';}
  finally {
    if (tracing) {try {const name = 'trace-' + arm.id + '.zip';await browserContext.tracing.stop({path: resolve(runDirectory, name)});arm.trace = {path: name, sha256: sha256(readFileSync(resolve(runDirectory, name)))};}catch (error) {arm.errors.push({phase: 'trace-stop', ...serializeError(error)});}}
    if (browserContext) {try {await browserContext.close();contexts.delete(browserContext);arm.contextClosed = true;}catch (error) {arm.errors.push({phase: 'context-close', ...serializeError(error)});}}
    arm.finishedAt = new Date().toISOString();journal('arm-finished', arm);
  }
}
async function work() {
  result.preflight = inputSnapshot();requirePinned(result.preflight);journal('pinned-preflight', result.preflight);
  const {chromium, devices, expect: importedExpect} = await import('@playwright/test');expect = importedExpect;
  const origin = await startServer();assertActive();
  browser = await chromium.launch({headless: true, channel: 'chromium', timeout: 30_000});
  result.browser = {engine: 'chromium', channel: 'chromium', version: browser.version(), executablePath: chromium.executablePath(), playwrightVersion: JSON.parse(readFileSync(resolve(repository, 'node_modules/@playwright/test/package.json'), 'utf8')).version};
  for (const armContract of armContracts) await runArm(origin, devices['Desktop Chrome'], armContract);
  result.postflight = inputSnapshot();requirePinned(result.postflight);
  result.assertionSummary = result.arms.map(arm => ({arm: arm.id, execution: arm.execution,
    failedArmAssertions: arm.assertions.filter(assertion => !assertion.passed).map(assertion => assertion.name),
    cases: arm.cases.map(entry => ({columns: entry.columns, execution: entry.execution, first2RafMeasurement: entry.first2RafMeasurement,
      failedAssertions: entry.assertions.filter(assertion => !assertion.passed).map(assertion => assertion.name)}))}));
  result.operationalStatus = result.arms.length === 3 && result.arms.every(arm => arm.execution === 'ALL_ONCE_ONLY_MEASUREMENTS_RECORDED' && arm.errors.length === 0 && arm.assertions.every(assertion => assertion.passed) && arm.pages.every(page => page.errors.length === 0)) ? 'ALL_SIX_MEASUREMENTS_RECORDED' : 'INCOMPLETE_OR_RUNTIME_ERROR';
}
async function main() {
  // A persistent exclusive claim forbids silent rerun/resume, including after an incomplete attempt.
  const claim = {startedAt: result.startedAt, scriptSha256: result.scriptSha256, contractHead: contract.head, pid: process.pid, policy: 'ONE_INVOCATION_NO_RETRY'};
  writeFileSync(resolve(here, 'run.claim.json'), JSON.stringify(claim, null, 2) + '\n', {flag: 'wx'});
  runDirectory = resolve(here, 'run-' + new Date().toISOString().replace(/[:.]/g, '-') + '-' + randomUUID());mkdirSync(runDirectory);
  result.outputDirectory = runDirectory;journalFd = openSync(resolve(runDirectory, 'journal.jsonl'), 'wx');
  journal('invocation', claim);
  let watchdog, rejectStop;
  const stop = new Promise((_, reject) => {rejectStop = reject;});
  const handlers = new Map(['SIGINT', 'SIGTERM'].map(signal => [signal, () => {cancelled = true;rejectStop(new Error('Received ' + signal + '; own resources will close, no resume'));}]));
  for (const [signal, handler] of handlers) process.once(signal, handler);
  watchdog = setTimeout(() => {cancelled = true;rejectStop(new Error('Total diagnostic deadline exceeded'));}, limits.totalMs);
  try {result.operationalStatus = 'RUNNING';await Promise.race([work(), stop]);}
  catch (error) {result.errors.push(serializeError(error));result.operationalStatus = 'INCOMPLETE';journal('fatal-error', serializeError(error));}
  finally {
    cancelled = true;clearTimeout(watchdog);
    for (const [signal, handler] of handlers) process.removeListener(signal, handler);
    for (const browserContext of contexts) {try {await browserContext.close();}catch (error) {result.errors.push({phase: 'finally-context-close', ...serializeError(error)});}}
    contexts.clear();
    try {if (browser) {await browser.close();result.cleanup.browserClosed = true;}else result.cleanup.browserClosed = 'NOT_STARTED';}
    catch (error) {result.cleanup.browserClosed = false;result.errors.push({phase: 'finally-browser-close', ...serializeError(error)});}
    try {if (server) {server.closeAllConnections();await new Promise((done, reject) => server.close(error => error ? reject(error) : done()));result.cleanup.ownedServerClosed = true;}else result.cleanup.ownedServerClosed = 'NOT_STARTED';}
    catch (error) {result.cleanup.ownedServerClosed = false;result.errors.push({phase: 'finally-server-close', ...serializeError(error)});}
    result.finishedAt = new Date().toISOString();
    if (result.errors.length || result.cleanup.browserClosed === false || result.cleanup.ownedServerClosed === false) result.operationalStatus = 'INCOMPLETE';
    result.processExitCode = result.operationalStatus === 'ALL_SIX_MEASUREMENTS_RECORDED' ? 0 : 2;
    journal('final-record', result);writeFileSync(resolve(runDirectory, 'raw.json'), JSON.stringify(result, null, 2) + '\n', {flag: 'wx'});
    closeSync(journalFd);journalFd = undefined;
    console.log(JSON.stringify({operationalStatus: result.operationalStatus, processExitCode: result.processExitCode, raw: resolve(runDirectory, 'raw.json'), assertionSummary: result.assertionSummary}, null, 2));
    process.exitCode = result.processExitCode;
  }
}
main().catch(error => {console.error(JSON.stringify({status: 'REFUSED_OR_OUTPUT_SETUP_FAILED', error: serializeError(error)}));process.exitCode = 2;});
