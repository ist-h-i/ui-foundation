# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: static-runtime-reassessment-layout.spec.ts >> reassessment specialist-style R161 B: JsonViewer real table consumer has local full-content reach after update
- Location: tests/ui/static-runtime-reassessment-layout.spec.ts:208:3

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 964.5
Received:    1393.1875
```

# Page snapshot

```yaml
- main [ref=e3]:
  - heading "静的警告の実行時検証" [level=1] [ref=e4]
  - generic [ref=e5]:
    - text: 表示設定
    - combobox "表示設定" [ref=e6]:
      - option "guided" [selected]
      - option "dense"
  - button "基準となる操作" [ref=e7]
  - region "検証する部品" [ref=e8]:
    - region "実consumerの階層" [ref=e10]:
      - paragraph [ref=e11]: 実consumerの階層
      - generic [ref=e12]:
        - generic [ref=e13]:
          - text: JSONを検索
          - searchbox "JSONを検索" [ref=e14]
        - button "原文をコピー" [ref=e15] [cursor=pointer]
        - status
      - region "実consumerの階層の階層" [active] [ref=e16]:
        - table [ref=e17]:
          - rowgroup [ref=e18]:
            - row [ref=e19]:
              - columnheader "階層" [ref=e20]
              - columnheader "型" [ref=e21]
              - columnheader "値" [ref=e22]
          - rowgroup [ref=e23]:
            - row [ref=e24]:
              - rowheader [ref=e25]:
                - button "root を折り畳む" [expanded] [ref=e26] [cursor=pointer]
              - cell "object" [ref=e27]
              - cell [ref=e28]:
                - code [ref=e29]: …
            - row [ref=e30]:
              - rowheader "\"申請項目0\"" [ref=e31]
              - cell "string" [ref=e32]
              - cell [ref=e33]:
                - code [ref=e34]: "\"保持する長文 0 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e35]:
              - rowheader "\"申請項目1\"" [ref=e36]
              - cell "string" [ref=e37]
              - cell [ref=e38]:
                - code [ref=e39]: "\"保持する長文 1 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e40]:
              - rowheader "\"申請項目2\"" [ref=e41]
              - cell "string" [ref=e42]
              - cell [ref=e43]:
                - code [ref=e44]: "\"保持する長文 2 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e45]:
              - rowheader "\"申請項目3\"" [ref=e46]
              - cell "string" [ref=e47]
              - cell [ref=e48]:
                - code [ref=e49]: "\"保持する長文 3 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e50]:
              - rowheader "\"申請項目4\"" [ref=e51]
              - cell "string" [ref=e52]
              - cell [ref=e53]:
                - code [ref=e54]: "\"保持する長文 4 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e55]:
              - rowheader "\"申請項目5\"" [ref=e56]
              - cell "string" [ref=e57]
              - cell [ref=e58]:
                - code [ref=e59]: "\"保持する長文 5 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e60]:
              - rowheader "\"申請項目6\"" [ref=e61]
              - cell "string" [ref=e62]
              - cell [ref=e63]:
                - code [ref=e64]: "\"保持する長文 6 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e65]:
              - rowheader "\"申請項目7\"" [ref=e66]
              - cell "string" [ref=e67]
              - cell [ref=e68]:
                - code [ref=e69]: "\"保持する長文 7 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e70]:
              - rowheader "\"申請項目8\"" [ref=e71]
              - cell "string" [ref=e72]
              - cell [ref=e73]:
                - code [ref=e74]: "\"保持する長文 8 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e75]:
              - rowheader "\"申請項目9\"" [ref=e76]
              - cell "string" [ref=e77]
              - cell [ref=e78]:
                - code [ref=e79]: "\"保持する長文 9 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e80]:
              - rowheader "\"申請項目10\"" [ref=e81]
              - cell "string" [ref=e82]
              - cell [ref=e83]:
                - code [ref=e84]: "\"保持する長文 10 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e85]:
              - rowheader "\"申請項目11\"" [ref=e86]
              - cell "string" [ref=e87]
              - cell [ref=e88]:
                - code [ref=e89]: "\"保持する長文 11 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e90]:
              - rowheader "\"申請項目12\"" [ref=e91]
              - cell "string" [ref=e92]
              - cell [ref=e93]:
                - code [ref=e94]: "\"保持する長文 12 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e95]:
              - rowheader "\"申請項目13\"" [ref=e96]
              - cell "string" [ref=e97]
              - cell [ref=e98]:
                - code [ref=e99]: "\"保持する長文 13 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e100]:
              - rowheader "\"申請項目14\"" [ref=e101]
              - cell "string" [ref=e102]
              - cell [ref=e103]:
                - code [ref=e104]: "\"保持する長文 14 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e105]:
              - rowheader "\"申請項目15\"" [ref=e106]
              - cell "string" [ref=e107]
              - cell [ref=e108]:
                - code [ref=e109]: "\"保持する長文 15 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e110]:
              - rowheader "\"申請項目16\"" [ref=e111]
              - cell "string" [ref=e112]
              - cell [ref=e113]:
                - code [ref=e114]: "\"保持する長文 16 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e115]:
              - rowheader "\"申請項目17\"" [ref=e116]
              - cell "string" [ref=e117]
              - cell [ref=e118]:
                - code [ref=e119]: "\"保持する長文 17 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e120]:
              - rowheader "\"申請項目18\"" [ref=e121]
              - cell "string" [ref=e122]
              - cell [ref=e123]:
                - code [ref=e124]: "\"保持する長文 18 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e125]:
              - rowheader "\"申請項目19\"" [ref=e126]
              - cell "string" [ref=e127]
              - cell [ref=e128]:
                - code [ref=e129]: "\"保持する長文 19 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e130]:
              - rowheader "\"申請項目20\"" [ref=e131]
              - cell "string" [ref=e132]
              - cell [ref=e133]:
                - code [ref=e134]: "\"保持する長文 20 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e135]:
              - rowheader "\"申請項目21\"" [ref=e136]
              - cell "string" [ref=e137]
              - cell [ref=e138]:
                - code [ref=e139]: "\"保持する長文 21 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e140]:
              - rowheader "\"申請項目22\"" [ref=e141]
              - cell "string" [ref=e142]
              - cell [ref=e143]:
                - code [ref=e144]: "\"保持する長文 22 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
            - row [ref=e145]:
              - rowheader "\"申請項目23\"" [ref=e146]
              - cell "string" [ref=e147]
              - cell [ref=e148]:
                - code [ref=e149]: "\"保持する長文 23 ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ ABCDEFGHIJ \""
```

# Test source

```ts
  127 |     async function intrinsic() {
  128 |       return editor.evaluate(el => {
  129 |         const original = el as HTMLTextAreaElement, style = getComputedStyle(original), clone = original.cloneNode() as HTMLTextAreaElement;
  130 |         clone.removeAttribute('id');clone.removeAttribute('name');clone.setAttribute('aria-hidden', 'true');clone.tabIndex = -1;
  131 |         for (const property of Array.from(style)) clone.style.setProperty(property, style.getPropertyValue(property));
  132 |         clone.style.cssText += ';position:absolute;visibility:hidden;pointer-events:none;height:auto;block-size:auto;max-height:none;max-block-size:none;';
  133 |         clone.style.width = original.getBoundingClientRect().width + 'px';clone.value = original.value;document.body.append(clone);
  134 |         const natural = clone.scrollHeight + parseFloat(style.borderTopWidth) + parseFloat(style.borderBottomWidth);clone.remove();
  135 |         return {natural, actual: original.getBoundingClientRect().height, scroll: original.scrollHeight, client: original.clientHeight};
  136 |       });
  137 |     }
  138 |     await expect.poll(async () => {const g = await intrinsic();return Math.abs(g.natural - g.actual);}).toBeLessThanOrEqual(1);
  139 |     await environment(page, contexts[(contexts.indexOf(context) + 1) % contexts.length]);
  140 |     await expect.poll(async () => {const g = await intrinsic();return Math.abs(g.natural - g.actual);}).toBeLessThanOrEqual(1);
  141 |     await node.evaluate(el => (el as HTMLElement).hidden = true);await expect(editor).toBeHidden();
  142 |     await environment(page, context);await node.evaluate(el => (el as HTMLElement).hidden = false);
  143 |     await expect.poll(async () => {const g = await intrinsic();return Math.abs(g.natural - g.actual);}).toBeLessThanOrEqual(1);
  144 |     await update(page, id, {maxHeight: 180});await expect.poll(async () => (await intrinsic()).actual).toBeLessThanOrEqual(181);
  145 |     expect((await intrinsic()).natural).toBeGreaterThan(180);await nativeFocus(page, editor);await editor.press('Control+End');
  146 |     await expect.poll(() => editor.evaluate(el => el.scrollTop)).toBeGreaterThan(0);await expect(editor).toHaveValue(text);await ring(editor);
  147 |     await record('textarea-independent-intrinsic', await intrinsic());await destroy(page, id);
  148 |   });
  149 | 
  150 |   test(`reassessment masonry R014 ${context.name}: unequal card heights stay unfragmented without overlap and retain native actions`, async ({page}) => {
  151 |     await ready(page, context);
  152 |     const items = Array.from({length: 7}, (_, i) => ({id: 'card-' + i, label: '申請を確認 ' + i, text: '内容を確認する ABCD '.repeat([2, 8, 3, 12, 4, 6, 2][i])}));
  153 |     const id = await create(page, 'RuntimeReassessmentMasonry', {items, columns: 2}), node = host(page, id);
  154 |     for (const columns of [2, 1, 3]) {
  155 |       await update(page, id, {columns});await settle(page);
  156 |       const cards = await node.locator('li[data-item-key]').evaluateAll(elements => elements.map(el => ({key: el.getAttribute('data-item-key'), fragments: el.getClientRects().length, box: el.getBoundingClientRect().toJSON()})));
  157 |       expect(cards).toHaveLength(7);expect(new Set(cards.map(card => Math.round(card.box.height))).size).toBeGreaterThan(1);
  158 |       for (let i = 0; i < cards.length; i++) {expect(cards[i].fragments).toBe(1);expect(cards[i].box.height).toBeGreaterThan(0);for (let j = i + 1; j < cards.length; j++) {
  159 |         const a = cards[i].box, b = cards[j].box;expect(Math.min(a.right, b.right) - Math.max(a.left, b.left) > 1 && Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top) > 1, 'cards must not overlap').toBe(false);
  160 |       }}
  161 |       await record('masonry-' + columns, cards);
  162 |     }
  163 |     await update(page, id, {columns: 1, items: items.map(item => ({...item, text: item.text + ' 更新後の全文末尾'}))});
  164 |     for (const item of items) {const action = node.getByRole('button', {name: item.label, exact: true});await nativeFocus(page, action);await expect(node.locator(`li[data-item-key="${item.id}"]`)).toContainText('更新後の全文末尾');}
  165 |     await destroy(page, id);
  166 |   });
  167 | 
  168 |   test(`reassessment grid-list R092 ${context.name}: semantic minimum threshold uses real gap and retains updated selected content`, async ({page}) => {
  169 |     await ready(page, context);
  170 |     const items = Array.from({length: 5}, (_, i) => ({id: 'item-' + i, name: '保持する申請 ' + i}));
  171 |     const id = await create(page, 'GridList', {items, keyField: 'id', labelField: 'name', controlId: 'threshold-grid', label: '幅の境界一覧', selectionMode: 'single', gap: 'compact'});
  172 |     const node = host(page, id), list = node.locator('ul.ui-grid-list');await set(node, '--ui-size-grid-item', '80px');
  173 |     for (const gap of ['compact', 'wide']) {
  174 |       await update(page, id, {gap});
  175 |       const minimum = await node.locator('.ui-grid-list__measure').evaluate(el => el.getBoundingClientRect().width);near(minimum,80,'independent configured semantic grid minimum');
  176 |       const actualGap = await list.evaluate(el => parseFloat(getComputedStyle(el).columnGap));
  177 |       const expectedGap = await token(node, gap === 'compact' ? '--ui-space-control-gap' : '--ui-space-section');near(actualGap, expectedGap, 'actual semantic gap');
  178 |       const threshold = minimum * 2 + actualGap;
  179 |       for (const delta of [-1, 0, 1]) {
  180 |         await node.evaluate((el, width) => (el as HTMLElement).style.inlineSize = width + 'px', threshold + delta);
  181 |         await expect.poll(() => list.evaluate(el => getComputedStyle(el).gridTemplateColumns.split(' ').length)).toBe(delta < 0 ? 1 : 2);
  182 |         const geometry = await list.evaluate(el => {const style = getComputedStyle(el);return {width: el.getBoundingClientRect().width, gap: parseFloat(style.columnGap), tracks: style.gridTemplateColumns.split(' ').map(Number.parseFloat)};});
  183 |         for (const width of geometry.tracks) near(width, (geometry.width - geometry.gap * (geometry.tracks.length - 1)) / geometry.tracks.length, 'used grid tracks');
  184 |         await record('grid-minimum-' + gap + '-' + delta, {minimum, threshold, delta, ...geometry});
  185 |       }
  186 |     }
  187 |     await clear(node, 'inline-size');await update(page, id, {items: items.map(item => ({...item, name: item.name + ' 更新済み全文'}))});
  188 |     const choice = node.getByRole('radio').first();await nativeFocus(page, choice);await choice.press('Space');
  189 |     await expect(node).toContainText('保持する申請 0 更新済み全文');
  190 |     const event = await page.evaluate(id => (window as any).__runtime.inspect(id).events.filter((event: {name: string}) => event.name === 'selectedKeysChange').at(-1), id);expect(event.value).toEqual(['item-0']);await destroy(page, id);
  191 |   });
  192 | 
  193 |   test(`reassessment layout-css R124 R125 ${context.name}: divider pseudo used border thickness/color and adjacent keyboard rings`, async ({page}) => {
  194 |     await ready(page, context);
  195 |     const id = await create(page, 'RuntimeReassessmentDivider', {}), node = host(page, id), divider = node.locator('ui-divider');
  196 |     for (const orientation of ['horizontal', 'vertical']) for (const lineStyle of ['solid', 'dashed', 'dotted']) {
  197 |       await update(page, id, {orientation, lineStyle});
  198 |       const expected = await divider.evaluate(el => {const probe = document.createElement('span');probe.style.cssText = 'position:absolute;visibility:hidden;border-top:var(--ui-border-control) solid var(--ui-color-border);';el.append(probe);const style = getComputedStyle(probe), result = {width: parseFloat(style.borderTopWidth), color: style.borderTopColor};probe.remove();return result;});
  199 |       for (const pseudo of ['::before', '::after']) {
  200 |         const actual = await divider.evaluate((el, {pseudo, orientation}) => {const s = getComputedStyle(el, pseudo);return orientation === 'horizontal' ? {width: parseFloat(s.borderTopWidth), color: s.borderTopColor, style: s.borderTopStyle} : {width: parseFloat(s.borderInlineStartWidth), color: s.borderInlineStartColor, style: s.borderInlineStartStyle};}, {pseudo, orientation});
  201 |         expect(actual.width).toBeGreaterThan(0);near(actual.width, expected.width, 'used pseudo border thickness');expect(actual.color).toBe(expected.color);expect(actual.style).toBe(lineStyle);
  202 |       }
  203 |       await nativeFocus(page, node.getByRole('button', {name: '境界の前の操作', exact: true}));await page.keyboard.press('Tab');await expect(node.getByRole('button', {name: '境界の後の操作', exact: true})).toBeFocused();await ring(node.getByRole('button', {name: '境界の後の操作', exact: true}));
  204 |     }
  205 |     await destroy(page, id);
  206 |   });
  207 | 
  208 |   test(`reassessment specialist-style R161 ${context.name}: JsonViewer real table consumer has local full-content reach after update`, async ({page}) => {
  209 |     await ready(page, context);
  210 |     const source = JSON.stringify(Object.fromEntries(Array.from({length: 24}, (_, i) => ['申請項目' + i, '保持する長文 ' + i + ' ABCDEFGHIJ '.repeat(6)])));
  211 |     const id = await create(page, 'JsonViewer', {label: '実consumerの階層', source}), node = host(page, id), viewport = node.getByRole('region', {name: '実consumerの階層の階層', exact: true}), table = node.locator('table.ui-specialist-data-table');
  212 |     for (const columns of [3, 5]) {
  213 |       await set(table, '--ui-specialist-columns', String(columns));await node.evaluate(el=>(el as HTMLElement).style.inlineSize='240px');await settle(page);
  214 |       const dimensions = await table.evaluate(el => {const style = getComputedStyle(el), parent = el.parentElement!;const unit = document.createElement('span');unit.style.cssText = 'position:absolute;visibility:hidden;inline-size:max(var(--ui-size-table-column-min),calc(8em + var(--ui-space-table-x) * 2));';el.append(unit);const minimum = unit.getBoundingClientRect().width;unit.remove();return {minimum, width: el.getBoundingClientRect().width, minWidth: parseFloat(style.minWidth), client: parent.clientWidth, scroll: parent.scrollWidth};});
  215 |       near(dimensions.minWidth, dimensions.minimum * columns, 'shared CSS used table minimum from actual consumer');expect(dimensions.width).toBeGreaterThanOrEqual(dimensions.minWidth - 1);expect(dimensions.scroll).toBeGreaterThan(dimensions.client);
  216 |       await nativeFocus(page, viewport);await viewport.press('End');await expect.poll(() => viewport.evaluate(el => el.scrollTop)).toBeGreaterThan(0);
  217 |       await viewport.evaluate(el => {el.scrollLeft = getComputedStyle(el).direction === 'rtl' ? -el.scrollWidth : el.scrollWidth;el.scrollTop = el.scrollHeight;});
  218 |       const last = node.locator('tbody tr').last().locator('td').last();await expect(last).toContainText('保持する長文 23');
  219 |       await last.evaluate(el => {
  220 |         el.scrollIntoView({block: 'end', inline: 'end'});
  221 |         const text = el.querySelector('code')!.firstChild!, range = document.createRange();
  222 |         range.setStart(text, Math.max(0, (text.textContent?.length ?? 1) - 1));range.setEnd(text, text.textContent!.length);
  223 |         const endpoint = range.getBoundingClientRect(), viewport = el.closest<HTMLElement>('.ui-specialist-scroll')!, view = viewport.getBoundingClientRect();
  224 |         viewport.scrollBy({left: endpoint.right > view.right ? endpoint.right - view.right + 2 : endpoint.left < view.left ? endpoint.left - view.left - 2 : 0, behavior: 'instant'});
  225 |       });await settle(page);
  226 |       const end = await last.evaluate(el => {const text = el.querySelector('code')!.firstChild!, range = document.createRange();range.setStart(text, Math.max(0, text.textContent!.length - 1));range.setEnd(text, text.textContent!.length);return {last: range.getBoundingClientRect().toJSON(), view: el.closest('.ui-specialist-scroll')!.getBoundingClientRect().toJSON()};});
> 227 |       expect(end.last.width).toBeGreaterThan(0);expect(end.last.bottom).toBeLessThanOrEqual(end.view.bottom + 1);expect(end.last.right).toBeLessThanOrEqual(end.view.right + 1);expect(end.last.left).toBeGreaterThanOrEqual(end.view.left - 1);
      |                                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  228 |       await record('specialist-json-columns-' + columns, {dimensions, end});
  229 |     }
  230 |     await update(page, id, {source: JSON.stringify({更新された申請: '更新後も消えない全文末尾'})});await expect(table).toContainText('更新後も消えない全文末尾');
  231 |     const search = node.getByRole('searchbox');await nativeFocus(page, search);await search.fill('更新された申請');await ring(search);await expect(table).toContainText('更新後も消えない全文末尾');await destroy(page, id);
  232 |   });
  233 | }
  234 | 
```