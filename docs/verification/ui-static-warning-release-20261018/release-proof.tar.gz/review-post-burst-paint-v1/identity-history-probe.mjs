import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import vm from 'node:vm';
import ts from 'typescript';

// Finite algorithm contract probe only. These mocks are not native-DOM,
// keyboard, rendering, or application acceptance evidence.
const file='tests/ui/post-burst-paint.ts';
const source=fs.readFileSync(file,'utf8');
const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const registrations=new Set();
let attemptedAttributeMutations=0;
let deliveredAttributeMutations=0;
let observedOptions=null;
const emitAttributeMutation=record=>{
 attemptedAttributeMutations++;
 for(const observer of registrations){
  if(!observer.options.attributes)continue;
  observer.records.push(record);
  queueMicrotask(()=>{
   if(!observer.records.length||!registrations.has(observer))return;
   const records=observer.records.splice(0);
   deliveredAttributeMutations+=records.length;
   observer.callback(records);
  });
 }
};
class ElementStub {
 constructor(id){this.value=id;this.isConnected=true;}
 get id(){return this.value;}
 set id(value){const oldValue=this.value;this.value=value;emitAttributeMutation({type:'attributes',target:this,attributeName:'id',oldValue});}
 contains(node){return node===this;}
}
const target=new ElementStub('paint-target');
const listeners=new Map();
const document={
 activeElement:target,
 addEventListener(type,listener){listeners.set(type,listener);},
 removeEventListener(type){listeners.delete(type);},
};
const sandbox={
 exports:{},window:{},document,performance,structuredClone,Number,Error,String,
 setTimeout,clearTimeout,
 requestAnimationFrame(callback){return setImmediate(()=>callback(performance.now()));},
 cancelAnimationFrame:clearImmediate,
 MutationObserver:class {
  constructor(callback){this.callback=callback;this.records=[];}
  observe(_node,options){this.options=options;observedOptions=structuredClone(options);registrations.add(this);}
  disconnect(){registrations.delete(this);this.records=[];}
 },
};
vm.createContext(sandbox);
vm.runInContext(compiled,sandbox,{filename:file});
sandbox.exports.installPostBurstPaintObserver();
let painted=false;
const producerIdentityHistory=[];
const result=sandbox.window.__observePostBurstPaint({
 expectedIdentity:'paint-target',identify:element=>element?.id??'null',
 read:()=>({painted}),isReady:metric=>metric.painted,timeoutMs:100,
});
queueMicrotask(()=>{
 target.id='different-logical-target';producerIdentityHistory.push(target.id);
 target.id='paint-target';producerIdentityHistory.push(target.id);
 painted=true;
});
const observation=await result;
assert.equal(observation.outcome,'ready');
assert.equal(observation.targetIssue,null);
assert.equal(observation.initial.ready,false);
assert.equal(observation.final.ready,true);
assert.equal(observation.final.sameTarget,true);
assert.equal(observation.final.activeIdentity,'paint-target');
assert.equal(attemptedAttributeMutations,2);
assert.equal(deliveredAttributeMutations,0);
assert.equal(listeners.size,0);
assert.equal(registrations.size,0);
console.log(JSON.stringify({
 status:'COUNTEREXAMPLE_REPRODUCED',
 scope:'Finite algorithm contract probe with mocked document, Element, MutationObserver and RAF; no browser/application acceptance',
 source:file,sourceSha256:crypto.createHash('sha256').update(source).digest('hex'),
 observedOptions,attemptedAttributeMutations,deliveredAttributeMutations,
 producerIdentityHistory,observation,
},null,2));
