from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

folder = Path('docs/verification/ui-static-warning-release-20261018')
manifest_path = folder / 'review-post-burst-paint-v1-snapshot.json'
manifest = json.loads(manifest_path.read_text())
digest = lambda value: hashlib.sha256(value).hexdigest()
assert len(manifest['files']) == 19
artifacts = {
    'snapshot': (manifest_path, '78937773883dec29bb25b9a7ade9b8a36bac0ea1d09ca0e73d563c06739a723b'),
    'tar': (folder / 'review-post-burst-paint-v1.tar', 'b94e4e32084ca9c6a9b3d9f4dd5d9d1db79d3ac548c99a21c1950ff84e586c7e'),
    'patch': (folder / 'review-post-burst-paint-v1.patch', '1c04bda10bbce6ebdcfe32eeb090fff0b6ba0ca03ea679dd3b21645bb19ff238'),
}
artifact_results = {name: {'expected': expected, 'actual': digest(path.read_bytes())} for name, (path, expected) in artifacts.items()}
files = []
with tarfile.open(artifacts['tar'][0]) as archive:
    members = {member.name.removeprefix('./'): member for member in archive.getmembers() if member.isfile()}
    for name, expected in manifest['files'].items():
        files.append({'file': name, 'expected': expected, 'live': digest(Path(name).read_bytes()), 'tar': digest(archive.extractfile(members[name]).read())})
assert all(item['expected'] == item['actual'] for item in artifact_results.values())
assert all(item['expected'] == item['live'] == item['tar'] for item in files)
print(json.dumps({
    'status': 'PASS',
    'phase': 'Final readback after source review; initial readback also matched all 19 live and tar files',
    'base_sha': manifest['base_sha'],
    'current_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'branch': subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip(),
    'file_count': len(files),
    'artifacts': artifact_results,
    'files': files,
}, indent=2))
