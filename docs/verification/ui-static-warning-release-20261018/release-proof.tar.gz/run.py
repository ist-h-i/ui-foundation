#!/usr/bin/env python3
"""Capture all repository test/build drivers before and after one local command."""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def inputs():
    paths = set()
    for directory in ['src', 'templates', 'tests', 'scripts', '.ui/generated', '.agents/skills/project-ui']:
        paths.update(p for p in (ROOT / directory).rglob('*') if p.is_file())
    paths.update(ROOT.glob('tsconfig*.json'))
    paths.update(ROOT.glob('playwright*.ts'))
    paths.update(ROOT / n for n in ['package.json', 'package-lock.json', 'playwright.config.ts', 'examples/ui.config.example.yaml', 'docs/static-checks.ja.md',
                                  'docs/ui-warning-reviews.json', 'docs/ui-warning-reviews.ja.md', '.gitignore', '.gitattributes'])
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(paths)}

def bundle():
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted((ROOT / 'dist/fixture-app').rglob('*')) if p.is_file()}

if __name__ == '__main__':
    name, *command = sys.argv[1:]
    if not name or '/' in name or '\\' in name or not command or (HERE / (name + '-receipt.json')).exists():
        raise SystemExit('Use a fresh run name and an explicit command.')
    source, assets = inputs(), bundle()
    verification_paths={Path(__file__),HERE/'classify.py'}
    verification_paths.update(HERE.glob('playwright*.ts'))
    for pattern in ['expected-cases*.json','plan*.json','classification*.json']:
        verification_paths.update(HERE.glob(pattern))
    verification = {str(p.relative_to(ROOT)): sha(p) for p in sorted(verification_paths) if p.exists()}
    started = time.time()
    with (HERE / (name + '.log')).open('wb') as log:
        done = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    after, assets_after = inputs(), bundle()
    result = {'run': name, 'command': command, 'exit_code': done.returncode,
              'started_unix': started, 'finished_unix': time.time(),
              'source_sha256': source, 'source_after_sha256': after, 'bundle_sha256': assets, 'bundle_after_sha256': assets_after, 'verification_sha256': verification,
              'source_changed_during_run': [p for p in sorted(source.keys() | after.keys()) if source.get(p) != after.get(p)],
              'bundle_changed_during_run': [p for p in sorted(assets.keys() | assets_after.keys()) if assets.get(p) != assets_after.get(p)],
              'log_sha256': sha(HERE / (name + '.log'))}
    (HERE / (name + '-receipt.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['run', 'exit_code', 'source_changed_during_run', 'bundle_changed_during_run']}))
    raise SystemExit(done.returncode)
