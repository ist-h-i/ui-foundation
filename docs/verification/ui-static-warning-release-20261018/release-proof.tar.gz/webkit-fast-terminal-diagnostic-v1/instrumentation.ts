import {type Page} from '@playwright/test';
import {writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {record} from '../../../../tests/ui/css-override-test';

const destination=resolve(process.env.UI_WEBKIT_DIAGNOSTIC_DIR!);
export async function installDiagnostic(page:Page,id:number){
 await page.evaluate(id=>{
  const instance=(window as any).__runtime.instance(id),component=instance.list(),viewport=component.viewport(),element=viewport.elementRef.nativeElement as HTMLElement,scroller=component.scroller(),journal:any[]=[],restore:(()=>void)[]=[];
  const identify=(node:any)=>node===element?'viewport':node instanceof Element?node.closest('[data-ui-virtual-index]')?.getAttribute('data-ui-virtual-index')+':'+node.tagName:node?.constructor?.name??null;
  const entry=(kind:string,detail:any)=>journal.push({time:performance.now(),kind,active:identify(document.activeElement),...detail});
  const wrap=(object:any,name:string,kind:string,scope:(self:any)=>boolean=()=>true)=>{const original=object?.[name];if(typeof original!=='function')return;const owned=Object.prototype.hasOwnProperty.call(object,name),descriptor=Object.getOwnPropertyDescriptor(object,name);object[name]=function(...args:any[]){if(scope(this))entry(kind,{name,target:identify(this),args:args.map(arg=>typeof arg==='object'&&arg!==null?{...arg}:arg),stack:new Error().stack});return Reflect.apply(original,this,args);};restore.push(()=>owned?Object.defineProperty(object,name,descriptor!):delete object[name]);};
  const scope=(self:any)=>self===window||self===element||self instanceof Element&&element.contains(self);
  for(const name of ['scroll','scrollTo','scrollBy','scrollIntoView']){wrap(Element.prototype,name,'js-scroll-write',scope);if(name!=='scrollIntoView')wrap(window,name,'js-window-scroll-write');}
  let owner:any=element;while(owner&&!Object.getOwnPropertyDescriptor(owner,'scrollTop'))owner=Object.getPrototypeOf(owner);
  if(owner){const descriptor=Object.getOwnPropertyDescriptor(owner,'scrollTop')!;if(descriptor.configurable&&descriptor.set){Object.defineProperty(owner,'scrollTop',{...descriptor,set:function(value:number){if(scope(this))entry('js-scrollTop-write',{target:identify(this),value,stack:new Error().stack});return descriptor.set!.call(this,value);}});restore.push(()=>Object.defineProperty(owner,'scrollTop',descriptor));}}
  wrap(viewport,'scrollToOffset','viewport-scroll-call');wrap(viewport,'scrollToIndex','viewport-scroll-call');
  for(const name of ['scrollToIndex','scrollToOffset'])wrap(component,name,'component-scroll-call');
  const position=component.scrollPosition,originalRebase=position.rebase;position.rebase=function(...args:any[]){const result=Reflect.apply(originalRebase,this,args);entry('position-rebase',{args,result});return result;};restore.push(()=>position.rebase=originalRebase);
  for(const name of ['onContentScrolled','onDataLengthChanged','ngOnChanges'])wrap(scroller,name,'strategy-callback');
  const ranged=viewport.renderedRangeStream.subscribe((range:any)=>entry('range',{range:{...range},indices:[...scroller.indices()],offset:scroller.offset()}));restore.push(()=>ranged.unsubscribe());
  const observer=new MutationObserver(records=>entry('mutation',{records:records.map(change=>({type:change.type,target:identify(change.target),className:change.target instanceof Element?change.target.className:null,attribute:change.attributeName,value:change.type==='attributes'?(change.target as Element).getAttribute(change.attributeName!):null,added:change.addedNodes.length,removed:change.removedNodes.length}))}));observer.observe(element,{subtree:true,childList:true,attributes:true,attributeFilter:['style']});restore.push(()=>observer.disconnect());
  const scroll=(event:Event)=>entry('native-scroll-event',{trusted:event.isTrusted,target:identify(event.target),eventTime:event.timeStamp});element.addEventListener('scroll',scroll,{passive:true});restore.push(()=>element.removeEventListener('scroll',scroll));
  (window as any).__webkitDiagnostic={journal,dispose:()=>restore.reverse().forEach(fn=>fn())};entry('installed',{range:viewport.getRenderedRange(),indices:[...scroller.indices()],offset:scroller.offset()});
 },id);
}

/** Called only during settled C terminal setup and after a complete burst. */
export function fingerprintInPage(){
 const viewport=document.querySelector<HTMLElement>('[data-runtime-id] cdk-virtual-scroll-viewport')!,box=viewport.getBoundingClientRect(),style=getComputedStyle(viewport),contentTop=box.top+viewport.clientTop,contentLeft=box.left+viewport.clientLeft;
 const properties=['font','fontSize','fontFamily','lineHeight','direction','contain','overflowX','overflowY','scrollBehavior','scrollPaddingTop','scrollPaddingBottom','paddingTop','paddingBottom','paddingLeft','paddingRight','borderTopWidth','borderBottomWidth','borderLeftWidth','borderRightWidth','boxSizing','borderRadius'];
 const css=(element:HTMLElement)=>{const s=getComputedStyle(element);return Object.fromEntries(properties.map(name=>[name,(s as any)[name]]));};
 const rows=[...viewport.querySelectorAll<HTMLElement>('[data-ui-virtual-index]')].map(row=>{const rect=row.getBoundingClientRect(),input=row.querySelector<HTMLInputElement>('input')!,control=input.getBoundingClientRect();return {index:Number(row.getAttribute('data-ui-virtual-index')),rect:{width:rect.width,height:rect.height,contentTop:rect.top-contentTop+viewport.scrollTop,contentLeft:rect.left-contentLeft+viewport.scrollLeft},css:css(row),input:{label:input.getAttribute('aria-label'),value:input.value,type:input.type,tabIndex:input.tabIndex,rect:{width:control.width,height:control.height,left:control.left-rect.left,top:control.top-rect.top},css:css(input)}};});
 return {viewport:{left:box.left,top:box.top,right:box.right,bottom:box.bottom,width:box.width,height:box.height,clientTop:viewport.clientTop,clientLeft:viewport.clientLeft,clientWidth:viewport.clientWidth,clientHeight:viewport.clientHeight,scrollWidth:viewport.scrollWidth,scrollHeight:viewport.scrollHeight,css:css(viewport)},windowStyle:viewport.querySelector('.ui-virtual-window')?.getAttribute('style'),cdkStyle:viewport.querySelector('.cdk-virtual-scroll-content-wrapper')?.getAttribute('style'),spacerStyle:viewport.querySelector('.cdk-virtual-scroll-spacer')?.getAttribute('style'),rows,environment:{width:innerWidth,height:innerHeight,devicePixelRatio,rootFont:getComputedStyle(document.documentElement).fontSize,dir:document.documentElement.dir,profile:document.querySelector('main')?.getAttribute('data-ui-profile'),motion:matchMedia('(prefers-reduced-motion: reduce)').matches}};
}

export async function saveNativeBlueprint(page:Page,id:number){
 const fingerprint=await page.evaluate(fingerprintInPage);
 const blueprint=await page.evaluate(id=>{
  const root=document.documentElement.cloneNode(true) as HTMLElement,sourceInputs=[...document.querySelectorAll<HTMLInputElement>('input')],cloneInputs=[...root.querySelectorAll<HTMLInputElement>('input')];sourceInputs.forEach((input,index)=>{cloneInputs[index]!.setAttribute('value',input.value);});
  for(const script of root.querySelectorAll('script,link[rel="modulepreload"]'))script.remove();
  for(const node of [root,...root.querySelectorAll('*')])for(const attribute of node.getAttributeNames())if(/^on/i.test(attribute))node.removeAttribute(attribute);
  for(const link of root.querySelectorAll<HTMLLinkElement>('link[href]'))link.href=new URL(link.getAttribute('href')!,location.href).href;
  const base=document.createElement('base');base.href=location.href;root.querySelector('head')!.prepend(base);
  const element=document.querySelector<HTMLElement>(`[data-runtime-id="${id}"] cdk-virtual-scroll-viewport`)!;
  return {html:'<!doctype html>'+root.outerHTML,url:location.href,scrollTop:element.scrollTop,scrollLeft:element.scrollLeft,documentScrollTop:document.scrollingElement?.scrollTop??0,range:(window as any).__runtime.instance(id).list().viewport().getRenderedRange(),limit:(window as any).__fastTab.snapshot().limit,applicationScriptCount:root.querySelectorAll('script').length,inlineHandlerCount:[root,...root.querySelectorAll('*')].reduce((total,node)=>total+node.getAttributeNames().filter(name=>/^on/i.test(name)).length,0)};
 },id);
 const data={...blueprint,fingerprint,source:'02-instrumented C terminal setup before the unchanged burst',htmlSha256:createHash('sha256').update(blueprint.html).digest('hex')};
 await writeFile(resolve(destination,'native-blueprint.json'),JSON.stringify(data,null,2)+'\n');await record('native-blueprint-provenance',{...data,html:'(saved native-blueprint.json)'});
}

export async function saveDiagnostic(page:Page,id:number){
 const read=()=>page.evaluate(id=>{const element=document.querySelector<HTMLElement>(`[data-runtime-id="${id}"] cdk-virtual-scroll-viewport`)!,input=document.activeElement as HTMLElement,rect=input.getBoundingClientRect(),bounds=element.getBoundingClientRect();return {time:performance.now(),scrollTop:element.scrollTop,max:element.scrollHeight-element.clientHeight,active:input.getAttribute('aria-label')??input.tagName,activeBox:rect.toJSON(),viewport:{top:bounds.top+element.clientTop,bottom:bounds.top+element.clientTop+element.clientHeight},journal:[...(window as any).__webkitDiagnostic.journal]};},id);
 if(page.isClosed()){await record('diagnostic-page-closed',{closed:true});return;}
 await record('diagnostic-finally-before-deferred-observation',await read());
 await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));
 await record('diagnostic-two-post-burst-frames',await read());
 await record('diagnostic-deferred-fingerprint',await page.evaluate(fingerprintInPage));
 await page.evaluate(()=>(window as any).__webkitDiagnostic.dispose());
}
