import {defineConfig,devices,webkit} from '@playwright/test';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const baseURL=process.env.UI_WEBKIT_DIAGNOSTIC_URL!;
const launcher=resolve('scripts/webkit-keyboard-launcher.sh');
const directory=fileURLToPath(new URL('.',import.meta.url));
export default defineConfig({
 testDir:'.',testMatch:['01-exact.spec.ts','02-instrumented.spec.ts','03-native.spec.ts'],
 grep:/fast native Tab original D to C|native cloned terminal C/,fullyParallel:false,workers:1,retries:0,repeatEach:1,forbidOnly:true,timeout:90_000,
 outputDir:resolve(directory,'artifacts'),reporter:[['list'],['json',{outputFile:resolve(directory,'results.json')}]],
 use:{baseURL,trace:'on',screenshot:'only-on-failure'},
 projects:[{name:'webkit',use:{...devices['Desktop Safari'],browserName:'webkit',...(process.platform==='darwin'?{launchOptions:{executablePath:launcher,env:{...process.env,UI_RADIO_WEBKIT_EXECUTABLE:webkit.executablePath()}}}:{})}}],
});
