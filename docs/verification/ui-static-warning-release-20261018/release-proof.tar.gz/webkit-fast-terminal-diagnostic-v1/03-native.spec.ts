import {test,expect,record} from '../../../../tests/ui/css-override-test';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fingerprintInPage} from './instrumentation';

test('native cloned terminal C: compare immediate and deferred unpaced Tab visibility',async({page,browser})=>{
 await record('native-engine',{browserVersion:browser.version(),engine:'webkit',worker:1,retries:0,build:'NOT_RUN'});
 const blueprint=JSON.parse(await readFile(resolve(process.env.UI_WEBKIT_DIAGNOSTIC_DIR!,'native-blueprint.json'),'utf8'));
 const network:{url:string;type:string}[]=[];page.on('request',request=>network.push({url:request.url(),type:request.resourceType()}));
 await page.setViewportSize({width:320,height:1000});await page.emulateMedia({reducedMotion:'no-preference'});
 await page.setContent(blueprint.html,{waitUntil:'load'});
 await page.evaluate(blueprint=>{const element=document.querySelector<HTMLElement>('[data-runtime-id] cdk-virtual-scroll-viewport')!;element.scrollTop=blueprint.scrollTop;element.scrollLeft=blueprint.scrollLeft;document.scrollingElement!.scrollTop=blueprint.documentScrollTop;},blueprint);
 // Setup may settle. The key burst below contains only trusted keyboard IPC.
 await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));
 const setup=await page.evaluate(fingerprintInPage);await record('native-source-fingerprint',blueprint.fingerprint);await record('native-setup-fingerprint',setup);
 expect(setup,'listener-free native clone exactly preserves source geometry, CSS and environment').toEqual(blueprint.fingerprint);
 const integrity=await page.evaluate(()=>({scripts:document.scripts.length,applicationRuntime:typeof(window as any).__runtime,inlineHandlers:[...document.querySelectorAll('*')].flatMap(node=>node.getAttributeNames().filter(name=>/^on/i.test(name))),scrollTop:document.querySelector<HTMLElement>('cdk-virtual-scroll-viewport')!.scrollTop}));
 await record('native-integrity',{...integrity,network,browserVersion:browser.version()});expect(integrity.scripts).toBe(0);expect(integrity.applicationRuntime).toBe('undefined');expect(integrity.inlineHandlers).toEqual([]);expect(network.filter(request=>request.type==='script')).toEqual([]);expect(integrity.scrollTop).toBe(blueprint.scrollTop);
 await page.evaluate(()=>{
  const viewport=document.querySelector<HTMLElement>('cdk-virtual-scroll-viewport')!,events:any[]=[],scrolls:any[]=[];
  const identify=(node:Element|null)=>node===viewport?'viewport':node?.closest('[data-ui-virtual-index]')?'row:'+node.closest('[data-ui-virtual-index]')!.getAttribute('data-ui-virtual-index')+':main':node?.id??node?.tagName??null;
  let key:any=null,keyEvent:KeyboardEvent|null=null;
  document.addEventListener('keydown',event=>{if(event.key==='Tab'){keyEvent=event;key={time:performance.now(),active:identify(document.activeElement),trusted:event.isTrusted,shift:event.shiftKey};}},true);
  document.addEventListener('keyup',event=>{if(event.key==='Tab')events.push({time:performance.now(),active:identify(document.activeElement),key:{...key,cancelled:keyEvent!.defaultPrevented},dom:[...viewport.querySelectorAll('[data-ui-virtual-index]')].map(row=>Number(row.getAttribute('data-ui-virtual-index')))});},true);
  viewport.addEventListener('scroll',event=>scrolls.push({time:performance.now(),eventTime:event.timeStamp,trusted:event.isTrusted}),{passive:true});
  (window as any).__nativeTerminal={events,scrolls};
 });
 const sample=()=>page.evaluate(()=>{const element=document.querySelector<HTMLElement>('cdk-virtual-scroll-viewport')!,active=document.activeElement as HTMLElement,box=active.getBoundingClientRect(),viewport=element.getBoundingClientRect();return {time:performance.now(),scrollTop:element.scrollTop,max:element.scrollHeight-element.clientHeight,active:active.getAttribute('aria-label'),activeBox:box.toJSON(),viewport:{top:viewport.top+element.clientTop,bottom:viewport.top+element.clientTop+element.clientHeight},events:[...(window as any).__nativeTerminal.events],scrolls:[...(window as any).__nativeTerminal.scrolls]};});
 await page.locator('#runtime-anchor').focus();
 await page.keyboard.press('Tab');
 for(const row of blueprint.fingerprint.rows)await page.keyboard.press('Tab');
 // Immutable immediate measurement follows the complete burst; no key was paced.
 const immediate=await sample();await record('native-immutable-immediate',immediate);
 const after=await page.evaluate(fingerprintInPage);await record('native-post-burst-fingerprint',after);
 expect(after,'source-equivalent structural geometry remains unchanged after the native burst').toEqual(blueprint.fingerprint);
 const expected=['viewport',...blueprint.fingerprint.rows.map((row:any)=>'row:'+row.index+':main')];
 expect(immediate.events).toHaveLength(expected.length);
 for(const [index,active]of expected.entries()){const event=immediate.events[index];expect(event.active).toBe(active);expect(event.key.trusted).toBe(true);expect(event.key.cancelled).toBe(false);expect(event.key.shift).toBe(false);expect(event.dom).toEqual(blueprint.fingerprint.rows.map((row:any)=>row.index));expect(event.dom.length).toBeLessThanOrEqual(blueprint.limit);}
 await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));
 const deferred=await sample();await record('native-two-post-burst-frames',deferred);
 await record('native-classification',{referenceValid:true,expectedKeys:expected.length,observedKeys:immediate.events.length,immediateVisible:immediate.activeBox.top<immediate.viewport.bottom&&immediate.activeBox.bottom>immediate.viewport.top,deferredVisible:deferred.activeBox.top<deferred.viewport.bottom&&deferred.activeBox.bottom>deferred.viewport.top,visibilityIsObservationOnly:true,sourceFailureRemainsUnchanged:true});
});
