# Fast native Tab normal-suite deadline investigation

Date: 2026-10-18. Scope: read-only investigation of the two Chromium A–D mixed-control failures in the normal UI suite. No browser, build, sync, suite, retry, product change, or test-source change was performed by this investigator. This report is the only created file.

## Finding and correction proposal

**Supported cause: the accumulated finite workload exceeds the normal runner's 30-second case budget.** The recorded key APIs continue to complete in milliseconds; the first timeout occurs during list D backward traversal and table C environment setup. No wrong-focus, range-bound, cancelled-Tab, crash, or stalled individual key has been observed in the saved evidence. This does not establish success for the unfinished table C backward/D phases.

The minimal correction that preserves the existing same-instance A→B→C→D coverage is `test.setTimeout(90_000)` inside only the two tests declared by the kind loop at `tests/ui/virtual-fast-tab.spec.ts:109`. Add a short explanation that each case performs 1,040 or 2,064 trusted key IPCs plus post-burst checks across four environments. The dedicated `virtual-radio` cross-browser configuration already specifies 90,000 ms (`playwright.cross-browser.config.ts:23`); the ordinary configuration has no case timeout override, and both trace headers confirm 30,000 ms. Keep the normal global timeout, all keys and assertions, burst boundaries, DOM/range bounds, geometry/paint checks, lifecycle cleanup, retries=0, and delay-free `keyboard.press` unchanged.

This is a proposal, not an applied or verified correction. The main agent required source to remain frozen while its separate focused UI run is active. After the proposed narrow change, the ordinary supported pipeline must actually complete these cases; a new fresh review must assess the changed test contract. No broad 120-second run is evidence for this conclusion.

## Snapshot and evidence identity

Repository: `/Users/inouehiroshi/Documents/GitHub/ui-foundation`, branch `feat/ui-static-warning-release`, investigated HEAD `10074eae430dd75335189e325edb7c57049e2bb5`. The failed normal run used source HEAD `20761f986c6480546ddf405235b1ddf4faa8b405` in `/var/folders/57/t9r9mr850f74d7hd68f9zcm80000gn/T/ui-foundation-release-v2-72k3he8j`.

For the first seven files below, bytes match all four identities: working checkout, current HEAD Git object, normal-run private copy, and run-HEAD Git object. Fixture and ADR bytes also match the working and private copies. The final read-only HEAD check remained `10074eae430dd75335189e325edb7c57049e2bb5`.

| Source | SHA256 |
| --- | --- |
| `tests/ui/virtual-fast-tab.spec.ts` | `36c1e061c20928a9fa707502ad4641d8526fb1def6d39e857993215dcb0f63e2` |
| `tests/ui/css-override-test.ts` | `87879619c19ecc8eb2b2acd65db71e08803cf61701887982b8abcaf69d085641` |
| `tests/ui/runtime-lifecycle.ts` | `3eb28ea91f7b713e1aa3c5f8eb873bcde85b4bb321f6ce1bfb8bbc109fc0db82` |
| `templates/angular/virtual-scroll.ts` | `826eaf798b70dad85a8221d1105a0ce8ef040be52ef803ba93d8d7fca4332c08` |
| `templates/angular/virtual-rows.ts` | `1336cf776a0952ae3c0c3bd5c81ca7e8c872d3ee2be6bea2fa9f07e1f2c240ee` |
| `playwright.config.ts` | `a71dfb025322236334908bb3a98fd9b126e83eac57dd1db9d1f7c9f45063d76f` |
| `playwright.cross-browser.config.ts` | `3f132c171e894212f95304d82dec29a5feb769a023cc2050837603afcabb6d92` |
| `tests/fixture-app/runtime-fast-tab.ts` | `23ca3449b98dfe3db66e6bf6a5d33f7fa68cc8e9ffebd2610ab29571e3132500` |
| `docs/adr/0003-virtual-native-tab.md` | `68872ac573a3182d09bef062f468be2c1f81701bec6d0b308f5a43c749a09ca1` |

Trace parent directory is the failed run's `test-results/`. List case directory: `virtual-fast-tab-fast-nati-3822e-ry-row-forward-and-backward-chromium`. Table case directory: `virtual-fast-tab-fast-nati-b4c6b-ry-row-forward-and-backward-chromium`. Each item named `attachments/...` below is an entry in that case's ZIP, not a new extracted file.

| Evidence | List SHA256 | Table SHA256 |
| --- | --- | --- |
| `trace.zip` | `fa552e1b120f4283746c2742617a5ec55ee265e0bbc7fee5350a6b040e916a5c` | `05980441c2a9c854330635f8291ce7a5ccd4a4221dcfd4ed7bc4b62e8b2e2fdf` |
| ZIP `test.trace` | `b74f6b066b19aa3c04119f4a2cb5f4754db47077d4a1bb0e71e23518290a2f9d` | `200658c43186e60d8a9e5dc20c66df5630bd29b84031701bdd9cd00e96af2be6` |
| ZIP `1-trace.trace` | `a1e819e748c96da3f4eba9a6a808ca806e58086df4f77ed18cd1ff50f68945f0` | `67671018683d0cebcf1c9e3db8495abb40b997d34f3e0839026eefe7d3ee2f09` |
| `error-context.md` | `418b10a3bb10d2fe5c5e765a411b85bd6ef46c416b95013c36a55c2dca138d14` | `d2e059fcfe7b2c6e867d98ad9c18bf79e72e091c27fbc2f3605d7f8c611f7d80` |
| Saved keyup log | `92e3677c0d13332b3a0a6ea01b5d835c44d8c98843fad913b55155984c368810` | `894bb1c5ef0505fd71326430a1ac01bca8ec13e135384f627156e0c2d401d63e` |
| Saved lifecycle | `7d4fdba7d8e93981170a9896a0186f3f1b148a172a09c146251819c329291550` | `e48a647e61ff099652fdc402d6164cc439f2075efd1dacafa80e1a8b1a9fa3c6` |

List keyup attachment: `attachments/d95fefd97ee03c705ee8d7209a9385324c763667`; lifecycle: `attachments/589f1e4ae7d771e0e5b1af6509d2921c50cb913c`. Table keyup attachment: `attachments/46fa39791073577e3465bbed2550fb6b9a8500ac`; lifecycle: `attachments/68e001d3c12e1e397bb7b97c5db26c3413136546`.

## Actual sequence and per-context time

The test creates one page and one `RuntimeFastTab` instance before the A–D loop, installs the probe once, updates that same id for each context, and destroys it after the loop (`virtual-fast-tab.spec.ts:110-121`). It does not create/destroy a component per context. Each iteration focuses the before boundary; the preceding iteration exits back to before with range start 0. There are no retained-edit/value assertions in this mixed-control case. Nevertheless, the existing case executes the same-instance row-size/overscan history `null/2 → null/2 → 220/0 → null/2`, including resetting C's explicit 220 height and overscan 0. Splitting contexts into eight independent cases would remove that table/mixed-control transition history. The separate original 1,000-row list test explicitly preserves a D→C environment change (`:86-100`); it does not replace the mixed-control table transitions.

For `k` controls per row, each context sends `1 + 64k + 1 + 64k + 2 = 4 + 128k` trusted Tab/Shift+Tab calls. Thus list (`k=2`) is 260 per context and **1,040 total**, table (`k=4`) is 516 per context and **2,064 total**. `flush` is after a burst, not after each key. Every recorded keyup checks focus identity, trusted/native key, direction, cancellation, public range size and live DOM bound (`:44-59`).

Times below are milliseconds relative to the runner trace's `context-options.monotonicTime`. Complete-context duration is measured from that context's environment-evaluation call to the next context's environment-evaluation call; it includes the completed key bursts, post-burst assertions/geometry and transition setup. It is not an isolated product performance benchmark.

| Kind/context | Context environment time | Next context environment time | Complete cycle duration | Native key calls completed in that cycle |
| --- | ---: | ---: | ---: | ---: |
| list A | 3,759.951 | 10,613.609 | 6,853.658 | 260 |
| list B | 10,613.609 | 17,787.988 | 7,174.379 | 260 |
| list C | 17,787.988 | 25,356.491 | 7,568.503 | 260 |
| list D | 25,356.491 | — | incomplete at timeout | see below |
| table A | 3,996.872 | 17,123.087 | 13,126.215 | 516 |
| table B | 17,123.087 | 29,951.697 | 12,828.610 | 516 |
| table C | 29,951.697 | — | setup straddles timeout | 0 before primary timeout |
| table D | — | — | NOT_REACHED | 0 |

List saved post-burst paint attachments were written at A forward/backward 6,830.685/10,482.737; B 13,592.706/17,622.113; C 21,144.769/25,226.002; D forward 28,938.078 ms. All have active and first-visible `painted: true`. D backward attachment was written at 31,297.042 ms, after failure, and cannot be counted as an in-budget test success. Table A attachments were at 9,976.519/16,978.235; B 24,216.350/29,877.256 ms, with both paint fields true. Table C forward paint at 32,594.750 ms is also post-deadline evidence only.

## Deadline, actions, and observed focus

The first `error` in runner `test.trace` is the primary failure boundary. Runner `before`/`after` records were joined by callId; library `stepId` connects native calls to those runner steps. This avoids treating work that continues during teardown as work completed before timeout.

| Observation | List | Table |
| --- | --- | --- |
| Runner trace monotonic origin | 3,011,665.122 | 3,015,452.212 |
| Nominal origin + 30,000 ms | 3,041,665.122 | 3,045,452.212 |
| After Hooks start relative to origin | 30,016.590 ms | 30,012.648 ms |
| Keyboard API calls completed before first timeout error | 975 | 1,032 |
| Keyboard API calls begun before first timeout error | 976 | 1,032 |
| Last completed native key before first error | list D backward: `row:32:main → row:31:tail` | table B final exit: `viewport → before` |
| Pending operation at first error | `pw:api@6676`, Shift+Tab from `row:31:tail`; its captured keyup later shows expected `row:31:main` | `pw:api@7411`, environment C evaluation; no C key begun |
| Native key duration min / max before first error | 2.971 / 64.289 ms | 3.753 / 58.515 ms |
| Native key duration median before first error | 9.495 ms | 9.971 ms |
| Runner key API duration min / max before nominal deadline | 4.241 / 70.526 ms | 5.865 / 62.632 ms |

For list D, 195 of that context's calls had completed before the primary error: 130 forward calls (viewport, 128 controls, after), then 65 Shift+Tab row-control calls. The 196th D call was pending at error. No long blocked keyboard action appears. The largest pre-deadline non-key action is initial navigation (list 1,924.896 ms, table 1,963.168 ms), followed by finite setup actions. Setup's native-wheel `expect.poll` records include false intermediate attempts and then finish; those records are not independent final assertion failures. Every observed reference wheel was trusted and uncancelled.

Raw keydown-to-keyup spans and consecutive keydown gaps *within bursts*, excluding intentional post-burst checks:

| Kind/context/burst | Captured events | Event span | Consecutive keydown gap min / max | Keydown→keyup min / max |
| --- | ---: | ---: | ---: | ---: |
| list A forward | 129 | 2,331.5 | 6.7 / 59.9 | 2.1 / 27.2 |
| list A backward | 129 | 2,555.5 | 8.8 / 52.7 | 1.9 / 22.7 |
| list B forward | 129 | 2,198.8 | 7.2 / 49.9 | 1.8 / 33.6 |
| list B backward | 129 | 2,568.5 | 7.7 / 56.4 | 1.7 / 19.0 |
| list C forward | 129 | 2,106.3 | 6.6 / 40.0 | 1.3 / 17.0 |
| list C backward | 129 | 2,447.5 | 8.5 / 39.5 | 1.4 / 12.7 |
| list D forward | 129 | 2,079.6 | 7.7 / 50.3 | 1.5 / 23.0 |
| list D backward (crosses timeout) | 129 | 1,909.1 | 4.7 / 93.4 | 1.6 / 14.3 |
| table A forward | 257 | 4,749.3 | 7.5 / 58.3 | 1.9 / 25.8 |
| table A backward | 257 | 5,395.3 | 8.3 / 61.3 | 0.8 / 43.5 |
| table B forward | 257 | 4,027.1 | 6.9 / 36.4 | 1.8 / 20.5 |
| table B backward | 257 | 3,937.4 | 7.0 / 63.3 | 1.5 / 15.8 |
| table C forward (after timeout) | 257 | 1,562.6 | 2.4 / 18.6 | 1.1 / 11.4 |

All time units in the last table are ms. Forward burst includes viewport entry plus all controls; backward burst includes the forward after-boundary call plus all reverse controls. The two final reverse exit keys are separate.

The saved list log contains all 1,040 expected keyups; a read-only reconstruction found zero mismatches against the expected row/control sequence, trust, direction, cancellation=false, DOM limit, and public range limit. Its last keyup and D backward paint happen after the primary timeout. The saved table log contains 1,289 keyups: all A/B (1,032) plus C forward (257), also with zero mismatches. C forward is after the timeout. The remaining C backward events were not flushed and are absent from that saved log.

The runner continued temporarily during teardown. List ultimately had all 1,040 key APIs return, with its final exit at 31,314.032 ms; this does not convert the failed test into a pass. Table had 1,431 key APIs begun, 1,430 successful completions, then a timeout cancellation at 33,945.376 ms on C backward. The last successfully returned reverse API corresponds to `row:29:cell1`; the interrupted API's planned destination is `row:28:cell2`, which is also the final error snapshot's active cell. Cancellation of the API promise therefore does not establish that the key's native focus effect was absent. These unflushed C backward events have no saved keyup assertions. This later keyboard error follows the primary timeout rather than causing it.

Both lifecycle attachments were captured shortly after the first timeout with classification `open`, `pageClosed=false`, `browserConnected=true`, no observed page.close/page.crash/context.close/browser.disconnected events, and the primary 30,000-ms timeout. The table later records `unexpectedPageClosed=true` during teardown. The early lifecycle boundary therefore does not support a crash/disconnect explanation for the primary deadline. Browser console records contain only the Angular development-mode log.

## Native event contract and scope

The test's `tab` helper only appends the expected identity and awaits `page.keyboard.press('Tab' | 'Shift+Tab')` with no options. The keyup listener captures identity/range/DOM without geometry, polling or RAF; `flush` reads/asserts after the burst. The actual Playwright 1.63.0 implementation in `node_modules/playwright-core/lib/coreBundle.js:21384-21413` sends modifier down, key down, optional delay only if explicitly set, key up, and modifier up. `keyboardPress` delegates to that path at `:53727`. Bundle SHA256: `549070af3acabb3efcc4f55bfe6210f9f7c2fcf633cf7eaa59bfe60719969171`. The collected events directly verify `isTrusted=true`, expected Shift direction and `defaultPrevented=false`.

Product `prepareTab` runs in the bubbling key handler, synchronously prepares a bounded window, and returns without cancelling Tab (`templates/angular/virtual-scroll.ts:65-96`). ADR 0003 requires native focus/default action and excludes per-key RAF waits. Increasing only the total case budget preserves that key-delivery contract; adding waits, synthetic key dispatch, skips, retries, fewer rows/contexts/controls, or weakening the assertions would not.

## Evidence ledger and NOT_RUN limits

| Claim | Status | Boundary / missing evidence |
| --- | --- | --- |
| Normal cases failed at their configured aggregate 30-second deadline | Verified | Error contexts and exact trace headers/boundary |
| Finite cumulative workload explains those failures better than a focus stall | Supported, high confidence | Millisecond native calls, correct saved prefixes, distinct progress positions; no fresh replay performed |
| Existing saved prefixes have expected focus, native events and bounds | Verified for saved events | Includes some explicitly labelled post-timeout evidence; missing table C backward/D cannot be filled in |
| A scoped 90-second case budget will complete all phases under normal two-worker load | Unknown / NOT_RUN | Requires actual supported-pipeline run on the changed snapshot |
| No product defect anywhere in this feature | Not claimed | Only these saved executions and inspected sources were investigated |
| Separate-context cases preserve the existing same-instance contract | Falsified for exact current coverage | They remove the A→B→C→D mixed-control history unless separately restored |

Methods used: standard-library Python `zipfile`/`json`/`hashlib` to inspect immutable ZIP records/attachments; `git show` plus SHA256 for source identity; targeted `rg` and line reads for the test/native driver/product contract. No fresh browser input, page navigation, test invocation, build, sync, generated-file modification, source modification, retry/resume, external publication, worktree creation, or subdelegation occurred. The existing large suite and the main agent's later focused run were not duplicated. Actual performance under a new budget, broad-suite success, and any cross-browser pass remain separate future evidence.

