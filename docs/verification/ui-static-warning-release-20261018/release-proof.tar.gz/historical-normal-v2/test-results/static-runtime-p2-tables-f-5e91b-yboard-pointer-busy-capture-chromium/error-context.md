# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: static-runtime-p2-tables.spec.ts >> fixture-column-resize-width R195 D: original catalog width sink keyboard/pointer/busy/capture
- Location: tests/ui/static-runtime-p2-tables.spec.ts:69:2

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "150px"
Received string:    ""
```

# Page snapshot

```yaml
- main [ref=e3]:
  - heading "表拡張の検証" [level=1] [ref=e4]
  - generic [ref=e5]:
    - text: 表示設定
    - combobox "表示設定" [ref=e7]:
      - option "guided"
      - option "dense" [selected]
  - generic [ref=e8]:
    - checkbox "RTL" [checked] [active] [ref=e9]
    - text: RTL
  - generic [ref=e10]:
    - checkbox "処理中" [ref=e11]
    - text: 処理中
  - generic [ref=e12]:
    - text: 保存の応答
    - combobox "保存の応答" [ref=e14]:
      - option "待機" [selected]
      - option "成功応答"
      - option "失敗応答"
  - generic [ref=e15]:
    - button "待機した要求を確定" [ref=e16]
    - button "待機した要求を失敗" [ref=e17]
    - button "先頭の行を除去" [ref=e18]
    - button "fixtureを戻す" [ref=e19]
  - paragraph [ref=e20]: "保存要求: 0"
  - paragraph [ref=e21]: 備品購入 / 0
  - generic [ref=e22]:
    - text: 読み取りを待機
    - checkbox "読み取りを待機" [ref=e23]
  - button "待機した読み取りを返す" [ref=e24]
  - heading "DataGrid" [level=2] [ref=e25]
  - generic "申請グリッド" [ref=e26]:
    - paragraph [ref=e27]: 矢印キーでセルを移動します。Shiftと矢印で範囲を選択し、EnterまたはF2で編集します。コピー・貼付けは選択したセルから行います。
    - generic [ref=e28]:
      - button "選択セルをコピー" [ref=e29] [cursor=pointer]
      - button "セルへ貼付け" [ref=e31] [cursor=pointer]
    - status
    - grid "申請グリッド" [ref=e34]:
      - caption [ref=e35]: 申請グリッド
      - rowgroup [ref=e36]:
        - row [ref=e37]:
          - columnheader "申請名" [ref=e38]
          - columnheader "金額" [ref=e39]
          - columnheader "申請日" [ref=e40]
          - columnheader "承認" [ref=e41]
          - columnheader "部署" [ref=e42]
      - rowgroup [ref=e43]:
        - row [ref=e44]:
          - gridcell [selected] [ref=e45]:
            - generic "申請名・備品購入" [ref=e46]:
              - group "申請名・備品購入" [ref=e47]:
                - generic [ref=e48]:
                  - generic [ref=e49]: 備品購入
                  - button "編集" [ref=e50] [cursor=pointer]
          - gridcell [ref=e52]:
            - generic "金額・備品購入" [ref=e53]:
              - group "金額・備品購入" [ref=e54]:
                - generic [ref=e55]:
                  - generic [ref=e56]: "0"
                  - button "編集" [ref=e57] [cursor=pointer]
          - gridcell [ref=e59]:
            - generic "申請日・備品購入" [ref=e60]:
              - group "申請日・備品購入" [ref=e61]:
                - generic [ref=e62]:
                  - generic [ref=e63]: 2026-10-01
                  - button "編集" [ref=e64] [cursor=pointer]
          - gridcell [ref=e66]:
            - generic "承認・備品購入" [ref=e67]:
              - group "承認・備品購入" [ref=e68]:
                - generic [ref=e69]:
                  - generic [ref=e70]: いいえ
                  - button "編集" [ref=e71] [cursor=pointer]
          - gridcell [ref=e73]:
            - generic "部署・備品購入" [ref=e74]:
              - group "部署・備品購入" [ref=e75]:
                - generic [ref=e76]:
                  - generic [ref=e77]: 総務
                  - button "編集" [ref=e78] [cursor=pointer]
        - row [ref=e80]:
          - gridcell [ref=e81]:
            - generic "申請名・交通費" [ref=e82]:
              - group "申請名・交通費" [ref=e83]:
                - generic [ref=e84]:
                  - generic [ref=e85]: 交通費
                  - button "編集" [ref=e86] [cursor=pointer]
          - gridcell [ref=e88]:
            - generic "金額・交通費" [ref=e89]:
              - group "金額・交通費" [ref=e90]:
                - generic [ref=e91]:
                  - generic [ref=e92]: 2,000
                  - button "編集" [ref=e93] [cursor=pointer]
          - gridcell [ref=e95]:
            - generic "申請日・交通費" [ref=e96]:
              - group "申請日・交通費" [ref=e97]:
                - generic [ref=e98]:
                  - generic [ref=e99]: 2026-10-02
                  - button "編集" [ref=e100] [cursor=pointer]
          - gridcell [ref=e102]:
            - generic "承認・交通費" [ref=e103]:
              - group "承認・交通費" [ref=e104]:
                - generic [ref=e105]:
                  - generic [ref=e106]: はい
                  - button "編集" [ref=e107] [cursor=pointer]
          - gridcell [ref=e109]:
            - generic "部署・交通費" [ref=e110]:
              - group "部署・交通費" [ref=e111]:
                - generic [ref=e112]:
                  - generic [ref=e113]: 総務
                  - button "編集" [ref=e114] [cursor=pointer]
        - row [ref=e116]:
          - gridcell [ref=e117]:
            - generic "申請名・未取得" [ref=e118]:
              - group "申請名・未取得" [ref=e119]:
                - generic [ref=e120]:
                  - generic [ref=e121]: 未取得
                  - button "編集" [ref=e122] [cursor=pointer]
          - gridcell [ref=e124]:
            - generic "金額・未取得" [ref=e125]:
              - group "金額・未取得" [ref=e126]:
                - generic [ref=e127]:
                  - generic [ref=e128]: 未取得
                  - button "編集" [ref=e129] [cursor=pointer]
          - gridcell [ref=e131]:
            - generic "申請日・未取得" [ref=e132]:
              - group "申請日・未取得" [ref=e133]:
                - generic [ref=e134]:
                  - generic [ref=e135]: 未取得
                  - button "編集" [ref=e136] [cursor=pointer]
          - gridcell [ref=e138]:
            - generic "承認・未取得" [ref=e139]:
              - group "承認・未取得" [ref=e140]:
                - generic [ref=e141]:
                  - generic [ref=e142]: 未取得
                  - button "編集" [ref=e143] [cursor=pointer]
          - gridcell [ref=e145]:
            - generic "部署・未取得" [ref=e146]:
              - group "部署・未取得" [ref=e147]:
                - generic [ref=e148]:
                  - generic [ref=e149]: 経理
                  - button "編集" [ref=e150] [cursor=pointer]
  - heading "CellEditor" [level=2] [ref=e152]
  - generic [ref=e153]:
    - button "編集元を更新" [ref=e154]
    - button "編集キーを変更" [ref=e155]
  - generic "申請名の編集" [ref=e156]:
    - group "申請名の編集" [ref=e157]:
      - generic [ref=e158]:
        - generic [ref=e159]: 備品購入
        - button "編集" [ref=e160] [cursor=pointer]
  - paragraph [ref=e162]: 表示
  - heading "RowEditor" [level=2] [ref=e163]
  - generic "申請行の編集" [ref=e164]:
    - region "申請行の編集" [ref=e165]:
      - generic [ref=e166]:
        - generic [ref=e167]: 備品購入 / 0 / 2026-10-01 / いいえ / 総務
        - button "編集" [ref=e168] [cursor=pointer]
  - heading "列条件" [level=2] [ref=e170]
  - region "複数条件" [ref=e171]:
    - generic "申請名の列条件" [ref=e172]:
      - group "申請名の列条件" [ref=e173]:
        - generic [ref=e175]:
          - generic [ref=e176]:
            - text: 申請名の比較方法
            - combobox "申請名の比較方法" [ref=e178]:
              - option "含む" [selected]
              - option "で始まる"
              - option "等しい"
              - option "未取得"
          - generic [ref=e179]:
            - text: 申請名の条件
            - searchbox "申請名の条件" [ref=e180]
          - button "申請名の条件 1 を解除" [ref=e181] [cursor=pointer]:
            - generic [ref=e182]: 条件を解除
        - button "申請名の条件を追加" [ref=e183] [cursor=pointer]
    - generic "金額の列条件" [ref=e185]:
      - group "金額の列条件" [ref=e186]:
        - generic [ref=e188]:
          - generic [ref=e189]:
            - text: 金額の比較方法
            - combobox "金額の比較方法" [ref=e191]:
              - option "等しい" [selected]
              - option "以上"
              - option "以下"
              - option "未取得"
          - generic [ref=e192]:
            - text: 金額の条件
            - spinbutton "金額の条件" [ref=e193]
          - button "金額の条件 1 を解除" [ref=e194] [cursor=pointer]:
            - generic [ref=e195]: 条件を解除
        - button "金額の条件を追加" [ref=e196] [cursor=pointer]
    - generic "申請日の列条件" [ref=e198]:
      - group "申請日の列条件" [ref=e199]:
        - generic [ref=e201]:
          - generic [ref=e202]:
            - text: 申請日の比較方法
            - combobox "申請日の比較方法" [ref=e204]:
              - option "等しい" [selected]
              - option "より後"
              - option "より前"
              - option "未取得"
          - generic [ref=e205]:
            - text: 申請日の条件
            - textbox "申請日の条件" [ref=e206]
          - button "申請日の条件 1 を解除" [ref=e207] [cursor=pointer]:
            - generic [ref=e208]: 条件を解除
        - button "申請日の条件を追加" [ref=e209] [cursor=pointer]
    - generic "承認の列条件" [ref=e211]:
      - group "承認の列条件" [ref=e212]:
        - generic [ref=e214]:
          - generic [ref=e215]:
            - text: 承認の比較方法
            - combobox "承認の比較方法" [ref=e217]:
              - option "等しい" [selected]
              - option "未取得"
          - generic [ref=e218]:
            - text: 承認の条件
            - combobox "承認の条件" [ref=e220]:
              - option "条件なし" [selected]
              - option "はい"
              - option "いいえ"
          - button "承認の条件 1 を解除" [ref=e221] [cursor=pointer]:
            - generic [ref=e222]: 条件を解除
        - button "承認の条件を追加" [ref=e223] [cursor=pointer]
    - generic "部署の列条件" [ref=e225]:
      - group "部署の列条件" [ref=e226]:
        - generic [ref=e228]:
          - generic [ref=e229]:
            - text: 部署の比較方法
            - combobox "部署の比較方法" [ref=e231]:
              - option "等しい" [selected]
              - option "未取得"
          - generic [ref=e232]:
            - text: 部署の条件
            - combobox "部署の条件" [ref=e234]:
              - option "条件なし" [selected]
              - option "総務"
              - option "経理"
          - button "部署の条件 1 を解除" [ref=e235] [cursor=pointer]:
            - generic [ref=e236]: 条件を解除
        - button "部署の条件を追加" [ref=e237] [cursor=pointer]
  - paragraph [ref=e239]: "検索結果: 1,2,3"
  - heading "条件と列設定" [level=2] [ref=e240]
  - generic "申請の検索条件" [ref=e241]:
    - group "申請の検索条件" [ref=e242]:
      - generic [ref=e244]:
        - text: 全体検索
        - searchbox "全体検索" [ref=e245]
      - button "検索を解除" [disabled] [ref=e246]
      - generic "適用条件" [ref=e248]:
        - list
        - paragraph [ref=e249]: 適用条件はありません。
      - generic [ref=e250]:
        - text: 保存条件の名前
        - textbox "保存条件の名前" [ref=e251]
      - button "条件を保存" [disabled] [ref=e252]
  - generic [ref=e254]:
    - text: 列設定の最小幅を256pxにする
    - checkbox "列設定の最小幅を256pxにする" [ref=e255]
  - generic [ref=e256]:
    - text: 列設定を隠す
    - checkbox "列設定を隠す" [ref=e257]
  - generic [ref=e258]:
    - text: 列設定を取り除く
    - checkbox "列設定を取り除く" [ref=e259]
  - generic "列の設定" [ref=e260]:
    - group [ref=e261]:
      - generic "列の設定" [ref=e262] [cursor=pointer]
      - option "固定しない" [selected]
      - option "先頭側"
      - option "末尾側"
      - option "固定しない" [selected]
      - option "先頭側"
      - option "末尾側"
      - option "固定しない" [selected]
      - option "先頭側"
      - option "末尾側"
      - option "固定しない" [selected]
      - option "先頭側"
      - option "末尾側"
      - option "固定しない" [selected]
      - option "先頭側"
      - option "末尾側"
  - generic "申請一覧の操作" [ref=e263]:
    - generic [ref=e264]:
      - generic [ref=e265]:
        - text: 全体検索
        - searchbox "全体検索" [ref=e266]
      - button "検索を解除" [disabled] [ref=e267]
      - generic "列の設定" [ref=e269]:
        - group [ref=e270]:
          - generic "列の設定" [ref=e271] [cursor=pointer]
          - option "固定しない" [selected]
          - option "先頭側"
          - option "末尾側"
          - option "固定しない" [selected]
          - option "先頭側"
          - option "末尾側"
          - option "固定しない" [selected]
          - option "先頭側"
          - option "末尾側"
          - option "固定しない" [selected]
          - option "先頭側"
          - option "末尾側"
          - option "固定しない" [selected]
          - option "先頭側"
          - option "末尾側"
      - button "一括確認 (2件)" [ref=e272] [cursor=pointer]
      - generic [ref=e274]:
        - text: 出力対象
        - combobox "出力対象" [ref=e276]:
          - option "表示ページ" [selected]
          - option "取得済み検索結果"
          - option "取得済み選択行"
          - option "受け取った全行"
      - button "表をコピー" [ref=e277] [cursor=pointer]
      - button "CSVを出力" [ref=e279] [cursor=pointer]
      - button "表を印刷" [ref=e281] [cursor=pointer]
  - paragraph
  - paragraph
  - heading "列境界" [level=2] [ref=e283]
  - paragraph [ref=e284]: 可変幅 (150px)
  - region "列幅の操作領域" [ref=e285]:
    - separator "申請名の列幅" [ref=e287]
  - heading "Native DataTable" [level=2] [ref=e288]
  - generic [ref=e289]:
    - button "内容幅と単一選択にする" [ref=e290]
    - button "申請名を同じにする" [ref=e291]
  - generic [ref=e292]:
    - text: 表の編集方式
    - combobox "表の編集方式" [ref=e294]:
      - option "なし" [selected]
      - option "セル"
      - option "行"
  - generic [ref=e295]:
    - checkbox "表を部署でグループ化" [ref=e296]
    - text: 表を部署でグループ化
  - generic [ref=e297]:
    - checkbox "表の列条件" [ref=e298]
    - text: 表の列条件
  - generic [ref=e299]:
    - checkbox "サーバー処理" [ref=e300]
    - text: サーバー処理
  - generic "拡張申請一覧" [ref=e301]:
    - generic [ref=e302]:
      - generic [ref=e303]:
        - text: 全体検索
        - searchbox "全体検索" [ref=e304]
      - button "検索を解除" [disabled] [ref=e305]
      - group [ref=e307]:
        - generic "列の設定" [ref=e308] [cursor=pointer]
        - option "固定しない" [selected]
        - option "先頭側"
        - option "末尾側"
        - option "固定しない" [selected]
        - option "先頭側"
        - option "末尾側"
        - option "固定しない" [selected]
        - option "先頭側"
        - option "末尾側"
        - option "固定しない" [selected]
        - option "先頭側"
        - option "末尾側"
        - option "固定しない" [selected]
        - option "先頭側"
        - option "末尾側"
    - status [ref=e309]
    - region "拡張申請一覧の表領域" [ref=e310]:
      - table [ref=e311]:
        - caption [ref=e312]: 拡張申請一覧
        - rowgroup [ref=e320]:
          - row [ref=e321]:
            - columnheader [ref=e322]:
              - checkbox "このページをすべて選択" [ref=e323]
            - columnheader "申請の情報" [ref=e324]
            - columnheader "担当" [ref=e325]
          - row [ref=e326]:
            - columnheader [ref=e327]:
              - button "申請名で並べ替え" [ref=e328] [cursor=pointer]:
                - generic [ref=e329]: 申請名
              - separator "申請名の列境界" [ref=e330]
            - columnheader "申請の詳細" [ref=e331]
            - columnheader [ref=e332]:
              - button "承認で並べ替え" [ref=e333] [cursor=pointer]:
                - generic [ref=e334]: 承認
              - separator "承認の列境界" [ref=e335]
            - columnheader [ref=e336]:
              - button "部署で並べ替え" [ref=e337] [cursor=pointer]:
                - generic [ref=e338]: 部署
              - separator "部署の列境界" [ref=e339]
          - row [ref=e340]:
            - columnheader [ref=e341]:
              - button "金額で並べ替え" [ref=e342] [cursor=pointer]:
                - generic [ref=e343]: 金額
              - separator "金額の列境界" [ref=e344]
            - columnheader [ref=e345]:
              - button "申請日で並べ替え" [ref=e346] [cursor=pointer]:
                - generic [ref=e347]: 申請日
              - separator "申請日の列境界" [ref=e348]
        - rowgroup [ref=e349]:
          - row [ref=e350]:
            - cell [ref=e351]:
              - 'checkbox "行を選択: 備品購入" [ref=e352]'
            - cell "備品購入" [ref=e353]
            - cell "0" [ref=e354]
            - cell "2026-10-01" [ref=e355]
            - cell "いいえ" [ref=e356]
            - cell "総務" [ref=e357]
          - row [ref=e358]:
            - cell [ref=e359]:
              - 'checkbox "行を選択: 交通費" [ref=e360]'
            - cell "交通費" [ref=e361]
            - cell "2,000" [ref=e362]
            - cell "2026-10-02" [ref=e363]
            - cell "はい" [ref=e364]
            - cell "総務" [ref=e365]
          - row [ref=e366]:
            - cell [ref=e367]:
              - 'checkbox "行を選択: 追加申請 1" [ref=e368]'
            - cell "追加申請 1" [ref=e369]
            - cell "0" [ref=e370]
            - cell "2026-10-01" [ref=e371]
            - cell "いいえ" [ref=e372]
            - cell "総務" [ref=e373]
          - row [ref=e374]:
            - cell [ref=e375]:
              - 'checkbox "行を選択: 追加申請 2" [ref=e376]'
            - cell "追加申請 2" [ref=e377]
            - cell "1,000" [ref=e378]
            - cell "2026-10-02" [ref=e379]
            - cell "はい" [ref=e380]
            - cell "総務" [ref=e381]
          - row [ref=e382]:
            - cell [ref=e383]:
              - 'checkbox "行を選択: 追加申請 3" [ref=e384]'
            - cell "追加申請 3" [ref=e385]
            - cell "2,000" [ref=e386]
            - cell "未取得" [ref=e387]
            - cell "未取得" [ref=e388]
            - cell "経理" [ref=e389]
          - row [ref=e390]:
            - cell [ref=e391]:
              - 'checkbox "行を選択: 追加申請 4" [ref=e392]'
            - cell "追加申請 4" [ref=e393]
            - cell "3,000" [ref=e394]
            - cell "2026-10-01" [ref=e395]
            - cell "いいえ" [ref=e396]
            - cell "総務" [ref=e397]
          - row [ref=e398]:
            - cell [ref=e399]:
              - 'checkbox "行を選択: 追加申請 5" [ref=e400]'
            - cell "追加申請 5" [ref=e401]
            - cell "4,000" [ref=e402]
            - cell "2026-10-02" [ref=e403]
            - cell "はい" [ref=e404]
            - cell "総務" [ref=e405]
          - row [ref=e406]:
            - cell [ref=e407]:
              - 'checkbox "行を選択: 追加申請 6" [ref=e408]'
            - cell "追加申請 6" [ref=e409]
            - cell "5,000" [ref=e410]
            - cell "未取得" [ref=e411]
            - cell "未取得" [ref=e412]
            - cell "経理" [ref=e413]
          - row [ref=e414]:
            - cell [ref=e415]:
              - 'checkbox "行を選択: 追加申請 7" [ref=e416]'
            - cell "追加申請 7" [ref=e417]
            - cell "6,000" [ref=e418]
            - cell "2026-10-01" [ref=e419]
            - cell "いいえ" [ref=e420]
            - cell "総務" [ref=e421]
          - row [ref=e422]:
            - cell [ref=e423]:
              - 'checkbox "行を選択: 追加申請 8" [ref=e424]'
            - cell "追加申請 8" [ref=e425]
            - cell "7,000" [ref=e426]
            - cell "2026-10-02" [ref=e427]
            - cell "はい" [ref=e428]
            - cell "総務" [ref=e429]
          - row [ref=e430]:
            - cell [ref=e431]:
              - 'checkbox "行を選択: 追加申請 9" [ref=e432]'
            - cell "追加申請 9" [ref=e433]
            - cell "8,000" [ref=e434]
            - cell "未取得" [ref=e435]
            - cell "未取得" [ref=e436]
            - cell "経理" [ref=e437]
          - row [ref=e438]:
            - cell [ref=e439]:
              - 'checkbox "行を選択: 追加申請 10" [ref=e440]'
            - cell "追加申請 10" [ref=e441]
            - cell "9,000" [ref=e442]
            - cell "2026-10-01" [ref=e443]
            - cell "いいえ" [ref=e444]
            - cell "総務" [ref=e445]
          - row [ref=e446]:
            - cell [ref=e447]:
              - 'checkbox "行を選択: 追加申請 11" [ref=e448]'
            - cell "追加申請 11" [ref=e449]
            - cell "10,000" [ref=e450]
            - cell "2026-10-02" [ref=e451]
            - cell "はい" [ref=e452]
            - cell "総務" [ref=e453]
          - row [ref=e454]:
            - cell [ref=e455]:
              - 'checkbox "行を選択: 追加申請 12" [ref=e456]'
            - cell "追加申請 12" [ref=e457]
            - cell "11,000" [ref=e458]
            - cell "未取得" [ref=e459]
            - cell "未取得" [ref=e460]
            - cell "経理" [ref=e461]
          - row [ref=e462]:
            - cell [ref=e463]:
              - 'checkbox "行を選択: 未取得" [ref=e464]'
            - cell "未取得" [ref=e465]
            - cell "未取得" [ref=e466]
            - cell "未取得" [ref=e467]
            - cell "未取得" [ref=e468]
            - cell "経理" [ref=e469]
        - rowgroup [ref=e470]:
          - row [ref=e471]:
            - rowheader "検索結果の集計" [ref=e472]
          - row [ref=e473]:
            - cell [ref=e474]
            - cell [ref=e475]
            - 'cell "金額 合計: 68,000 (既知 14件・未取得 1件)" [ref=e476]'
            - cell [ref=e478]
            - cell [ref=e479]
            - cell [ref=e480]
      - generic "拡張申請一覧の追加取得" [ref=e481]:
        - region "拡張申請一覧の追加取得" [ref=e482]:
          - button "さらに読み込む" [ref=e484] [cursor=pointer]
    - generic "拡張申請一覧の出力と一括操作" [ref=e486]:
      - generic [ref=e487]:
        - generic [ref=e488]:
          - text: 出力対象
          - combobox "出力対象" [ref=e490]:
            - option "表示ページ" [selected]
            - option "取得済み検索結果"
            - option "取得済み選択行"
            - option "受け取った全行"
        - button "表をコピー" [ref=e491] [cursor=pointer]
        - button "CSVを出力" [ref=e493] [cursor=pointer]
        - button "表を印刷" [ref=e495] [cursor=pointer]
  - generic [ref=e497]:
    - button "5件ずつページ表示" [ref=e498]
    - button "全列幅を320pxにする" [ref=e499]
  - paragraph
  - paragraph [ref=e500]: "追加要求: 0"
  - generic [ref=e501]:
    - button "追加取得を確定" [ref=e502]
    - button "追加取得を失敗" [ref=e503]
    - button "追加取得を終端" [ref=e504]
  - heading "Virtual DataTable" [level=2] [ref=e505]
  - generic "仮想申請一覧" [ref=e506]:
    - generic [ref=e507]:
      - generic [ref=e508]:
        - text: 全体検索
        - searchbox "全体検索" [ref=e509]
      - button "検索を解除" [disabled] [ref=e510]
      - group [ref=e512]:
        - generic "列の設定" [ref=e513] [cursor=pointer]
        - option "固定しない" [selected]
        - option "先頭側"
        - option "末尾側"
        - option "固定しない" [selected]
        - option "先頭側"
        - option "末尾側"
        - option "固定しない" [selected]
        - option "先頭側"
        - option "末尾側"
        - option "固定しない" [selected]
        - option "先頭側"
        - option "末尾側"
        - option "固定しない" [selected]
        - option "先頭側"
        - option "末尾側"
    - status [ref=e514]
    - table "仮想申請一覧" [ref=e516]:
      - paragraph [ref=e517]: 仮想申請一覧 (1000件の取得済み行)
      - generic [ref=e518]:
        - rowgroup [ref=e519]:
          - row [ref=e520]:
            - columnheader [ref=e521]:
              - checkbox "取得済み表示行をすべて選択" [ref=e522]
            - columnheader [ref=e523]:
              - button "申請名で並べ替え" [ref=e524] [cursor=pointer]:
                - generic [ref=e525]: 申請名
            - columnheader [ref=e526]:
              - button "金額で並べ替え" [ref=e527] [cursor=pointer]:
                - generic [ref=e528]: 金額
            - columnheader [ref=e529]:
              - button "申請日で並べ替え" [ref=e530] [cursor=pointer]:
                - generic [ref=e531]: 申請日
            - columnheader [ref=e532]:
              - button "承認で並べ替え" [ref=e533] [cursor=pointer]:
                - generic [ref=e534]: 承認
            - columnheader [ref=e535]:
              - button "部署で並べ替え" [ref=e536] [cursor=pointer]:
                - generic [ref=e537]: 部署
        - rowgroup "仮想申請一覧の仮想スクロール領域" [ref=e538]:
          - generic [ref=e540]:
            - row [ref=e542]:
              - cell [ref=e543]:
                - 'checkbox "行を選択: 仮想申請 1" [ref=e544]'
              - cell "仮想申請 1" [ref=e545]
              - cell "0" [ref=e547]
              - cell "2026-10-01" [ref=e549]
              - cell "いいえ" [ref=e551]
              - cell "総務" [ref=e553]
            - row [ref=e556]:
              - cell [ref=e557]:
                - 'checkbox "行を選択: 仮想申請 2" [ref=e558]'
              - cell "仮想申請 2" [ref=e559]
              - cell "1" [ref=e561]
              - cell "2026-10-02" [ref=e563]
              - cell "はい" [ref=e565]
              - cell "総務" [ref=e567]
            - row [ref=e570]:
              - cell [ref=e571]:
                - 'checkbox "行を選択: 仮想申請 3" [ref=e572]'
              - cell "仮想申請 3" [ref=e573]
              - cell "2" [ref=e575]
              - cell "未取得" [ref=e577]
              - cell "未取得" [ref=e579]
              - cell "経理" [ref=e581]
            - row [ref=e584]:
              - cell [ref=e585]:
                - 'checkbox "行を選択: 仮想申請 4" [ref=e586]'
              - cell "仮想申請 4" [ref=e587]
              - cell "3" [ref=e589]
              - cell "2026-10-01" [ref=e591]
              - cell "いいえ" [ref=e593]
              - cell "総務" [ref=e595]
            - row [ref=e598]:
              - cell [ref=e599]:
                - 'checkbox "行を選択: 仮想申請 5" [ref=e600]'
              - cell "仮想申請 5" [ref=e601]
              - cell "4" [ref=e603]
              - cell "2026-10-02" [ref=e605]
              - cell "はい" [ref=e607]
              - cell "総務" [ref=e609]
            - row [ref=e612]:
              - cell [ref=e613]:
                - 'checkbox "行を選択: 仮想申請 6" [ref=e614]'
              - cell "仮想申請 6" [ref=e615]
              - cell "5" [ref=e617]
              - cell "未取得" [ref=e619]
              - cell "未取得" [ref=e621]
              - cell "経理" [ref=e623]
            - row [ref=e626]:
              - cell [ref=e627]:
                - 'checkbox "行を選択: 仮想申請 7" [ref=e628]'
              - cell "仮想申請 7" [ref=e629]
              - cell "6" [ref=e631]
              - cell "2026-10-01" [ref=e633]
              - cell "いいえ" [ref=e635]
              - cell "総務" [ref=e637]
            - row [ref=e640]:
              - cell [ref=e641]:
                - 'checkbox "行を選択: 仮想申請 8" [ref=e642]'
              - cell "仮想申請 8" [ref=e643]
              - cell "7" [ref=e645]
              - cell "2026-10-02" [ref=e647]
              - cell "はい" [ref=e649]
              - cell "総務" [ref=e651]
            - row [ref=e654]:
              - cell [ref=e655]:
                - 'checkbox "行を選択: 仮想申請 9" [ref=e656]'
              - cell "仮想申請 9" [ref=e657]
              - cell "8" [ref=e659]
              - cell "未取得" [ref=e661]
              - cell "未取得" [ref=e663]
              - cell "経理" [ref=e665]
  - button "仮想表の500番目へ" [ref=e668]
  - paragraph [ref=e669]: "仮想位置: 0"
  - heading "通常表への復旧" [level=2] [ref=e670]
  - generic "復旧する申請一覧" [ref=e671]:
    - status [ref=e672]
    - alert [ref=e673]: 表の設定を確認してください。固定行・固定列・集計・階層見出し・詳細・編集・行操作は通常表を選択してください。
    - button "通常表へ切り替える" [ref=e674] [cursor=pointer]
  - heading "TableContainer" [level=2] [ref=e676]
  - generic [ref=e677]:
    - text: 領域のスクロール方向
    - combobox "領域のスクロール方向" [ref=e679]:
      - option "横"
      - option "縦"
      - option "両方向" [selected]
      - option "なし"
  - button "表領域を70pxへ" [ref=e680]
  - paragraph [ref=e681]: 0 / 0
  - region "サイズ付き表領域" [ref=e682]:
    - paragraph [ref=e683]: 表領域の見出し
    - table [ref=e684]:
      - caption [ref=e685]: native caption
      - rowgroup [ref=e686]:
        - row [ref=e687]:
          - columnheader "値" [ref=e688]
      - rowgroup [ref=e689]:
        - row [ref=e690]:
          - cell "備品購入" [ref=e691]
        - row [ref=e692]:
          - cell "交通費" [ref=e693]
        - row [ref=e694]:
          - cell "未取得" [ref=e695]
        - row [ref=e696]:
          - cell "追加申請 1" [ref=e697]
        - row [ref=e698]:
          - cell "追加申請 2" [ref=e699]
        - row [ref=e700]:
          - cell "追加申請 3" [ref=e701]
        - row [ref=e702]:
          - cell "追加申請 4" [ref=e703]
        - row [ref=e704]:
          - cell "追加申請 5" [ref=e705]
        - row [ref=e706]:
          - cell "追加申請 6" [ref=e707]
        - row [ref=e708]:
          - cell "追加申請 7" [ref=e709]
        - row [ref=e710]:
          - cell "追加申請 8" [ref=e711]
        - row [ref=e712]:
          - cell "追加申請 9" [ref=e713]
        - row [ref=e714]:
          - cell "追加申請 10" [ref=e715]
        - row [ref=e716]:
          - cell "追加申請 11" [ref=e717]
        - row [ref=e718]:
          - cell "追加申請 12" [ref=e719]
  - heading "投影入力の表" [level=2] [ref=e720]
  - generic "投影入力の一覧" [ref=e721]:
    - status [ref=e722]
    - region "投影入力の一覧の表領域" [ref=e723]:
      - table [ref=e724]:
        - caption [ref=e725]: 投影入力の一覧
        - rowgroup [ref=e732]:
          - row [ref=e733]:
            - columnheader [ref=e734]:
              - button "申請名で並べ替え" [ref=e735] [cursor=pointer]:
                - generic [ref=e736]: 申請名
            - columnheader [ref=e737]:
              - button "金額で並べ替え" [ref=e738] [cursor=pointer]:
                - generic [ref=e739]: 金額
            - columnheader [ref=e740]:
              - button "申請日で並べ替え" [ref=e741] [cursor=pointer]:
                - generic [ref=e742]: 申請日
            - columnheader [ref=e743]:
              - button "承認で並べ替え" [ref=e744] [cursor=pointer]:
                - generic [ref=e745]: 承認
            - columnheader [ref=e746]:
              - button "部署で並べ替え" [ref=e747] [cursor=pointer]:
                - generic [ref=e748]: 部署
        - rowgroup [ref=e749]:
          - row [ref=e750]:
            - cell [ref=e751]:
              - generic [ref=e752]:
                - text: 投影名:1
                - textbox "投影名:1" [ref=e753]: 備品購入
            - cell "0" [ref=e754]
            - cell "2026-10-01" [ref=e755]
            - cell "いいえ" [ref=e756]
            - cell "総務" [ref=e757]
          - row [ref=e758]:
            - cell [ref=e759]:
              - generic [ref=e760]:
                - text: 投影名:2
                - textbox "投影名:2" [ref=e761]: 交通費
            - cell "2,000" [ref=e762]
            - cell "2026-10-02" [ref=e763]
            - cell "はい" [ref=e764]
            - cell "総務" [ref=e765]
          - row [ref=e766]:
            - cell [ref=e767]:
              - generic [ref=e768]:
                - text: 投影名:3
                - textbox "投影名:3" [ref=e769]: 未取得
            - cell "未取得" [ref=e770]
            - cell "未取得" [ref=e771]
            - cell "未取得" [ref=e772]
            - cell "経理" [ref=e773]
  - button "投影行を除去" [ref=e774]
  - heading "TreeGrid" [level=2] [ref=e775]
  - generic "部署の申請" [ref=e776]:
    - generic "部署の申請" [ref=e777]:
      - paragraph [ref=e778]: 矢印キーでセルを移動します。Shiftと矢印で範囲を選択し、EnterまたはF2で編集します。コピー・貼付けは選択したセルから行います。先頭セルの左右で階層を開閉し、Spaceで行を選択します。
      - generic [ref=e779]:
        - button "選択セルをコピー" [ref=e780] [cursor=pointer]
        - button "セルへ貼付け" [ref=e782] [cursor=pointer]
      - status
      - treegrid "部署の申請" [ref=e785]:
        - caption [ref=e786]: 部署の申請
        - rowgroup [ref=e787]:
          - row [ref=e788]:
            - columnheader "申請名" [ref=e789]
            - columnheader "金額" [ref=e790]
            - columnheader "申請日" [ref=e791]
            - columnheader "承認" [ref=e792]
            - columnheader "部署" [ref=e793]
        - rowgroup [ref=e794]:
          - row [level=1] [ref=e795]:
            - gridcell [selected] [ref=e796]:
              - generic [ref=e797]:
                - 'button "展開: 総務の申請" [ref=e798] [cursor=pointer]':
                  - generic [ref=e799]: +
                - 'checkbox "行を選択: 総務の申請" [ref=e800]'
              - generic "申請名・総務の申請" [ref=e801]:
                - group "申請名・総務の申請" [ref=e802]:
                  - generic [ref=e803]:
                    - generic [ref=e804]: 総務の申請
                    - button "編集" [ref=e805] [cursor=pointer]
            - gridcell [ref=e807]:
              - generic "金額・総務の申請" [ref=e808]:
                - group "金額・総務の申請" [ref=e809]:
                  - generic [ref=e810]:
                    - generic [ref=e811]: "0"
                    - button "編集" [ref=e812] [cursor=pointer]
            - gridcell [ref=e814]:
              - generic "申請日・総務の申請" [ref=e815]:
                - group "申請日・総務の申請" [ref=e816]:
                  - generic [ref=e817]:
                    - generic [ref=e818]: 2026-10-01
                    - button "編集" [ref=e819] [cursor=pointer]
            - gridcell [ref=e821]:
              - generic "承認・総務の申請" [ref=e822]:
                - group "承認・総務の申請" [ref=e823]:
                  - generic [ref=e824]:
                    - generic [ref=e825]: いいえ
                    - button "編集" [ref=e826] [cursor=pointer]
            - gridcell [ref=e828]:
              - generic "部署・総務の申請" [ref=e829]:
                - group "部署・総務の申請" [ref=e830]:
                  - generic [ref=e831]:
                    - generic [ref=e832]: 総務
                    - button "編集" [ref=e833] [cursor=pointer]
          - row [level=1] [ref=e835]:
            - gridcell [ref=e836]:
              - 'checkbox "行を選択: 経理の申請" [ref=e838]'
              - generic "申請名・経理の申請" [ref=e839]:
                - group "申請名・経理の申請" [ref=e840]:
                  - generic [ref=e841]:
                    - generic [ref=e842]: 経理の申請
                    - button "編集" [ref=e843] [cursor=pointer]
            - gridcell [ref=e845]:
              - generic "金額・経理の申請" [ref=e846]:
                - group "金額・経理の申請" [ref=e847]:
                  - generic [ref=e848]:
                    - generic [ref=e849]: 未取得
                    - button "編集" [ref=e850] [cursor=pointer]
            - gridcell [ref=e852]:
              - generic "申請日・経理の申請" [ref=e853]:
                - group "申請日・経理の申請" [ref=e854]:
                  - generic [ref=e855]:
                    - generic [ref=e856]: 未取得
                    - button "編集" [ref=e857] [cursor=pointer]
            - gridcell [ref=e859]:
              - generic "承認・経理の申請" [ref=e860]:
                - group "承認・経理の申請" [ref=e861]:
                  - generic [ref=e862]:
                    - generic [ref=e863]: 未取得
                    - button "編集" [ref=e864] [cursor=pointer]
            - gridcell [ref=e866]:
              - generic "部署・経理の申請" [ref=e867]:
                - group "部署・経理の申請" [ref=e868]:
                  - generic [ref=e869]:
                    - generic [ref=e870]: 経理
                    - button "編集" [ref=e871] [cursor=pointer]
  - paragraph [ref=e873]: "選択:"
  - button "階層をすべて閉じる" [ref=e874]
  - generic [ref=e875]:
    - text: 外部入力
    - textbox "外部入力" [ref=e876]: 外部focus
  - region "文字列IDの検証" [ref=e878]:
    - button "文字列IDの表を開く" [ref=e879]
```

# Test source

```ts
  1  | import {test,expect,type Page,type Locator} from '@playwright/test';
  2  | const modes=[{name:'A',profile:'guided',width:1280,font:'100%',dir:'ltr',reduce:false},{name:'B',profile:'dense',width:320,font:'200%',dir:'rtl',reduce:true},{name:'C',profile:'guided',width:320,font:'200%',dir:'ltr',reduce:false},{name:'D',profile:'dense',width:1280,font:'100%',dir:'rtl',reduce:true}] as const;
  3  | type Mode={name:string;profile:string;width:number;font:string;dir:string;reduce:boolean};
  4  | async function ready(page:Page,m:Mode){await page.setViewportSize({width:m.width,height:900});await page.emulateMedia({reducedMotion:m.reduce?'reduce':'no-preference'});await page.goto('/catalog/static-runtime');await expect.poll(()=>page.evaluate(()=>typeof (window as any).__runtime?.create)).toBe('function');await page.evaluate(m=>{document.documentElement.style.fontSize=m.font;document.documentElement.dir=m.dir;document.documentElement.setAttribute('data-ui-profile',m.profile);document.querySelector<HTMLElement>('main')!.style.padding='0';},m);}
  5  | async function create(page:Page,name:string,inputs:Record<string,unknown>){const id=await page.evaluate(({name,inputs})=>(window as any).__runtime.create(name,inputs),{name,inputs});return {id,host:page.locator(`[data-runtime-id="${id}"]`)};}
  6  | async function update(page:Page,id:number,inputs:Record<string,unknown>){await page.evaluate(({id,inputs})=>(window as any).__runtime.update(id,inputs),{id,inputs});}
  7  | async function destroy(page:Page,id:number,host:Locator){const before=await page.evaluate(id=>(window as any).__runtime.inspect(id),id);expect(before.errors).toEqual([]);await page.evaluate(id=>(window as any).__runtime.destroy(id),id);await expect(host).toHaveCount(0);await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));const after=await page.evaluate(id=>(window as any).__runtime.inspect(id),id);expect(after.errors).toEqual([]);expect(after.events).toEqual(before.events);}
  8  | async function contained(locator:Locator){const measurements=await locator.evaluateAll(nodes=>nodes.map(n=>{const e=n as HTMLElement,r=e.getBoundingClientRect(),p=e.parentElement!.getBoundingClientRect();return {width:r.width,parent:p.width,scroll:e.scrollWidth,client:e.clientWidth,left:r.left,right:r.right,pLeft:p.left,pRight:p.right};}));for(const x of measurements){expect(x.width).toBeGreaterThan(0);expect(x.left).toBeGreaterThanOrEqual(x.pLeft-1);expect(x.right).toBeLessThanOrEqual(x.pRight+1);}return measurements;}
  9  | async function spreadsheetFocusMetric(cell:Locator){return cell.evaluate(node=>{const input=node as HTMLInputElement,viewport=input.closest<HTMLElement>('.ui-specialist-scroll')!,r=input.getBoundingClientRect(),v=viewport.getBoundingClientRect(),style=getComputedStyle(input),outlineWidth=parseFloat(style.outlineWidth)||0,outlineOffset=parseFloat(style.outlineOffset)||0,extent=outlineWidth+Math.max(0,outlineOffset),ring={left:r.left-extent,right:r.right+extent,top:r.top-extent,bottom:r.bottom+extent},clip={left:Math.max(0,v.left+viewport.clientLeft),right:Math.min(innerWidth,v.left+viewport.clientLeft+viewport.clientWidth),top:Math.max(0,v.top+viewport.clientTop),bottom:Math.min(innerHeight,v.top+viewport.clientTop+viewport.clientHeight)},own=input.closest('td,th'),frozen=[...viewport.querySelectorAll<HTMLElement>('thead th,.ui-sheet-freeze-row,.ui-sheet-freeze-column')].filter(c=>c!==own).map(c=>{const b=c.getBoundingClientRect();return {text:c.textContent,box:{left:b.left,right:b.right,top:b.top,bottom:b.bottom},overlapWidth:Math.min(ring.right,b.right,clip.right)-Math.max(ring.left,b.left,clip.left),overlapHeight:Math.min(ring.bottom,b.bottom,clip.bottom)-Math.max(ring.top,b.top,clip.top)};}),hitInset=Math.min(r.width/2,r.height/2,Math.max(2,...[style.borderTopLeftRadius,style.borderTopRightRadius,style.borderBottomLeftRadius,style.borderBottomRightRadius].map(value=>parseFloat(value)||0))),hits=[r.left+hitInset,(r.left+r.right)/2,r.right-hitInset].flatMap(x=>[r.top+hitInset,(r.top+r.bottom)/2,r.bottom-hitInset].map(y=>document.elementFromPoint(x,y)===input)),contained=ring.left>=clip.left-1&&ring.right<=clip.right+1&&ring.top>=clip.top-1&&ring.bottom<=clip.bottom+1,uncovered=frozen.every(c=>c.overlapWidth<=1||c.overlapHeight<=1);return {address:input.dataset['sheetCell'],value:input.value,ring,clip,outlineWidth,outlineOffset,outlineStyle:style.outlineStyle,window:{width:innerWidth,height:innerHeight,scrollX,scrollY},viewport:{left:v.left,right:v.right,top:v.top,bottom:v.bottom,clientLeft:viewport.clientLeft,clientTop:viewport.clientTop,clientWidth:viewport.clientWidth,clientHeight:viewport.clientHeight,scrollTop:viewport.scrollTop,scrollLeft:viewport.scrollLeft},borderRadii:[style.borderTopLeftRadius,style.borderTopRightRadius,style.borderBottomLeftRadius,style.borderBottomRightRadius],hitInset,frozen,hits,contained,uncovered,focusVisible:input.matches(':focus-visible'),pass:contained&&uncovered&&hits.every(Boolean)&&input.matches(':focus-visible')&&outlineWidth>0&&style.outlineStyle!=='none'};});}
  10 | async function expectSpreadsheetFocus(cell:Locator){await expect(cell).toBeFocused();try{await expect.poll(async()=>(await spreadsheetFocusMetric(cell)).pass,{message:'the complete input focus outline fits the scrollport/window and does not overlap frozen cell rectangles'}).toBe(true);}catch(error){const metric=await spreadsheetFocusMetric(cell);await test.info().attach('sheet-full-focus-ring-failure',{body:JSON.stringify(metric),contentType:'application/json'});throw error;}return spreadsheetFocusMetric(cell);}
  11 | async function changeEnvironment(page:Page,host:Locator,m:Mode){await host.evaluate(n=>(n as HTMLElement).style.width='280px');await page.evaluate(m=>{document.documentElement.setAttribute('data-ui-profile',m.profile==='guided'?'dense':'guided');document.documentElement.style.fontSize=m.font==='100%'?'200%':'100%';},m);await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));}
  12 | const rows=Array.from({length:1000},(_,id)=>({id,name:'申請 '+id+' 長い申請内容 '.repeat(4),amount:id}));
  13 | const state={page:1,pageSize:1000,search:'',sort:[],filters:[],columnOrder:[],hiddenColumns:[],columnWidths:{},pinnedColumns:{}};
  14 | for(const m of modes){
  15 |  for(const family of ['masonry-measured-column-count','grid-list-measured-column-count'] as const){test(`${family} ${family.startsWith('masonry')?'R014':'R092'} ${m.name}: width/gap/breakpoints/invalid/reveal`,async({page},info)=>{
  16 |   await ready(page,m);const masonry=family.startsWith('masonry'),{id,host}=await create(page,masonry?'Masonry':'GridList',{items:rows.slice(0,8),keyField:'id',labelField:'name',label:'不均等の申請一覧',...(masonry?{}:{controlId:'grid-list-p2'}),columns:null,minimumItemWidth:90,maxColumns:6});const list=host.locator(masonry?'ul':'.ui-grid-list');
  17 |   for(const gap of ['0px','20px','500px','invalid']){await list.evaluate((n,gap)=>(n as HTMLElement).style.columnGap=gap,gap);for(const width of [179,180,181,299]){await host.evaluate((n,width)=>(n as HTMLElement).style.width=width+'px',width);await expect.poll(async()=>Number(await list.evaluate((n,masonry)=>masonry?getComputedStyle(n).columnCount:getComputedStyle(n).gridTemplateColumns.split(' ').length,masonry))).toBeGreaterThan(0);
  18 |    await page.evaluate(id=>(window as any).__runtime.render(id),id);await page.waitForTimeout(60);const metric=await list.evaluate((n,masonry)=>{const s=getComputedStyle(n),r=n.getBoundingClientRect(),gap=parseFloat(s.columnGap)||0;return {width:r.width,gap,count:masonry?Number(s.columnCount):s.gridTemplateColumns.split(' ').length,children:[...n.children].map(c=>{const b=c.getBoundingClientRect();return {width:b.width,left:b.left,right:b.right,top:b.top,bottom:b.bottom};}),left:r.left,right:r.right};},masonry);expect(metric.count).toBe(Math.min(6,Math.max(1,Math.floor((metric.width+metric.gap)/(90+metric.gap)))));const expected=(metric.width-metric.gap*(metric.count-1))/metric.count;for(const c of metric.children){expect(Math.abs(c.width-expected)).toBeLessThanOrEqual(1);expect(c.left).toBeGreaterThanOrEqual(metric.left-1);expect(c.right).toBeLessThanOrEqual(metric.right+1);}await info.attach('track-measurement',{body:JSON.stringify(metric),contentType:'application/json'});
  19 |   }}
  20 |   await list.evaluate(n=>(n as HTMLElement).style.columnGap='0px');await update(page,id,{breakpoints:[{minWidth:180,columns:2},{minWidth:260,columns:3}]});for(const [width,count]of [[179,1],[180,2],[259,2],[260,3]]){await host.evaluate((n,width)=>(n as HTMLElement).style.width=width+'px',width);await expect.poll(()=>list.evaluate((n,masonry)=>masonry?Number(getComputedStyle(n).columnCount):getComputedStyle(n).gridTemplateColumns.split(' ').length,masonry)).toBe(count);}
  21 |   await update(page,id,{breakpoints:[],columns:2});for(const value of [0,1.5,NaN,Infinity]){await page.evaluate(({id,value})=>(window as any).__runtime.update(id,{columns:value}),{id,value});await expect(host.getByRole('alert')).toBeVisible();await expect(list).toHaveCount(0);await update(page,id,{columns:2});await expect(list).toHaveCount(1);}
  22 |   await host.evaluate(n=>(n as HTMLElement).hidden=true);await update(page,id,{items:rows.slice(0,3)});await host.evaluate(n=>(n as HTMLElement).hidden=false);await expect(list.locator(':scope>li')).toHaveCount(3);await update(page,id,{columns:null,minimumItemWidth:null});await list.evaluate(n=>(n as HTMLElement).style.columnGap='0px');await host.evaluate(n=>(n as HTMLElement).hidden=true);await page.waitForTimeout(80);const hiddenColumns=await page.evaluate(id=>(window as any).__runtime.instance(id).resolvedColumns(),id);expect(Number.isFinite(hiddenColumns)).toBe(true);expect(hiddenColumns).toBeGreaterThanOrEqual(1);await host.evaluate(n=>(n as HTMLElement).hidden=false);await expect(list.locator(':scope>li')).toHaveCount(3);await contained(list.locator(':scope>li'));expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await destroy(page,id,host);
  23 |  });}
  24 |  test(`listbox-virtual-geometry R133-R137 ${m.name}: 1000/groups/text/owned active/search/invalid/reveal`,async({page},info)=>{
  25 |   await ready(page,m);const options=rows.map(r=>({value:String(r.id),label:r.name,group:r.id<500?'前半':'後半'}));const{id,host}=await create(page,'Listbox',{options,controlId:'p2-listbox',label:'1000候補',virtual:true,searchable:true,height:null,itemHeight:null,overscan:3});const viewport=host.getByRole('listbox');await expect(host.getByRole('option').first()).toBeVisible();await viewport.focus();await viewport.press('PageDown');await viewport.press('End');await expect(host.locator('[data-list-value="999"]')).toBeVisible();await expect.poll(()=>viewport.evaluate(n=>{const id=n.getAttribute('aria-activedescendant'),active=id&&n.ownerDocument.getElementById(id);return !!active&&n.contains(active)&&active.getAttribute('data-list-value')==='999'&&n.ownerDocument.querySelectorAll('[id="'+id+'"]').length===1;}),{message:'End publishes one rendered and owned active descendant for option 999'}).toBe(true);
  26 |   const metric=await viewport.evaluate(n=>{const e=n as HTMLElement,options=[...n.querySelectorAll<HTMLElement>('[role=option]')],active=e.getAttribute('aria-activedescendant'),owned=(e.getAttribute('aria-owns')??'').split(' ').filter(Boolean);return {clientWidth:e.clientWidth,clientHeight:e.clientHeight,rows:options.map(o=>{const r=o.getBoundingClientRect(),s=getComputedStyle(o),spans=[...o.children].map(x=>x.getBoundingClientRect().height);return {height:r.height,width:r.width,content:spans.reduce((a,b)=>a+b,0)+parseFloat(s.paddingTop)+parseFloat(s.paddingBottom)+parseFloat(s.borderBottomWidth)};}),active,count:document.querySelectorAll('[id="'+active+'"]').length,activeInside:!!active&&n.contains(document.getElementById(active)),owned:owned.map(id=>({id,exists:!!document.getElementById(id),children:(document.getElementById(id)?.getAttribute('aria-owns')??'').split(' ').filter(Boolean).map(child=>!!document.getElementById(child))}))};});expect(metric.activeInside).toBe(true);expect(metric.count).toBe(1);for(const row of metric.rows){expect(Math.abs(row.width-metric.clientWidth)).toBeLessThanOrEqual(1);expect(row.height).toBeGreaterThanOrEqual(row.content-1);}expect(metric.rows.length).toBeLessThanOrEqual(Math.ceil(metric.clientHeight/metric.rows[0]!.height)+10);for(const own of metric.owned){expect(own.exists).toBe(true);expect(own.children.every(Boolean)).toBe(true);}const cdp=await page.context().newCDPSession(page);const ax=await cdp.send('Accessibility.getFullAXTree');const listboxAX=ax.nodes.find((n:any)=>n.role?.value==='listbox'&&n.name?.value==='1000候補')!;expect(listboxAX).toBeTruthy();const byAX=new Map(ax.nodes.map(n=>[n.nodeId,n]));const ownedByListbox=(n:typeof ax.nodes[number])=>{let current=n;const seen=new Set<string>();while(current.parentId&&!seen.has(current.parentId)){seen.add(current.parentId);if(current.parentId===listboxAX.nodeId)return true;const parent=byAX.get(current.parentId);if(!parent)return false;current=parent;}return false;};const optionsAX=ax.nodes.filter(n=>n.role?.value==='option'&&!n.ignored&&ownedByListbox(n));await info.attach('listbox-AX-scope-publication',{body:JSON.stringify({metric,expectedLabel:options[999]!.label,AXOptions:optionsAX.map(n=>({id:n.nodeId,parent:n.parentId,name:n.name?.value,role:n.role?.value}))}),contentType:'application/json'});expect(optionsAX.length).toBe(metric.rows.length);expect(optionsAX.some(n=>String(n.name?.value??'').replace(/\s+/g,' ').trim()===options[999]!.label.replace(/\s+/g,' ').trim())).toBe(true);await cdp.detach();await info.attach('listbox-geometry',{body:JSON.stringify(metric),contentType:'application/json'});await viewport.press('Space');expect(await page.evaluate(id=>(window as any).__runtime.inspect(id).events.filter((e:any)=>e.name==='valueChange').at(-1)?.value,id)).toBe('999');
  27 |   await host.getByRole('searchbox').fill('申請 999');await expect(host.getByRole('option')).toHaveCount(1);await changeEnvironment(page,host,m);await expect(host.locator('[data-list-value="999"]')).toHaveAttribute('aria-selected','true');const resizedListbox=await viewport.evaluate(n=>({width:n.clientWidth,row:n.querySelector('[role=option]')!.getBoundingClientRect().width}));expect(Math.abs(resizedListbox.width-resizedListbox.row)).toBeLessThanOrEqual(1);await update(page,id,{virtual:false});await expect(host.getByRole('option')).toHaveCount(1);await update(page,id,{virtual:true,height:250,itemHeight:160});await expect(host.getByRole('option')).toHaveCount(1);for(const value of [0,-1,NaN,Infinity]){await page.evaluate(({id,value})=>(window as any).__runtime.update(id,{height:value,itemHeight:value}),{id,value});await expect(host.getByRole('alert')).toBeVisible();await expect(viewport).toHaveCount(0);await update(page,id,{height:null,itemHeight:null});await expect(viewport).toHaveCount(1);}
  28 |   await host.evaluate(n=>(n as HTMLElement).hidden=true);await update(page,id,{options:options.slice(990)});await host.evaluate(n=>(n as HTMLElement).hidden=false);await expect(host.getByRole('option')).toHaveCount(1);await destroy(page,id,host);
  29 |  });
  30 |  test(`virtual-list-measured-layout R189-R191 ${m.name}: 1000/end/spacer/clientWidth/projected draft/reveal/invalid`,async({page},info)=>{
  31 |   await ready(page,m);const{id,host}=await create(page,'RuntimeP2VirtualEditor',{height:null,itemHeight:null,overscan:3});const viewport=host.locator('cdk-virtual-scroll-viewport');await expect(host.locator('.ui-virtual-row').first()).toBeVisible();const editor=host.getByRole('textbox',{name:'編集 0',exact:true});await editor.fill('アプリに保存する編集');await viewport.focus();await viewport.press('PageDown');await viewport.press('End');await expect(host.locator('[aria-posinset="1000"]')).toBeVisible();const metric=await viewport.evaluate(n=>{const e=n as HTMLElement,rows=[...n.querySelectorAll<HTMLElement>('.ui-virtual-row')],r=rows[0]!.getBoundingClientRect(),wrapper=n.querySelector<HTMLElement>('.cdk-virtual-scroll-content-wrapper')!,spacer=n.querySelector<HTMLElement>('.cdk-virtual-scroll-spacer')!;return {width:e.clientWidth,height:e.clientHeight,rowHeight:r.height,count:rows.length,first:Number(rows[0]!.getAttribute('aria-posinset'))-1,last:Number(rows.at(-1)!.getAttribute('aria-posinset'))-1,offset:new DOMMatrixReadOnly(getComputedStyle(wrapper).transform).m42,spacer:spacer.getBoundingClientRect().height,rows:rows.map(row=>({height:row.getBoundingClientRect().height,width:row.getBoundingClientRect().width})),scroll:e.scrollTop};});for(const row of metric.rows){expect(Math.abs(row.height-metric.rowHeight)).toBeLessThanOrEqual(1);expect(Math.abs(row.width-metric.width)).toBeLessThanOrEqual(1);}expect(Math.abs(metric.offset-metric.first*metric.rowHeight)).toBeLessThanOrEqual(1);expect(Math.abs(metric.spacer-1000*metric.rowHeight)).toBeLessThanOrEqual(1);expect(metric.count).toBeLessThanOrEqual(Math.ceil(metric.height/metric.rowHeight)+10);await info.attach('virtual-list-layout',{body:JSON.stringify(metric),contentType:'application/json'});
  32 |   await viewport.press('Home');await expect(editor).toHaveValue('アプリに保存する編集');await update(page,id,{height:300,itemHeight:180,overscan:1});await expect(editor).toHaveValue('アプリに保存する編集');await changeEnvironment(page,host,m);await expect(editor).toHaveValue('アプリに保存する編集');await expect.poll(()=>viewport.evaluate(n=>Math.abs(n.clientWidth-n.querySelector('.ui-virtual-row')!.getBoundingClientRect().width))).toBeLessThanOrEqual(1);await contained(host.locator('.ui-virtual-row input'));await host.evaluate(n=>(n as HTMLElement).hidden=true);await update(page,id,{items:rows.slice(0,999)});await host.evaluate(n=>(n as HTMLElement).hidden=false);await expect(editor).toHaveValue('アプリに保存する編集');for(const value of [0,-1,NaN,Infinity]){await page.evaluate(({id,value})=>(window as any).__runtime.update(id,{height:value,itemHeight:value}),{id,value});await expect(host.getByRole('alert')).toBeVisible();await update(page,id,{height:null,itemHeight:null});await expect(viewport).toHaveCount(1);}for(const overscan of [-1,1.5,NaN,Infinity]){await page.evaluate(({id,overscan})=>(window as any).__runtime.update(id,{overscan}),{id,overscan});await expect(host.getByRole('alert')).toBeVisible();await update(page,id,{overscan:3});await expect(viewport).toHaveCount(1);}await destroy(page,id,host);
  33 |  });
  34 |  test(`virtual-table-measured-layout R183,R185,R187,R188 ${m.name}: header/body minmax/1000/end/saved widths/invalid`,async({page},info)=>{
  35 |   await ready(page,m);const columns=[{id:'name',field:'name',header:'申請',minWidth:100,maxWidth:220},{id:'amount',field:'amount',header:'金額',type:'number',minWidth:80,maxWidth:180}];const{id,host}=await create(page,'VirtualDataTable',{caption:'1000行の申請',tableId:'p2-virtual-table',rows,columns,keyField:'id',state:{...state,columnWidths:{name:150,amount:90}},selectionMode:'single',height:null,itemHeight:null});const viewport=host.locator('cdk-virtual-scroll-viewport');await expect(host.locator('[data-virtual-row-key]').first()).toBeVisible();await viewport.focus();await viewport.press('PageDown');await viewport.press('End');await expect(host.locator('[data-virtual-row-key="number:999"]')).toBeVisible();
  36 |   const measure=async()=>host.evaluate(n=>{const headers=[...n.querySelectorAll<HTMLElement>('[role=columnheader]')],cells=[...n.querySelector<HTMLElement>('[data-virtual-row-key]')!.querySelectorAll<HTMLElement>('[role=cell]')],v=n.querySelector<HTMLElement>('cdk-virtual-scroll-viewport')!,row=n.querySelector<HTMLElement>('[data-virtual-row-key]')!;return {headers:headers.map(h=>({left:h.getBoundingClientRect().left,right:h.getBoundingClientRect().right,width:h.getBoundingClientRect().width})),cells:cells.map(c=>({left:c.getBoundingClientRect().left,right:c.getBoundingClientRect().right,width:c.getBoundingClientRect().width,height:c.getBoundingClientRect().height})),count:n.querySelectorAll('[data-virtual-row-key]').length,height:v.clientHeight,row:row.getBoundingClientRect().height};});const metric=await measure();for(let i=0;i<metric.headers.length;i++){expect(Math.abs(metric.headers[i]!.left-metric.cells[i]!.left)).toBeLessThanOrEqual(1);expect(Math.abs(metric.headers[i]!.right-metric.cells[i]!.right)).toBeLessThanOrEqual(1);}expect(metric.count).toBeLessThanOrEqual(Math.ceil(metric.height/metric.row)+10);await host.locator('[data-virtual-row-key="number:999"] input').check();expect(await page.evaluate(id=>(window as any).__runtime.inspect(id).events.filter((e:any)=>e.name==='selectedKeysChange').at(-1)?.value,id)).toEqual([999]);await info.attach('virtual-table-geometry',{body:JSON.stringify(metric),contentType:'application/json'});
  37 |   await update(page,id,{state:{...state,columnWidths:{name:220,amount:80}},height:300,itemHeight:180});await expect.poll(async()=>Math.round((await measure()).headers[1]!.width)).toBe(220);await update(page,id,{rows:rows.slice(0,999)});await viewport.press('End');await expect(host.locator('[data-virtual-row-key="number:998"]')).toBeVisible();await changeEnvironment(page,host,m);await viewport.focus();await viewport.press('End');await expect(host.locator('[data-virtual-row-key="number:998"]')).toContainText(rows[998]!.name);const changedColumns=await measure();for(let i=0;i<changedColumns.headers.length;i++){expect(Math.abs(changedColumns.headers[i]!.left-changedColumns.cells[i]!.left)).toBeLessThanOrEqual(1);expect(Math.abs(changedColumns.headers[i]!.right-changedColumns.cells[i]!.right)).toBeLessThanOrEqual(1);}for(const value of [0,-1,NaN,Infinity]){await page.evaluate(({id,value})=>(window as any).__runtime.update(id,{height:value,itemHeight:value}),{id,value});await expect(host.getByRole('alert')).toBeVisible();await update(page,id,{height:null,itemHeight:null});await expect(viewport).toHaveCount(1);}await host.evaluate(n=>(n as HTMLElement).hidden=true);await host.evaluate(n=>(n as HTMLElement).hidden=false);await viewport.focus();await viewport.press('End');await expect(host.locator('[data-virtual-row-key="number:998"]')).toBeVisible();await destroy(page,id,host);
  38 |  });
  39 |  test(`fixture-column-resize-width R195 ${m.name}: keyboard/pointer/capture/disabled/busy 80..300`,async({page},info)=>{
  40 |   await ready(page,m);const{id,host}=await create(page,'RuntimeP2ColumnResize',{});const handle=host.getByRole('separator'),column=host.locator('[data-resize-column]');const check=async(expected:number)=>{await expect(handle).toHaveAttribute('aria-valuenow',String(expected));expect(Math.abs((await column.boundingBox())!.width-expected)).toBeLessThanOrEqual(1);};await check(150);await handle.focus();await handle.press('Home');await check(80);await handle.press('End');await check(300);await handle.press(m.dir==='rtl'?'ArrowRight':'ArrowLeft');await check(290);
  41 |   const box=(await handle.boundingBox())!;await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();await page.mouse.move(box.x+box.width/2+(m.dir==='rtl'?20:-20),box.y+box.height/2,{steps:5});await check(270);expect(await handle.evaluate(n=>(n as any).hasPointerCapture(1))).toBe(true);await page.mouse.up();expect(await handle.evaluate(n=>(n as any).hasPointerCapture(1))).toBe(false);
  42 |   for(const patch of [{disabled:true,busy:false},{disabled:false,busy:true}]){await update(page,id,patch);await expect(handle).toHaveAttribute('aria-disabled','true');const before=await page.evaluate(id=>(window as any).__runtime.instance(id).emitted(),id);await handle.dispatchEvent('keydown',{key:'Home'});await handle.click({force:true});await check(270);expect(await page.evaluate(id=>(window as any).__runtime.instance(id).emitted(),id)).toEqual(before);}await update(page,id,{disabled:false,busy:false});const again=(await handle.boundingBox())!;await page.mouse.move(again.x+again.width/2,again.y+again.height/2);await page.mouse.down();expect(await handle.evaluate(n=>(n as HTMLElement).hasPointerCapture(1))).toBe(true);await update(page,id,{disabled:true});expect(await handle.evaluate(n=>(n as HTMLElement).hasPointerCapture(1))).toBe(false);await page.mouse.up();await update(page,id,{disabled:false});await handle.focus();await handle.press('Home');await check(80);await info.attach('resize-values',{body:JSON.stringify(await page.evaluate(id=>(window as any).__runtime.instance(id).emitted(),id)),contentType:'application/json'});await destroy(page,id,host);
  43 |  });
  44 |  test(`print-document-css-copy R175 ${m.name}: 11 scope tokens/direction/long table/nullview/destroy`,async({page},info)=>{
  45 |   const printMode=m.name==='C'?{...m,width:1280,dir:'rtl' as const}:m.name==='D'?{...m,width:320,dir:'ltr' as const}:m;await ready(page,printMode);await page.emulateMedia({media:'print'});const{id,host}=await create(page,'RuntimeP2Print',{});await host.evaluate(n=>{for(const [name,value] of Object.entries({'font-body':'serif','text-body':'1.2rem','leading-body':'1.8','weight-control':'700','space-page':'1rem','space-table-y':'0.4rem','space-table-x':'1.1rem','border-control':'2px','color-border':'rgb(61, 71, 81)','color-text':'rgb(21, 31, 41)','color-surface':'rgb(241, 246, 251)'}))(n as HTMLElement).style.setProperty('--ui-'+name,value);});await page.evaluate(id=>{const host=document.querySelector(`[data-runtime-id="${id}"]`)!;const frame=(window as any).__runtime.instance(id).create(host);frame.hidden=false;frame.style.width=Math.min(innerWidth,800)+'px';frame.style.height='650px';frame.dataset.p2Print='true';},id);
  46 |   const metric=await page.evaluate(id=>{const names=['font-body','text-body','leading-body','weight-control','space-page','space-table-y','space-table-x','border-control','color-border','color-text','color-surface'],host=document.querySelector(`[data-runtime-id="${id}"]`)!,frame=document.querySelector<HTMLIFrameElement>('[data-p2-print]')!,doc=frame.contentDocument!,source=getComputedStyle(host),target=frame.contentWindow!.getComputedStyle(doc.documentElement);return {source:names.map(n=>source.getPropertyValue('--ui-'+n).trim()),target:names.map(n=>target.getPropertyValue('--ui-'+n).trim()),direction:target.direction,cells:[...doc.querySelectorAll<HTMLElement>('th,td')].map(c=>({text:c.textContent,height:c.clientHeight,scroll:c.scrollHeight,width:c.clientWidth,scrollWidth:c.scrollWidth})),title:doc.title};},id);expect(metric.source).toHaveLength(11);expect(metric.source.every(Boolean)).toBe(true);expect(metric.target).toEqual(metric.source);expect(metric.direction).toBe(printMode.dir);for(const cell of metric.cells){expect(cell.scroll).toBeLessThanOrEqual(cell.height+1);expect(cell.scrollWidth).toBeLessThanOrEqual(cell.width+1);}await info.attach('print-scope-token-copy',{body:JSON.stringify(metric),contentType:'application/json'});
  47 |   // A document without a defaultView has no computed source values; empty properties remain absent.
  48 |   await page.evaluate(id=>{const doc=document.implementation.createHTMLDocument('detached source');const scope=doc.createElement('div');doc.body.append(scope);const frame=(window as any).__runtime.instance(id).create(scope);frame.dataset.p2Print='true';},id);expect(await page.evaluate(()=>document.querySelector<HTMLIFrameElement>('[data-p2-print]')!.contentDocument!.documentElement.style.length)).toBe(0);await destroy(page,id,host);await expect(page.locator('[data-p2-print]')).toHaveCount(0);
  49 |  });
  50 |  test(`spreadsheet-frozen-measured-layout R165-R168 ${m.name}: frozen measured offsets/last keyboard/value/focus/reveal`,async({page},info)=>{
  51 |   await ready(page,m);const sheet={rows:Array.from({length:12},(_,r)=>Array.from({length:8},(_,c)=>`保持 ${r},${c}`))};const{id,host}=await create(page,'Spreadsheet',{sheet,label:'固定セルを確認',frozenRows:2,frozenColumns:2});const viewport=host.locator('.ui-specialist-scroll');await expect(host.locator('[data-sheet-cell="0,0"]')).toBeVisible();await expect.poll(()=>host.locator('.ui-sheet-freeze-row').count()).toBeGreaterThan(0);
  52 |   const measure=async()=>host.evaluate(n=>{const table=n.querySelector('table')!,headers=[...table.querySelectorAll<HTMLElement>('thead th')],rows=[...table.querySelectorAll<HTMLElement>('tbody tr')],head=table.querySelector('thead')!.getBoundingClientRect().height,rowHeader=headers[0]!.getBoundingClientRect().width;return {head,rowHeader,columns:headers.slice(1).map(h=>h.getBoundingClientRect().width),rows:rows.map(r=>r.getBoundingClientRect().height),frozen:[...table.querySelectorAll<HTMLElement>('tbody td.ui-sheet-freeze-row,tbody td.ui-sheet-freeze-column')].map(td=>({row:[...td.parentElement!.parentElement!.children].indexOf(td.parentElement!),col:[...td.parentElement!.children].indexOf(td)-1,rowFixed:td.classList.contains('ui-sheet-freeze-row'),columnFixed:td.classList.contains('ui-sheet-freeze-column'),top:parseFloat(getComputedStyle(td).insetBlockStart),start:parseFloat(getComputedStyle(td).insetInlineStart)}))};});const metric=await measure();for(const cell of metric.frozen){if(cell.rowFixed)expect(Math.abs(cell.top-metric.head-metric.rows.slice(0,cell.row).reduce((a,b)=>a+b,0))).toBeLessThanOrEqual(1);if(cell.columnFixed)expect(Math.abs(cell.start-metric.rowHeader-metric.columns.slice(0,cell.col).reduce((a,b)=>a+b,0))).toBeLessThanOrEqual(1);}await info.attach('sheet-sticky-measurements',{body:JSON.stringify(metric),contentType:'application/json'});
  53 |   const first=host.locator('[data-sheet-cell="0,0"]');await first.focus();await first.press('End');for(let row=0;row<11;row++)await page.keyboard.press('ArrowDown');const last=host.locator('[data-sheet-cell="11,7"]');await expect(last).toBeFocused();await expect(last).toHaveValue('保持 11,7');const focusMeasurements=[await expectSpreadsheetFocus(last)];await viewport.evaluate(n=>{n.scrollTop=0;n.scrollLeft=0;});await first.focus();await first.press(m.dir==='rtl'?'ArrowLeft':'ArrowRight');await expect(host.locator('[data-sheet-cell="0,1"]')).toBeFocused();focusMeasurements.push(await expectSpreadsheetFocus(host.locator('[data-sheet-cell="0,1"]')));await page.keyboard.press(m.dir==='rtl'?'ArrowLeft':'ArrowRight');await page.keyboard.press('ArrowDown');await page.keyboard.press('ArrowDown');const boundary=host.locator('[data-sheet-cell="2,2"]');await expect(boundary).toHaveValue('保持 2,2');focusMeasurements.push(await expectSpreadsheetFocus(boundary));await boundary.press('ArrowUp');focusMeasurements.push(await expectSpreadsheetFocus(host.locator('[data-sheet-cell="1,2"]')));await page.keyboard.press('ArrowDown');focusMeasurements.push(await expectSpreadsheetFocus(boundary));await boundary.press(m.dir==='rtl'?'ArrowRight':'ArrowLeft');focusMeasurements.push(await expectSpreadsheetFocus(host.locator('[data-sheet-cell="2,1"]')));await page.keyboard.press(m.dir==='rtl'?'ArrowLeft':'ArrowRight');focusMeasurements.push(await expectSpreadsheetFocus(boundary));await info.attach('sheet-full-focus-ring-frozen-boundaries',{body:JSON.stringify(focusMeasurements),contentType:'application/json'});
  54 |   await host.evaluate(n=>(n as HTMLElement).hidden=true);await update(page,id,{frozenRows:1,frozenColumns:1});await host.evaluate(n=>(n as HTMLElement).hidden=false);await last.focus();await expect(last).toHaveValue('保持 11,7');await update(page,id,{frozenRows:-1});await expect(host.getByRole('alert')).toBeVisible();await update(page,id,{frozenRows:2});await expect(host.getByRole('alert')).toHaveCount(0);await destroy(page,id,host);
  55 |  });
  56 |  test(`native-table-measured-layout R020-R036 ${m.name}: width/minmax/headerbodyfooter/multiple sticky/resize/hide/reveal`,async({page},info)=>{
  57 |   await ready(page,m);const columns=[{id:'name',field:'name',header:'氏名',minWidth:100,maxWidth:220,width:150,pinned:'start'},{id:'amount',field:'amount',header:'金額',type:'number',minWidth:80,maxWidth:180,width:100,pinned:m.name==='D'?'end':'start'},{id:'extra',field:'name',header:'内容',minWidth:100,maxWidth:230,width:140,pinned:'end'}];const{id,host}=await create(page,'DataTableView',{caption:'実測する固定一覧',tableId:'p2-native',rows:rows.slice(0,25),columns,keyField:'id',state,pagination:false,stickyHeader:true,stickyFooter:true,fixedStartKeys:[0,1],fixedEndKeys:[23,24],aggregates:[{column:'amount',kind:'sum',label:'合計'}],columnControls:false,resizableColumns:false});const viewport=host.locator('.ui-data-table__viewport');await viewport.evaluate(n=>(n as HTMLElement).style.maxHeight='360px');
  58 |   for(const autoFit of ['available','content']){await update(page,id,{autoFit});await expect(host.getByRole('alert')).toHaveCount(0);await expect(host.locator('tbody tr').first()).toBeVisible();await page.waitForTimeout(100);const metric=await host.evaluate(n=>{const table=n.querySelector('table')!,headers=[...table.querySelectorAll<HTMLElement>('thead th[data-column-id]')],cells=[...table.querySelectorAll<HTMLElement>('tbody tr[data-row-key]')][0]!.querySelectorAll<HTMLElement>('td'),footer=[...table.querySelectorAll<HTMLElement>('tfoot tr')].at(-1)!.querySelectorAll<HTMLElement>('td'),fixed=[...table.querySelectorAll<HTMLElement>('tbody tr.ui-data-table__fixed-row')],head=table.querySelector('thead')!.getBoundingClientRect().height,foot=table.querySelector('tfoot')!.getBoundingClientRect().height;return {headers:headers.map(h=>({id:h.dataset['columnId'],left:h.getBoundingClientRect().left,right:h.getBoundingClientRect().right,width:h.getBoundingClientRect().width,start:parseFloat(getComputedStyle(h).insetInlineStart),end:parseFloat(getComputedStyle(h).insetInlineEnd)})),cells:[...cells].map(h=>({left:h.getBoundingClientRect().left,right:h.getBoundingClientRect().right})),footer:[...footer].map(h=>({left:h.getBoundingClientRect().left,right:h.getBoundingClientRect().right})),fixed:fixed.map(row=>({key:row.dataset['rowKey'],height:row.getBoundingClientRect().height,top:parseFloat(getComputedStyle(row).insetBlockStart),bottom:parseFloat(getComputedStyle(row).insetBlockEnd)})),head,foot};});
  59 |    expect(metric.headers).toHaveLength(3);for(let i=0;i<3;i++){const h=metric.headers[i]!,c=columns[i]!;expect(h.width).toBeGreaterThanOrEqual(c.minWidth-1);expect(h.width).toBeLessThanOrEqual(c.maxWidth+1);for(const x of [metric.cells[i]!,metric.footer[i]!]){expect(Math.abs(h.left-x.left)).toBeLessThanOrEqual(1);expect(Math.abs(h.right-x.right)).toBeLessThanOrEqual(1);}}for(let i=0;i<columns.length;i++){const column=columns[i]!,prior=column.pinned==='start'?columns.slice(0,i):columns.slice(i+1);const expected=prior.filter(c=>c.pinned===column.pinned).reduce((sum,c)=>sum+metric.headers[columns.indexOf(c)]!.width,0);expect(Math.abs((column.pinned==='start'?metric.headers[i]!.start:metric.headers[i]!.end)-expected)).toBeLessThanOrEqual(1);}const [r0,r1,r23,r24]=metric.fixed;expect(Math.abs(r0!.top-metric.head)).toBeLessThanOrEqual(1);expect(Math.abs(r1!.top-metric.head-r0!.height)).toBeLessThanOrEqual(1);expect(Math.abs(r24!.bottom-metric.foot)).toBeLessThanOrEqual(1);expect(Math.abs(r23!.bottom-metric.foot-r24!.height)).toBeLessThanOrEqual(1);await info.attach('native-table-measurement',{body:JSON.stringify({autoFit,...metric}),contentType:'application/json'});
  60 |   }
  61 |   await viewport.evaluate(n=>{n.scrollTop=200;n.scrollLeft=100;});await page.evaluate(()=>window.scrollBy(0,100));await update(page,id,{state:{...state,columnWidths:{name:200},columnOrder:['extra','name','amount'],hiddenColumns:['amount'],pinnedColumns:{extra:'end',name:'start'}}});await expect(host.locator('thead th[data-column-id="amount"]')).toHaveCount(0);await expect.poll(()=>host.locator('thead th[data-column-id="name"]').evaluate(n=>Math.round(n.getBoundingClientRect().width))).toBe(200);await update(page,id,{fixedStartKeys:[],fixedEndKeys:[],aggregates:[]});await expect(host.locator('.ui-data-table__fixed-row')).toHaveCount(0);await host.evaluate(n=>(n as HTMLElement).hidden=true);await update(page,id,{state});await host.evaluate(n=>(n as HTMLElement).hidden=false);await expect(host.locator('thead th[data-column-id]')).toHaveCount(3);await update(page,id,{columns:[{...columns[0],minWidth:-1}]});await expect(host.getByRole('alert')).toBeVisible();await update(page,id,{columns});await expect(host.getByRole('alert')).toHaveCount(0);await destroy(page,id,host);
  62 |  });
  63 |  test(`native-table-measured-layout R020-R036 ${m.name}: projected editor focus outside sticky stack`,async({page},info)=>{
  64 |   await ready(page,m);const{id,host}=await create(page,'RuntimeP2NativeEditors',{});const viewport=host.locator('.ui-data-table__viewport');const editor=host.getByRole('textbox',{name:'申請 10',exact:true});await editor.focus();await editor.fill('保存前の全文を保持');
  65 |   const metric=await editor.evaluate(n=>{const e=n as HTMLInputElement,r=e.getBoundingClientRect(),vp=e.closest('.ui-data-table__viewport')!.getBoundingClientRect(),style=getComputedStyle(e),outline=parseFloat(style.outlineWidth)+Math.max(0,parseFloat(style.outlineOffset));return {box:{left:r.left,right:r.right,top:r.top,bottom:r.bottom},vp:{left:vp.left,right:vp.right,top:vp.top,bottom:vp.bottom},outline,hits:[r.left+2,(r.left+r.right)/2,r.right-2].map(x=>document.elementFromPoint(x,(r.top+r.bottom)/2)===e),focusVisible:e.matches(':focus-visible')};});expect(metric.hits.every(Boolean)).toBe(true);expect(metric.box.top).toBeGreaterThanOrEqual(metric.vp.top-1);expect(metric.box.bottom+metric.outline).toBeLessThanOrEqual(metric.vp.bottom+1);expect(metric.box.left-metric.outline).toBeGreaterThanOrEqual(Math.max(0,metric.vp.left)-1);expect(metric.box.right+metric.outline).toBeLessThanOrEqual(Math.min(m.width,metric.vp.right)+1);expect(metric.focusVisible).toBe(true);
  66 |   await host.evaluate(n=>(n as HTMLElement).hidden=true);await host.evaluate(n=>(n as HTMLElement).hidden=false);await editor.focus();await expect(editor).toHaveValue('保存前の全文を保持');await expect(editor).toBeFocused();await info.attach('native-editor-focus',{body:JSON.stringify(metric),contentType:'application/json'});await destroy(page,id,host);
  67 |  });
  68 | 
  69 |  test(`fixture-column-resize-width R195 ${m.name}: original catalog width sink keyboard/pointer/busy/capture`,async({page},info)=>{
  70 |   await page.setViewportSize({width:m.width,height:900});await page.emulateMedia({reducedMotion:m.reduce?'reduce':'no-preference'});await page.goto('/catalog/tables');await page.getByRole('combobox',{name:'表示設定',exact:true}).selectOption(m.profile);if(m.dir==='rtl')await page.getByRole('checkbox',{name:'RTL',exact:true}).check();await page.evaluate(font=>document.documentElement.style.fontSize=font,m.font);
  71 |   const column=page.locator('.resize-demo'),handle=column.getByRole('separator',{name:'申請名の列幅',exact:true}),busy=page.getByRole('checkbox',{name:'処理中',exact:true});const samples:unknown[]=[];
> 72 |   const check=async(expected:number)=>{await expect(handle).toHaveAttribute('aria-valuenow',String(expected));const metric=await column.evaluate(n=>({width:n.getBoundingClientRect().width,inlineWidth:(n as HTMLElement).style.width,text:n.textContent}));expect(Math.abs(metric.width-expected)).toBeLessThanOrEqual(1);expect(metric.inlineWidth).toBe(expected+'px');expect(metric.text).toContain(expected+'px');expect(expected).toBeGreaterThanOrEqual(80);expect(expected).toBeLessThanOrEqual(300);samples.push({expected,...metric});};
     |                                                                                                                                                                                                                                                                                                                                                                                                ^ Error: expect(received).toContain(expected) // indexOf
  73 |   await check(150);await handle.focus();await handle.press('Home');await check(80);await handle.press('End');await check(300);await handle.press(m.dir==='rtl'?'ArrowRight':'ArrowLeft');await check(290);await handle.scrollIntoViewIfNeeded();const rect=(await handle.boundingBox())!;await page.mouse.move(rect.x+rect.width/2,rect.y+rect.height/2);await page.mouse.down();expect(await handle.evaluate(n=>(n as HTMLElement).hasPointerCapture(1))).toBe(true);await page.mouse.move(rect.x+rect.width/2+(m.dir==='rtl'?20:-20),rect.y+rect.height/2,{steps:5});await check(270);await page.mouse.up();expect(await handle.evaluate(n=>(n as HTMLElement).hasPointerCapture(1))).toBe(false);
  74 |   await busy.check();await expect(handle).toHaveAttribute('aria-disabled','true');await handle.dispatchEvent('keydown',{key:'Home'});await check(270);await busy.uncheck();await expect(handle).toHaveAttribute('aria-disabled','false');await handle.scrollIntoViewIfNeeded();const second=(await handle.boundingBox())!;await page.mouse.move(second.x+second.width/2,second.y+second.height/2);await page.mouse.down();expect(await handle.evaluate(n=>(n as HTMLElement).hasPointerCapture(1))).toBe(true);await busy.focus();await busy.press('Space');await expect(busy).toBeChecked();await expect.poll(()=>handle.evaluate(n=>(n as HTMLElement).hasPointerCapture(1))).toBe(false);await page.mouse.up();await check(270);await busy.uncheck();await expect(handle).toHaveAttribute('aria-disabled','false');await handle.focus();await handle.press('Home');await check(80);await info.attach('R195-original-width-binding',{body:JSON.stringify({mode:m,samples}),contentType:'application/json'});
  75 |  });
  76 | 
  77 | }
  78 | 
```