# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: virtual-fast-tab.spec.ts >> fast native Tab table: A-D mixed controls visit every row forward and backward
- Location: tests/ui/virtual-fast-tab.spec.ts:109:45

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: keyboard.press: Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- main [ref=e3]:
  - heading "静的警告の実行時検証" [level=1] [ref=e4]
  - generic [ref=e5]:
    - text: 表示設定
    - combobox "表示設定" [ref=e6]:
      - option "guided" [selected]
      - option "dense"
  - button "基準となる操作" [ref=e7]
  - region "検証する部品" [ref=e8]:
    - generic [ref=e9]:
      - button "一覧の前" [ref=e10]
      - table "連続キーの編集表" [ref=e12]:
        - paragraph [ref=e13]: 連続キーの編集表 (64件の取得済み行)
        - generic [ref=e14]:
          - rowgroup [ref=e15]:
            - row [ref=e16]:
              - columnheader "申請" [ref=e17]
              - columnheader "金額" [ref=e18]
          - rowgroup "連続キーの編集表の仮想スクロール領域" [ref=e19]:
            - generic [ref=e21]:
              - row [ref=e23]:
                - cell [ref=e24]:
                  - generic [ref=e25]:
                    - textbox "入力 27" [ref=e26]: 申請 27 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前
                    - button "無効操作" [disabled] [ref=e27]
                    - textbox "Tab対象外"
                    - combobox "選択 27" [ref=e28]:
                      - option "候補1" [selected]
                      - option "候補2"
                - cell "27" [ref=e29]
              - row [ref=e32]:
                - cell [ref=e33]:
                  - generic [ref=e34]:
                    - textbox "入力 28" [ref=e35]: 申請 28 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前
                    - button "無効操作" [disabled] [ref=e36]
                    - textbox "Tab対象外"
                    - combobox "選択 28" [ref=e37]:
                      - option "候補1" [selected]
                      - option "候補2"
                - cell "28" [active] [ref=e38]
              - row [ref=e41]:
                - cell [ref=e42]:
                  - generic [ref=e43]:
                    - textbox "入力 29" [ref=e44]: 申請 29 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前
                    - button "無効操作" [disabled] [ref=e45]
                    - textbox "Tab対象外"
                    - combobox "選択 29" [ref=e46]:
                      - option "候補1" [selected]
                      - option "候補2"
                - cell "29" [ref=e47]
              - row [ref=e50]:
                - cell [ref=e51]:
                  - generic [ref=e52]:
                    - textbox "入力 30" [ref=e53]: 申請 30 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前 長い内容と保持する名前
                    - button "無効操作" [disabled] [ref=e54]
                    - textbox "Tab対象外"
                    - combobox "選択 30" [ref=e55]:
                      - option "候補1" [selected]
                      - option "候補2"
                - cell "30" [ref=e56]
      - button "一覧の後" [ref=e59]
```

# Test source

```ts
  1   | import {runWithLifecycleCleanup} from './runtime-lifecycle';
  2   | import {type Page} from '@playwright/test';
  3   | import {test,expect,contexts,ready,environment,settle,create,host,destroy,record,update} from './css-override-test';
  4   | 
  5   | const rows=(count:number)=>Array.from({length:count},(_,id)=>({id,name:`申請 ${id} `+'長い内容と保持する名前 '.repeat(8),amount:id}));
  6   | type Kind='list'|'table';
  7   | interface Snapshot{time:number;active:string;range:{start:number;end:number};dom:number[];limit:number;key:{time:number;key:string;trusted:boolean;shift:boolean;active:string;cancelled:boolean}|null;}
  8   | /** Only identity, public range, and DOM indices: no geometry, polling, or frame wait per key. */
  9   | async function installProbe(page:Page,id:number,kind:Kind){const native={ltr:await nativeScrollReference(page,id,kind,1,'ltr'),rtl:await nativeScrollReference(page,id,kind,1,'rtl')};for(const reference of Object.values(native))expect(reference.wheel).toEqual([{trusted:true,cancelled:false}]);await record(kind+'-native-scrollbar-reference',native);await page.evaluate(({id,kind,gutter})=>{
  10  |  const root=document.querySelector<HTMLElement>(`[data-runtime-id="${id}"]`)!,instance=(window as any).__runtime.instance(id),component=kind==='list'?instance.list():instance.table(),viewport=component.viewport(),element=viewport.elementRef.nativeElement as HTMLElement;
  11  |  const identify=(node:Element|null):string=>{
  12  |   if(!node)return 'null';if(node===document.body)return 'BODY';if(node===element)return 'viewport';if(node.matches('cdk-virtual-scroll-viewport'))return 'nested-viewport';if(node.hasAttribute('data-fast-nested'))return 'nested:'+node.getAttribute('data-fast-nested')+':main';
  13  |   if(node.matches('.ui-virtual-row')&&node.closest('cdk-virtual-scroll-viewport')!==element)return `nested-row:${Number(node.getAttribute('aria-posinset'))-1}:DIV`;
  14  |   const boundary=node.getAttribute('data-fast-boundary');if(boundary)return boundary;
  15  |   const row=node.closest<HTMLElement>('.ui-virtual-row,[data-virtual-row-key]');
  16  |   if(root.contains(node)&&row){const index=kind==='list'?Number(row.getAttribute('aria-posinset'))-1:Number(row.getAttribute('aria-rowindex'))-2,control=node.getAttribute('data-fast-control')??(node.getAttribute('role')==='cell'?'cell'+node.getAttribute('aria-colindex'):node.tagName==='INPUT'?'main':node.tagName);return `row:${index}:${control}`;}
  17  |   return node.id||'external:'+node.tagName;
  18  |  };
  19  |  // This explicit post-burst oracle performs layout and hit testing. The keyup
  20  |  // recorder below never invokes it, so it cannot pace the keyboard traversal.
  21  |  const paint=(mode:'active'|'first-visible')=>{
  22  |   const scrollbar=gutter[getComputedStyle(element).direction as 'ltr'|'rtl'],vp=element.getBoundingClientRect(),viewportBox={left:vp.left+element.clientLeft,top:vp.top+element.clientTop,right:vp.left+element.clientLeft+element.clientWidth-scrollbar.right,bottom:vp.top+element.clientTop+element.clientHeight};viewportBox.left+=scrollbar.left;
  23  |   const target=mode==='active'?document.activeElement:[...element.querySelectorAll<HTMLElement>(kind==='list'?'.ui-virtual-row':'[data-virtual-row-key]')].filter(row=>row.closest('cdk-virtual-scroll-viewport')===element).find(row=>{const box=row.getBoundingClientRect();return box.bottom>viewportBox.top&&box.top<viewportBox.bottom;})??null;
  24  |   if(!(target instanceof HTMLElement))return null;
  25  |   const radius=(style:CSSStyleDeclaration)=>Math.max(...[style.borderTopLeftRadius,style.borderTopRightRadius,style.borderBottomLeftRadius,style.borderBottomRightRadius].flatMap(value=>value.split(' ').map(part=>parseFloat(part)||0)));let maxRadius=radius(getComputedStyle(target));
  26  |   const box=target.getBoundingClientRect(),intersection={left:Math.max(box.left,viewportBox.left,0),top:Math.max(box.top,viewportBox.top,0),right:Math.min(box.right,viewportBox.right,innerWidth),bottom:Math.min(box.bottom,viewportBox.bottom,innerHeight)},clips:{tag:string;className:string;contain:string;left:number;top:number;right:number;bottom:number}[]=[];
  27  |   for(let parent=target.parentElement;parent;parent=parent.parentElement){
  28  |    const style=getComputedStyle(parent),paintContain=/(?:^| )(?:paint|content|strict)(?: |$)/.test(style.contain),clipX=paintContain||/auto|scroll|hidden|clip/.test(style.overflowX),clipY=paintContain||/auto|scroll|hidden|clip/.test(style.overflowY);
  29  |    if(!clipX&&!clipY)continue;maxRadius=Math.max(maxRadius,radius(style));const bounds=parent.getBoundingClientRect(),clip={tag:parent.tagName,className:parent.className,contain:style.contain,left:bounds.left+parent.clientLeft,top:bounds.top+parent.clientTop,right:bounds.left+parent.clientLeft+parent.clientWidth,bottom:bounds.top+parent.clientTop+parent.clientHeight};clips.push(clip);
  30  |    if(clipX){intersection.left=Math.max(intersection.left,clip.left);intersection.right=Math.min(intersection.right,clip.right);}if(clipY){intersection.top=Math.max(intersection.top,clip.top);intersection.bottom=Math.min(intersection.bottom,clip.bottom);}
  31  |   }
  32  |   const nonempty=intersection.right>intersection.left&&intersection.bottom>intersection.top,insetX=Math.min(Math.max(4,maxRadius),(intersection.right-intersection.left)/3),insetY=Math.min(4,(intersection.bottom-intersection.top)/4),hits=nonempty?[intersection.left+insetX,(intersection.left+intersection.right)/2,intersection.right-insetX].flatMap(x=>[intersection.top+insetY,(intersection.top+intersection.bottom)/2,intersection.bottom-insetY].map(y=>{const hit=document.elementFromPoint(x,y);return {x,y,tag:hit?.tagName??null,role:hit?.getAttribute('role')??null,label:hit?.getAttribute('aria-label')??null,owned:hit===target||!!hit&&target.contains(hit)};})):[];
  33  |   return {mode,target:identify(target),rect:{left:box.left,top:box.top,right:box.right,bottom:box.bottom},intersection,maxRadius,clips,hits,painted:nonempty&&hits.length===9&&hits.every(hit=>hit.owned)};
  34  |  };
  35  |  let key:Snapshot['key']=null,keyEvent:KeyboardEvent|null=null;const events:Snapshot[]=[];
  36  |  const read=():Snapshot=>({time:performance.now(),active:identify(document.activeElement),range:viewport.getRenderedRange(),dom:[...element.querySelectorAll<HTMLElement>(kind==='list'?'.ui-virtual-row':'[data-virtual-row-key]')].filter(row=>row.closest('cdk-virtual-scroll-viewport')===element).map(row=>kind==='list'?Number(row.getAttribute('aria-posinset'))-1:Number(row.getAttribute('aria-rowindex'))-2),limit:Math.ceil(viewport.getViewportSize()/component.rowSize())+2*(component.overscan()+1)+2,key:key?{...key,cancelled:keyEvent?.defaultPrevented??false}:null});
  37  |  const keydown=(event:KeyboardEvent)=>{if(event.key==='Tab'){keyEvent=event;key={time:performance.now(),key:event.key,trusted:event.isTrusted,shift:event.shiftKey,active:identify(document.activeElement),cancelled:event.defaultPrevented};}};
  38  |  const keyup=(event:KeyboardEvent)=>{if(event.key==='Tab')events.push(read());};
  39  |  document.addEventListener('keydown',keydown,true);document.addEventListener('keyup',keyup,true);
  40  |  (window as any).__fastTab={snapshot:read,paint,drain:()=>events.splice(0),dispose:()=>{document.removeEventListener('keydown',keydown,true);document.removeEventListener('keyup',keyup,true);}};
  41  |  },{id,kind,gutter:{ltr:native.ltr.gutter,rtl:native.rtl.gutter}});}
  42  | async function snapshot(page:Page):Promise<Snapshot>{return page.evaluate(()=>(window as any).__fastTab.snapshot());}
  43  | interface ExpectedKey{active:string;backwards:boolean;cancelled:boolean;}
  44  | const pending=new WeakMap<Page,ExpectedKey[]>();
  45  | /** A burst pays only the trusted keyboard IPC: all reads and assertions follow the burst. */
  46  | async function tab(page:Page,expected:string,_log:Snapshot[],backwards=false,cancelled=false){
> 47  |  const plan=pending.get(page)??[];plan.push({active:expected,backwards,cancelled});pending.set(page,plan);await page.keyboard.press(backwards?'Shift+Tab':'Tab');
      |                                                                                                                               ^ Error: keyboard.press: Test timeout of 30000ms exceeded.
  48  | }
  49  | async function flush(page:Page,log:Snapshot[]){
  50  |  const events:Snapshot[]=await page.evaluate(()=>(window as any).__fastTab.drain()),plan=pending.get(page)??[];pending.set(page,[]);log.push(...events);
  51  |  expect(events.length,'each trusted Tab has one captured keyup').toBe(plan.length);
  52  |  for(const [index,expected] of plan.entries()){
  53  |   const current=events[index]!;
  54  |   // CDK maxBuffer is overscan+1 rows per side; two additional rows cover the
  55  |   // active row's adjacent handoff. This bound applies at every keyup, before RAF.
  56  |   expect(current.dom.length,'live DOM stays bounded during the burst').toBeLessThanOrEqual(current.limit);expect(current.range.end-current.range.start,'public range stays bounded during the burst').toBeLessThanOrEqual(current.limit);
  57  |   expect(current.key?.trusted,'the traversal uses a trusted native key').toBe(true);expect(current.key?.cancelled,'Tab default follows the application handler').toBe(expected.cancelled);expect(current.key?.shift).toBe(expected.backwards);
  58  |   expect(current.active,`native ${expected.backwards?'Shift+Tab':'Tab'} from ${current.key?.active}; range ${current.range.start}..${current.range.end}; DOM ${current.dom.join(',')}`).toBe(expected.active);
  59  |  }
  60  | }
  61  | async function disposeProbe(page:Page){if(page.isClosed()){await record('unexpected-page-close',{unexpectedPageClosed:true});return;}await page.evaluate(()=>(window as any).__fastTab.dispose());}
  62  | 
  63  | interface NativeScrollReference{top:number;max:number;steps:number[];gutter:{left:number;right:number};wheel:{trusted:boolean;cancelled:boolean}[];}
  64  | async function nativeScrollReference(sourcePage:Page,id:number,kind:Kind,gestures:number,direction?:'ltr'|'rtl'):Promise<NativeScrollReference>{
  65  |  // A separate native page avoids carrying a browser wheel gesture's scroll
  66  |  // latch from a temporary overlay into the application under test.
  67  |  const geometry=await sourcePage.evaluate(({id,kind,direction})=>{const instance=(window as any).__runtime.instance(id),component=kind==='list'?instance.list():instance.table(),source=component.viewport().elementRef.nativeElement as HTMLElement,style=getComputedStyle(source);return {width:source.clientWidth,height:source.clientHeight,scrollHeight:source.scrollHeight,direction:direction??style.direction,font:style.font,lineHeight:style.lineHeight};},{id,kind,direction});
  68  |  const page=await sourcePage.context().newPage();const size=sourcePage.viewportSize();if(size)await page.setViewportSize(size);
  69  |  const steps:number[]=[];
  70  |  try{
  71  |   await page.setContent('<!doctype html><html><body></body></html>');
  72  |   await page.evaluate(geometry=>{const reference=document.createElement('div'),content=document.createElement('div');reference.id='fast-native-scroll-reference';reference.style.cssText=`position:fixed;inset:0 auto auto 0;z-index:2147483647;inline-size:${geometry.width}px;block-size:${geometry.height}px;overflow:auto;border:0;padding:0;box-sizing:content-box;direction:${geometry.direction};font:${geometry.font};line-height:${geometry.lineHeight}`;content.style.cssText=`block-size:${geometry.scrollHeight}px;inline-size:100%;background:white`;reference.append(content);document.body.append(reference);const events:WheelEvent[]=[];reference.addEventListener('wheel',event=>events.push(event));(window as any).__fastNativeScroll={reference,content,events};},geometry);
  73  |   const target=await page.locator('#fast-native-scroll-reference').boundingBox();expect(target,'native scroll oracle is rendered').toBeTruthy();
  74  |   await page.mouse.move(target!.x+target!.width/2,target!.y+target!.height/2);
  75  |   for(let index=0;index<gestures;index++){const before=steps.at(-1)??0;await page.mouse.wheel(0,1_000_000);await expect.poll(()=>page.evaluate(before=>{const {reference}= (window as any).__fastNativeScroll;return reference.scrollTop>before||reference.scrollTop===reference.scrollHeight-reference.clientHeight;},before)).toBe(true);await settle(page);steps.push(await page.evaluate(()=>(window as any).__fastNativeScroll.reference.scrollTop));}
  76  |   return await page.evaluate(steps=>{const {reference,content,events}= (window as any).__fastNativeScroll,bounds=reference.getBoundingClientRect(),y=bounds.top+reference.clientHeight/2,owns=(x:number)=>{const hit=document.elementFromPoint(x,y);return hit===content||!!hit&&content.contains(hit);};let left=0,right=0;while(left<reference.clientWidth/2&&!owns(bounds.left+left+.5))left++;while(right<reference.clientWidth/2&&!owns(bounds.left+reference.clientWidth-right-.5))right++;return {top:reference.scrollTop,max:reference.scrollHeight-reference.clientHeight,steps,gutter:{left,right},wheel:events.map((event:WheelEvent)=>({trusted:event.isTrusted,cancelled:event.defaultPrevented}))};},steps);
  77  |  }finally{await page.close();await sourcePage.bringToFront();}
  78  | }
  79  | // Listener-free DOM provides this engine's native stops, including implicit
  80  | // scrollable row stops. Actual nested traversal below remains an unpaced burst.
  81  | async function nativeNestedSequence(page:Page,id:number,kind:Kind):Promise<string[]>{
  82  |  await page.evaluate(({id,kind})=>{const root=document.querySelector(`[data-runtime-id="${id}"]`)!,outer=(kind==='list'?root.querySelector('ui-virtual-list'):root.querySelector('ui-virtual-data-table'))!,nested=outer.querySelector('ui-virtual-list')!,reference=document.createElement('section'),before=document.createElement('button'),after=document.createElement('button');reference.id='fast-native-nested';before.id='fast-native-nested-before';after.id='fast-native-nested-after';reference.append(before,nested.cloneNode(true),after);document.querySelector('#runtime-slot')!.append(reference);},{id,kind});
  83  |  const result:string[]=[];try{await page.locator('#fast-native-nested-before').focus();for(let index=0;index<8;index++){await page.keyboard.press('Tab');const stop=await page.evaluate(()=>{const node=document.activeElement!;if(node.id==='fast-native-nested-after')return 'after';if(node.matches('cdk-virtual-scroll-viewport'))return 'nested-viewport';if(node.hasAttribute('data-fast-nested'))return 'nested:'+node.getAttribute('data-fast-nested')+':main';if(node.matches('.ui-virtual-row'))return 'nested-row:'+(Number(node.getAttribute('aria-posinset'))-1)+':DIV';return 'unexpected:'+node.tagName;});if(stop==='after')return result;result.push(stop);}throw new Error('native nested oracle did not exit within all three inputs and optional row stops');}finally{await page.locator('#fast-native-nested').evaluate(node=>node.remove());await page.evaluate(()=>(window as any).__fastTab.drain());}
  84  | }
  85  | 
  86  | // The original 1000-row/default-height/overscan-2 projection and D → C environment change.
  87  | // Settling is confined to setup, explicit End navigation, and profile transitions.
  88  | test('fast native Tab original D to C: terminal projected inputs never exit before row 999',async({page,lifecycle})=>{
  89  |  await ready(page,contexts[3]);const id=await create(page,'RuntimeReassessmentVirtual',{kind:'list',rows:rows(1000),height:360,itemHeight:null,overscan:2,editors:true}),node=host(page,id),log:Snapshot[]=[];
  90  |  await node.evaluate(root=>{const after=document.createElement('button');after.id='fast-original-after';after.textContent='一覧の後';root.after(after);});await settle(page);await installProbe(page,id,'list');
  91  |  await runWithLifecycleCleanup(lifecycle,async()=>{
  92  |   for(const context of [contexts[3],contexts[2]]){
  93  |    await environment(page,context);await page.locator('#runtime-anchor').focus();await tab(page,'viewport',log);await page.keyboard.press('End');await settle(page);await flush(page,log);
  94  |    const terminal=await snapshot(page);expect(terminal.dom.at(-1),'setup must actually render the final row').toBe(999);expect(terminal.range.end).toBe(1000);const terminalPaint=await page.evaluate(()=>(window as any).__fastTab.paint('first-visible'));await record('original-'+context.name+'-End-first-visible-paint',terminalPaint);expect(terminalPaint?.painted,'first visible terminal row is painted and owns its native hit points').toBe(true);
  95  |    const start=terminal.dom[0]!;await page.locator('#runtime-anchor').focus();await tab(page,'viewport',log);
  96  |    for(let index=start;index<1000;index++)await tab(page,`row:${index}:main`,log);
  97  |    await flush(page,log);await geometry(page,id,'list','original-'+context.name+'-forward-burst');await tab(page,'fast-original-after',log);await flush(page,log);
  98  |   }
  99  |  },async()=>{await record('original-D-C-immediate-native-tab',log);await disposeProbe(page);});
  100 |  await destroy(page,id);
  101 | });
  102 | 
  103 | async function geometry(page:Page,id:number,kind:Kind,label:string){
  104 |  const metric=await page.evaluate(({id,kind})=>{const instance=(window as any).__runtime.instance(id),component=kind==='list'?instance.list():instance.table(),viewport=component.viewport(),element=viewport.elementRef.nativeElement as HTMLElement,wrapper=element.querySelector<HTMLElement>('.ui-virtual-window')!,cdkWrapper=element.querySelector<HTMLElement>('.cdk-virtual-scroll-content-wrapper')!,range=viewport.getRenderedRange(),active=document.activeElement as HTMLElement,box=active.getBoundingClientRect(),bounds=element.getBoundingClientRect(),height=component.rowSize(),nodes=[...element.querySelectorAll<HTMLElement>(kind==='list'?'.ui-virtual-row':'[data-virtual-row-key]')];return {range,height,offset:parseFloat(getComputedStyle(wrapper).paddingBlockStart)||0,cdkOffset:new DOMMatrixReadOnly(getComputedStyle(cdkWrapper).transform).m42,rows:nodes.map(row=>({index:kind==='list'?Number(row.getAttribute('aria-posinset'))-1:Number(row.getAttribute('aria-rowindex'))-2,height:row.getBoundingClientRect().height})),active:{top:box.top,bottom:box.bottom},viewport:{top:bounds.top+element.clientTop,bottom:bounds.top+element.clientTop+element.clientHeight},activePaint:(window as any).__fastTab.paint('active'),firstVisiblePaint:(window as any).__fastTab.paint('first-visible')};},{id,kind});
  105 |  expect(metric.range.start,label+': public range begins at first DOM row').toBe(metric.rows[0]?.index);expect(metric.range.end-metric.range.start).toBe(metric.rows.length);expect(Math.abs(metric.offset-metric.range.start*metric.height),label+': owned window follows public range').toBeLessThanOrEqual(1);expect(metric.cdkOffset,label+': CDK wrapper does not add a second offset').toBe(0);
  106 |  for(const row of metric.rows)expect(Math.abs(row.height-metric.height),label+': fixed rows match measured size').toBeLessThanOrEqual(1);
  107 |  expect(metric.active.top,label+': burst target is above the viewport bottom').toBeLessThan(metric.viewport.bottom);expect(metric.active.bottom,label+': burst target is below the viewport top').toBeGreaterThan(metric.viewport.top);await record(label,metric);expect(metric.activePaint?.painted,label+': focused target owns all center/inset hit samples').toBe(true);expect(metric.firstVisiblePaint?.painted,label+': first visible row is painted and hit testable').toBe(true);
  108 | }
  109 | for(const kind of ['list','table'] as const)test(`fast native Tab ${kind}: A-D mixed controls visit every row forward and backward`,async({page,lifecycle})=>{
  110 |  await ready(page,contexts[0]);const count=64,id=await create(page,'RuntimeFastTab',{kind,rows:rows(count),mixed:true,itemHeight:null}),node=host(page,id),log:Snapshot[]=[];await settle(page);await installProbe(page,id,kind);
  111 |  await runWithLifecycleCleanup(lifecycle,async()=>{
  112 |   for(const context of contexts){
  113 |    await environment(page,context);await update(page,id,{itemHeight:context.name==='C'?220:null,overscan:context.name==='C'?0:2});await node.locator('[data-fast-boundary="before"]').focus();await tab(page,'viewport',log);
  114 |    const controls=kind==='list'?['main','tail']:['cell1','main','tail','cell2'];
  115 |    for(let index=0;index<count;index++)for(const control of controls)await tab(page,`row:${index}:${control}`,log);
  116 |    await flush(page,log);await geometry(page,id,kind,kind+'-'+context.name+'-forward-burst');if(context.name==='C')await test.info().attach(kind+'-C-post-forward-painted',{body:await page.screenshot({fullPage:true}),contentType:'image/png'});await tab(page,'after',log);
  117 |    for(let index=count-1;index>=0;index--)for(const control of [...controls].reverse())await tab(page,`row:${index}:${control}`,log,true);
  118 |    await flush(page,log);await geometry(page,id,kind,kind+'-'+context.name+'-backward-burst');await tab(page,'viewport',log,true);await tab(page,'before',log,true);await flush(page,log);
  119 |   }
  120 |  },async()=>{await record(kind+'-A-D-immediate-native-tab',log);await disposeProbe(page);});
  121 |  await destroy(page,id);
  122 | });
  123 | 
  124 | test('fast native Tab guards: consumed and IME keys preserve state; editors keep native key behavior',async({page,lifecycle})=>{
  125 |  await ready(page,contexts[2]);const log:Snapshot[]=[];
  126 |  for(const kind of ['list','table'] as const){
  127 |   const id=await create(page,'RuntimeFastTab',{kind,rows:rows(1000),mixed:true,itemHeight:null}),node=host(page,id);await settle(page);await installProbe(page,id,kind);
  128 |   await runWithLifecycleCleanup(lifecycle,async()=>{
  129 |    await node.locator('[data-fast-boundary="before"]').focus();await tab(page,'viewport',log);if(kind==='table')await tab(page,'row:0:cell1',log);await tab(page,'row:0:main',log);await flush(page,log);
  130 |    // Compare the same native editor keys with an identical external reference input.
  131 |    const native=await page.evaluate(()=>{const source=document.activeElement as HTMLInputElement,reference=source.cloneNode() as HTMLInputElement;reference.id='fast-native-reference';reference.removeAttribute('data-fast-control');reference.removeAttribute('aria-label');document.querySelector('#runtime-slot')!.before(reference);source.setSelectionRange(3,3);return {value:source.value,dir:getComputedStyle(source).direction};});
  132 |    const before=await snapshot(page),positions:number[]=[];for(const key of ['ArrowRight','ArrowLeft','ArrowLeft','ArrowRight']){await page.keyboard.press(key);positions.push(await page.evaluate(()=>(document.activeElement as HTMLInputElement).selectionStart??-1));}
  133 |    expect((await snapshot(page)).active).toBe('row:0:main');expect((await snapshot(page)).range).toEqual(before.range);
  134 |    await page.locator('#fast-native-reference').evaluate((node,native)=>{const input=node as HTMLInputElement;input.value=native.value;input.style.direction=native.dir;input.focus();input.setSelectionRange(3,3);},native);
  135 |    const reference:number[]=[];for(const key of ['ArrowRight','ArrowLeft','ArrowLeft','ArrowRight']){await page.keyboard.press(key);reference.push(await page.evaluate(()=>(document.activeElement as HTMLInputElement).selectionStart??-1));}expect(positions,'projected input preserves the browser native caret behavior').toEqual(reference);
  136 |    await node.locator('[data-fast-control="main"]').first().focus();await page.locator('#fast-native-reference').evaluate(node=>node.remove());
  137 |    await node.locator('[data-fast-control="main"]').first().evaluate(node=>node.addEventListener('keydown',event=>event.preventDefault(),{once:true}));await tab(page,'row:0:main',log,false,true);await flush(page,log);
  138 |    await tab(page,'row:0:tail',log);await flush(page,log);
  139 |    await page.evaluate(()=>{const source=document.activeElement as HTMLSelectElement,reference=source.cloneNode(true) as HTMLSelectElement;source.selectedIndex=0;reference.selectedIndex=0;reference.id='fast-native-select';reference.removeAttribute('data-fast-control');reference.removeAttribute('aria-label');document.querySelector('#runtime-slot')!.before(reference);});
  140 |    const selected:string[]=[];for(const key of ['ArrowDown','Enter','Escape']){await page.keyboard.press(key);selected.push(await page.evaluate(()=>(document.activeElement as HTMLSelectElement).value));}expect((await snapshot(page)).active).toBe('row:0:tail');
  141 |    await page.locator('#fast-native-select').focus();const nativeSelected:string[]=[];for(const key of ['ArrowDown','Enter','Escape']){await page.keyboard.press(key);nativeSelected.push(await page.evaluate(()=>(document.activeElement as HTMLSelectElement).value));}expect(selected,'projected select preserves browser native popup/selection behavior').toEqual(nativeSelected);await node.locator('[data-fast-control="tail"]').first().focus();await page.locator('#fast-native-select').evaluate(node=>node.remove());
  142 |    // Synthetic dispatch proves handler delegation only: it does not run native
  143 |    // Home/End scrolling or an OS/browser-reserved modified Tab default action.
  144 |    const guards=await page.evaluate(({id,kind})=>{
  145 |     const root=document.querySelector(`[data-runtime-id="${id}"]`)!,instance=(window as any).__runtime.instance(id),viewport=(kind==='list'?instance.list():instance.table()).viewport(),elements=[...root.querySelectorAll<HTMLElement>(kind==='list'?'[data-fast-control=tail]':'[role=cell][aria-colindex="2"]')],target=elements.at(-1)!;target.focus();
  146 |     const variants:(KeyboardEventInit&{defaultPrevented?:boolean})[]=[{defaultPrevented:true},{isComposing:true},{keyCode:229},{altKey:true},{ctrlKey:true},{metaKey:true},{key:'Home'},{key:'End'}];return variants.map(init=>{const range={...viewport.getRenderedRange()},active=document.activeElement,event=new KeyboardEvent('keydown',{key:'Tab',bubbles:true,cancelable:true,...init});if(init.defaultPrevented)event.preventDefault();target.dispatchEvent(event);return {init,cancelled:event.defaultPrevented,activeUnchanged:active===document.activeElement,rangeUnchanged:JSON.stringify(range)===JSON.stringify(viewport.getRenderedRange())};});
  147 |    },{id,kind});
```