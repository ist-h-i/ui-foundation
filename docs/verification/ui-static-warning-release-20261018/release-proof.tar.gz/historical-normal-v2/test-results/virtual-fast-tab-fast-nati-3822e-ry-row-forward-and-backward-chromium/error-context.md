# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: virtual-fast-tab.spec.ts >> fast native Tab list: A-D mixed controls visit every row forward and backward
- Location: tests/ui/virtual-fast-tab.spec.ts:109:45

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- main [ref=e3]:
  - heading "静的警告の実行時検証" [level=1] [ref=e4]
  - generic [ref=e5]:
    - text: 表示設定
    - combobox "表示設定" [ref=e6]:
      - option "guided" [selected]
      - option "dense"
  - button "基準となる操作" [ref=e7]
  - region "検証する部品"
```