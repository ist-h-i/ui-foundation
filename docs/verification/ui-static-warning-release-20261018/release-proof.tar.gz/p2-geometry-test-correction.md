# P2 geometry test correction

Status: test correction implemented; isolated typecheck passed. Browser verification is **NOT RUN** for this correction. The main agent owns the subsequent browser run and independent review after the existing full normal run finishes.

## Identity and scope

- Repository: `/Users/inouehiroshi/Documents/GitHub/ui-foundation`
- Branch/base/current HEAD: `feat/ui-static-warning-release` / `20761f986c6480546ddf405235b1ddf4faa8b405` (unchanged during this correction).
- Owned source: `tests/ui/static-runtime-p2-tables.spec.ts` only; this note is the separately requested report. No component, fixture, generated output, ledger, Git state, or other test was changed by this worker.
- Base test SHA-256: `675413dbd1bd1dd8e2d97760e99c0b3609b80a0dc427c413f5ad00217f8dbdcd`.
- Corrected test SHA-256: `89a0640355ea824ccc9f5e16b5cf6c7e3c17cad0366031e0c5ad02858f4ecb69`.

## Evidence and source contract

The eight retained failure traces under `/var/folders/57/t9r9mr850f74d7hd68f9zcm80000gn/T/ui-foundation-release-v2-72k3he8j/test-results/static-runtime-p2-tables-*/trace.zip` all embed the base test SHA-256 above. The corresponding `error-context.md` files identify the four A/B/C/D failures in each affected test.

1. **R195 caption target.** `tests/fixture-app/table-catalog.ts:24` binds the actual column width to `.resize-demo`, the separator value to the same signal, and the displayed `可変幅 (150px)` text to sibling `p#resize-caption`. The column contains only the handle. All four original failures are the column-text `150px` assertion receiving an empty string; each retained page snapshot already contains the correct sibling caption. The old numeric actual-width/inline-width and ARIA checks precede that failure. This distinguishes a stale text target from a missing displayed value at the failing initial state.
2. **R189–R191 rendered position.** `templates/angular/virtual-scroll.ts` explicitly documents a fixed-row application-owned window with CDK's wrapper at offset zero. Its `window` method publishes the first rendered index as leading space; `templates/angular/virtual-list.ts` renders that space on `.ui-virtual-window`; `templates/angular/virtual-rows.ts` derives slot gaps from the indices to retain a bounded projected editor without losing its position. The old test reads only the CDK wrapper transform and therefore tests a storage assumption. Its A/B/C/D residuals are respectively 79360 / 126976 / 158720 / 63488. These residuals do not measure the actual row position, so they do not establish a product geometry defect or a geometry pass.

## Actual diff

- R195 reads `#resize-caption` and checks the exact expected caption while keeping the existing expected width sequence, actual bounding width, inline width, ARIA value, min/max, keyboard, pointer capture/release, and busy validations. Each width sample is attached before the numeric/caption assertions; the final sample collection remains attached.
- R189–R191 computes scroll-content position from `rowRect.top - (viewportRect.top + viewport.clientTop) + viewport.scrollTop`. It checks the first-row position and every rendered row's position against that row's published index times the measured uniform row height. The formula accounts for the viewport border and observes the composed rendered result, without reading wrapper transforms or summing implementation padding.
- The full virtual-list measurement, including mode, viewport origin/border, scroll position, row rectangles/indices/offsets, row sizes/count, and spacer height, is attached before geometry assertions.
- Uniform height, client width, 1000-item spacer, bounded live count, end visibility, projected draft preservation, resize/profile/font changes, hide/reveal, invalid input, lifecycle checks, and the `<= 1px` geometry tolerance remain. No skip, retry, or fixed sleep was added.

## Checks and limits

- `./node_modules/.bin/tsc --ignoreConfig --noEmit --target ES2022 --module ESNext --moduleResolution bundler --lib ES2022,DOM --types node --strict --skipLibCheck --noUncheckedIndexedAccess tests/ui/static-runtime-p2-tables.spec.ts` — exit **0**; isolated typecheck only.
- `git diff --check -- tests/ui/static-runtime-p2-tables.spec.ts` — exit **0**.
- Read-only Python inspection of all eight retained failure contexts/trace source hashes — exit **0**; confirms the failing test identity and caption snapshots.
- Browser, build, sync, full-suite rerun, and independent review — **NOT RUN by this worker**, to avoid overlapping the active full normal run on the 16GB host. Corrected runtime behavior remains unverified until the main agent's run.
