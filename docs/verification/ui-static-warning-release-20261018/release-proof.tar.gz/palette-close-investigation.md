# Palette recovery close investigation — 2026-10-18

## Scope and result

- Repository: `/Users/inouehiroshi/Documents/GitHub/ui-foundation`.
- Assigned base/head: `feat/ui-static-warning-release` at `20761f986c6480546ddf405235b1ddf4faa8b405`.
- Observed failures: reassessment `palette-recovery-geometry A` and `C`, Chromium, at the final `toBeHidden()` assertion.
- Classification: **test sequencing race against an intentional busy-close guard**. Both saved traces show the Escape action while the dialog still has `aria-busy="true"`; the recovered failure state appears afterward. A completed fixture response click does not establish that its bound child dialog input has rendered.
- Correction: wait for the observable recovered state (`aria-busy="false"` and the full error marker), then reassert the retained query and active command before the same native Escape and hidden assertion.
- No production/template/generated file was edited. The correction does not add sleeps, animation frames, retries, skips, expected failures, or a substitute close mechanism.
- Browser rerun, build, sync, typecheck, and `npm test`: **NOT_RUN by this worker**. The parent-owned normal test run was active, so this worker used source/trace reads and a small TypeScript AST probe only. Runtime success of the corrected test remains unverified here.

## Source contract

1. `tests/fixture-app/navigation-catalog.ts:49-50`: `failCommand()` sets the application busy signal to false and publishes the error; `runCommand()` clears the error and sets busy true. The palette receives these through `[busy]="commandBusy()"` and `[error]="commandError()"` on line 14.
2. `templates/angular/command-palette.ts:12`: the palette passes its `busy()` input into the native `uiDialog`. Lines 203-205 preserve the pending/busy duplicate-invocation guard and move retry focus to the search.
3. `templates/angular/overlay.ts:56-64`: an unconsumed Escape is routed to the top overlay's `dismiss('escape')`; child/IME handled events retain priority.
4. `templates/angular/dialog.ts:208-216`: UI close is deliberately vetoed when `busy()` is true. Lines 221-227 retain Escape cancellation semantics. The test must first establish the failure response has reached this bound busy state if it expects the close to succeed.
5. Original `tests/ui/static-runtime-reassessment-navigation.spec.ts:49`: the first failure click awaits the error marker, but the second failure click immediately presses Escape. The original final `toBeHidden()` observes busy false only after the key has already been consumed by the guard.

The live source files and generated Angular files inspected here match their counterparts in the private committed test archive byte for byte, except for the deliberately corrected test file.

## Saved trace evidence

Archive root: `/var/folders/57/t9r9mr850f74d7hd68f9zcm80000gn/T/ui-foundation-release-v2-72k3he8j`.

All times below are the trace monotonic milliseconds. Action snapshots were read directly from `1-trace.trace` inside each zip, without opening or rerunning a browser.

| Case | Failure response | Escape action snapshot | First subsequent recovered snapshot | Result |
| --- | --- | --- | --- | --- |
| A | `call@9007`, click ends `2260604.007` | `call@9009`, `2260611.059`: modal dialog, busy **true**, query `保存`, active descendant `catalog-palette-command-save` | `call@9011` before, `2260621.267`: busy false | Final hidden assertion times out with dialog visible and busy false. |
| C | `call@12868`, click ends `2282268.308` | `call@12870`, `2282275.038`: modal dialog, busy **true**, query `保存`, same active descendant | `call@12870` after, `2282283.61`: busy false, recovered error ending `エラーの末尾。再試行できます。`, response buttons disabled | Final hidden assertion times out with dialog visible and busy false. |

Trace directories under `test-results/`:

- A: `static-runtime-reassessmen-fb1f5-or-held-through-environment-chromium`.
- C: `static-runtime-reassessmen-2d203-or-held-through-environment-chromium`.

| Artifact | SHA-256 |
| --- | --- |
| A `trace.zip` | `66520e9639099af9fe989da853923dc2db2117e9d414c7cc5ea7f1751f15370d` |
| A `error-context.md` | `6a817b50d32a10cb96d23b793ab1d36c9b54d12cb9bd98574c38b26bc4ddf18c` |
| C `trace.zip` | `c11573f41ef844f72d86773b413d6c539cdf974d2ab4588da553642247416df9` |
| C `error-context.md` | `a0305ed7b8c771514afc016bcbf3d5b1eeedbe21d8ecca06a20da8bccf7a44a0` |

Alternative explanations were checked against these observations. The saved query and active descendant contradict an Escape search-clear explanation. Geometry and focus assertions have already completed at this point. A stuck dialog after a settled idle failure is not established by these traces, because the sent close request occurs while the guard is active. No assertion that arbitrary future close paths are correct is made.

## Actual test delta

Only the suffix after the second failure response in the palette test changed. The preceding geometry, all-error-lines, native keyboard focus, native editor identity, query, active command, retry, and invocation-count assertions remain. The existing Escape and hidden assertions remain unchanged.

```diff
 await page.getByTestId('command-fail').click();
+// Observe the recovered error and bound busy state before requesting a UI close.
+await expect(dialog).toHaveAttribute('aria-busy','false');
+await expect(error).toContainText('エラーの末尾');
+await expect(search).toHaveValue('保存');
+await expect(search).toHaveAttribute('aria-activedescendant','catalog-palette-command-save');
 await search.press('Escape');
 await expect(dialog).toBeHidden();
 await finishNative(page,'palette-'+c.name);
```

The diff above expands the existing compact statement formatting for readability; the actual file uses the established compact format on lines 49-51. The added waits are assertions of the source-defined state transition, not elapsed-time settling.

## Source hashes

| File | Archive SHA-256 | Current SHA-256 |
| --- | --- | --- |
| `tests/ui/static-runtime-reassessment-navigation.spec.ts` | `e6c42faf2487bce5b07530b8118628714559a01404cd5a932e2b69726c9f1478` | `3a8a298257b28878eaacd69b0d0a68397987bf433068edba0ca2e5ea88b5e436` |
| `tests/ui/css-override-test.ts` | `87879619c19ecc8eb2b2acd65db71e08803cf61701887982b8abcaf69d085641` | same |
| `tests/fixture-app/navigation-catalog.ts` | `8879714f46322fbcb57e3cf5aa113fec9e2a84397927320b620d033f59f19819` | same |
| `templates/angular/command-palette.ts` | `48f4419a30224cf68ceee948a212609fea0bfcb9551f3c1cc20973a055678f8a` | same |
| `templates/angular/dialog.ts` | `bba2cd978843a86f22fefa1718fe8531fe8c610d4d5d0c187a7abb66f32af56b` | same |
| `templates/angular/overlay.ts` | `cb525ece71402ced6235553344dc3d157491cbe6b83efb89e5c716b3ff0fd982` | same |

The three `.ui/generated/angular/` counterparts have the same hashes as their template files in both the archive and live workspace.

## Commands and verification boundary

All commands ran in the repository root. Read-only source searches and `nl`/`sed` reads exited 0. One initial search incorrectly used `tests/fixture-app/src`; that path does not exist, and subsequent reads used the actual `tests/fixture-app/navigation-catalog.ts` path. No result was inferred from that failed path search.

| Command/probe | Exit | Observed result |
| --- | --- | --- |
| Python `zipfile.ZipFile` + JSON reads of `test.trace` and `1-trace.trace` for both failures | 0 | Action order, snapshots, busy/query/selection state, and failure timing above. No trace or historical result was changed. |
| Python `hashlib.sha256` comparison of the listed archive/live sources and failure artifacts | 0 | Source identity and hashes above. |
| `git diff --check -- tests/ui/static-runtime-reassessment-navigation.spec.ts` | 0 | No whitespace error. |
| `git diff -- tests/ui/static-runtime-reassessment-navigation.spec.ts` | 0 | Only the palette test suffix and explanatory comment changed. |
| `node --input-type=module` with `typescript.createSourceFile` and `node:assert/strict` | 0 | Zero parse diagnostics; AST confirms exactly two failure clicks, then the second click followed by idle/error/query/active assertions, Escape, hidden assertion, native-event finish. Existing all-error-lines, native error entry, and search-focus assertions remain. |
| Python exact archive/live text-delta assertion | 0 | Removing only the added recovered-state assertion block and comment reproduces the archived test byte for byte; the resulting test hash matches this report. |
| Browser/build/sync/typecheck/`npm test` | NOT_RUN | Parent-owned normal run was active. No concurrent heavy process was started. |

Next required verification belongs to the parent integration run against the corrected candidate: rerun the affected navigation test through the repository's normal supported UI pipeline after the existing heavy run ends, preserve all four contexts, and record the candidate/source hashes and actual result. This report does not convert the original A/C failures into passing browser evidence.
