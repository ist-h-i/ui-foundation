# Post-burst identity-history correction

Source frozen as an uncommitted snapshot on `feat/ui-static-warning-release`, base/current HEAD `2b46a4487a08e069bcae74fd98f62f4899789fa6`. The parent explicitly released source mutation after completing review v1. This worker changed only the two owned test sources below and this report; no ledger, Git, driver, product, generated source, or dependency changes.

| Frozen source | SHA-256 |
| --- | --- |
| `tests/ui/post-burst-paint.ts` | `25c0fd3a2def34739fddd649f52c57302b92644e3d3f6539044a7659b3dbc837` |
| `tests/ui/virtual-fast-tab.spec.ts` | `523b4df14e8245db103e680f47d996c95f3029a0ab3538ac3b8447646300dd54` |

## Accepted finding and correction

F1 was valid: review v1's observer watched child-list changes, focus, and sampled identity, so an attribute-driven A→B→A identity change between samples could be accepted. The baseline helper hash was `aaa05618b63103591284cd33559c2dc57c4fee7f85dcdfbe15356fc557a932ee`. The original report and immutable review probe remain unchanged.

The observer now requires explicit identity rules. The fast-tab caller declares nine target attributes (`id`, `data-fast-nested`, `data-fast-boundary`, `data-fast-control`, `role`, `aria-colindex`, `aria-posinset`, `aria-rowindex`, `data-virtual-row-key`), three ancestor attributes (`aria-posinset`, `aria-rowindex`, `data-virtual-row-key`), and the single identity selector class token `ui-virtual-row`. These cover the finite attribute/selector dependencies of the actual `identify` callback. Initial values are pinned on the target and its ancestor chain. Filtered attribute observation retains old values; each relevant record's old value and current value are compared with that pinned value. Pending records are drained before deciding an outcome. Thus restored identity still fails.

Class history compares only `ui-virtual-row` membership. Tokenization uses HTML ASCII whitespace, `/[\t\n\f\r ]+/`, matching DOMTokenList rather than splitting NBSP. Other class tokens, style, hidden, unrelated attributes, and unrelated nodes do not become identity failures. Removal detection also retains the pinned ancestry, including an ancestor removed before the target is moved elsewhere.

The observer remains read-only with respect to DOM, focus, scroll, and application state. It retains the synchronous cloned FIRST actual metric before its first await; initial/final metrics, attempts, elapsed time, outcome, deadline, focus-history and exact DOM-target checks are preserved. The 1000 ms application bound, original nine controls, exact geometry assertions and 1 px tolerances, native key delivery/keyup recorder/flush assertions, same-instance contexts, and 1040/2064 counts remain unchanged. No per-key pacing, test timeout, suite, driver, or tsconfig change was added. This is a finite oracle correction, not a causal explanation of the original native scroll position or a universal runtime-safety claim.

## Added native DOM controls

Ten new controls mutate and restore identity in the same queued microtask after the immutable initial sample, before the next frame. Each records actual A/B/A identities and requires `target-changed` even though the final target is connected, remains the same active DOM object, regains its original identity, and is painted.

| Scope | A→B→A dependency |
| --- | --- |
| Target | `id` |
| Target | `data-fast-control` |
| Target | `role` |
| Target | `aria-colindex` |
| Target | `data-fast-boundary` |
| Target | `data-fast-nested` |
| Ancestor row | `aria-posinset` |
| Ancestor row | `aria-rowindex` |
| Ancestor row | `data-virtual-row-key` selector presence, falling back to another ancestor |
| Ancestor row | `ui-virtual-row` class membership, falling back to another ancestor |

One positive control completes native DOM geometry through style changes, adds cosmetic classes on target/ancestor, updates an unrelated label, and adds then extends a class token containing NBSP (`cosmetic\u00a0ui-virtual-row`). It requires `ready` with no target issue. The shared dependency declaration is used by application observation and these controls. Controls are self-contained inline DOM with actual rectangles/hit testing and no historical artifact imports. Producers are separate from the read-only observer and do not pace application operations.

Counts: existing 9 observer controls + 10 identity-history controls + 1 cosmetic/style control = **20 observer controls**. The fast file has **25 expanded cases**, including the original five application cases. The supported three-engine broad matrix is expected to be **180 cases**, preserving the original 120 application/other-suite cases without filtering.

## Checks actually executed

Environment: existing checkout/dependencies, Node `v24.19.0`. No browser, build, dependency installation, or heavy suite was run.

* `node docs/verification/ui-static-warning-release-20261018/review-post-burst-paint-v1/identity-history-probe.mjs` before editing — exit 0, `COUNTEREXAMPLE_REPRODUCED`. The pinned old helper watched only `childList/subtree`; two attempted id mutations yielded zero delivered attribute records, and the observer returned `ready`, `targetIssue:null`, despite the recorded changed/restored identity. This was a finite mocked algorithm probe, not native acceptance.
* `node_modules/.bin/tsc -p tsconfig.ui-runtime.json` — exit 0, no diagnostics.
* Read-only inline `node --input-type=module` old/new VM contract probe — exit 0, `PASS`. Same mocked producer scenarios against the base helper and corrected helper: **10 old counterexamples returned `ready`; all 10 corrected identity histories returned `target-changed`; the cosmetic/style case remained `ready` in both**. Each negative emitted two attribute changes; old helper delivered zero, corrected helper delivered two. Corrected cosmetic case delivered three relevant class records while style/label stayed outside the filter. Cleanup left zero listeners/observers. Corrected filter had ten distinct names, with `attributes:true` and `attributeOldValue:true`. Old/current helper hashes matched the hashes above. The mocks exercise the finite observation algorithm; they do not prove native DOM behavior, rendering, keyboard delivery, or application acceptance.
* Read-only inline TypeScript AST/source audit — exit 0, exact output:

```json
{
  "status": "PASS",
  "base": "2b46a4487a08e069bcae74fd98f62f4899789fa6",
  "unchangedFunctions": 6,
  "unchangedProbeMembers": 4,
  "unchangedNativeTestDeclarations": 4,
  "unchangedExistingControlDeclarations": 4,
  "existingObserverControls": 9,
  "addedIdentityHistoryControls": 10,
  "addedCosmeticStyleControls": 1,
  "totalObserverControls": 20,
  "expandedFastFileCases": 25,
  "expectedSupportedBroadCases": 180,
  "exactGeometryAssertions": "BYTE_IDENTICAL",
  "initialSampleBeforeFirstAwait": true,
  "identityRuleTargetAttributes": 9,
  "identityRuleAncestorAttributes": 3,
  "identityClassTokens": 1,
  "classSplit": "HTML_ASCII_WHITESPACE",
  "observerForbiddenCalls": 0,
  "observerPropertyWrites": 0,
  "newTimeoutOverrides": 0,
  "browser": "NOT_RUN"
}
```

The audit byte-compared the six existing native helpers and probe paint/read/keydown/keyup members, compared all four original native declarations and four existing control declarations, retained every exact geometry assertion, checked the declared dependency lists and initial-sample/await order, and scanned the observer for focus/scroll/DOM mutation calls and property writes. Static results are separate from rendered acceptance.

* `git diff --check -- tests/ui/post-burst-paint.ts tests/ui/virtual-fast-tab.spec.ts` — exit 0, no output.

**All twenty native DOM controls, Chromium/Firefox/WebKit acceptance, supported broad suite, normal suite, build, and fresh independent v2 review: NOT_RUN by this worker.** The parent owns those steps and the direct helper evidence/ledger hash update. No worktree or subagent was created; unrelated work was preserved. No worker process remains active.
