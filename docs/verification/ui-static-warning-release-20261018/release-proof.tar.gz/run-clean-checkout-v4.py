"""Run the normal suite from committed files, with a private copy of pinned dev dependencies."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tarfile
import tempfile

p = Path(__file__).resolve().parent
root = p.parents[2]
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
stamp = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
spec = importlib.util.spec_from_file_location('capture', p / 'run.py')
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
inputs = capture.inputs()
target = Path(tempfile.mkdtemp(prefix='ui-foundation-release-v4-'))
receipt = {'head': head, 'started_at': stamp(), 'checkout': str(target), 'source_inputs': inputs,
    'harness_sha256': sha(Path(__file__)), 'capture_driver_sha256': sha(p / 'run.py'),
    'archive_only': True, 'historical_work_directories_copied': False, 'node_modules_symlink': False, 'status': 'PREPARING'}
save = lambda: (p / 'clean-checkout-v4.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
save()
try:
    archive = target / '.candidate.tar'
    with archive.open('wb') as output:
        subprocess.run(['git', 'archive', '--format=tar', head], cwd=root, stdout=output, check=True)
    with tarfile.open(archive) as bundle:
        bundle.extractall(target, filter='data')
    archive.unlink()
    for file, digest in inputs.items():
        assert sha(target / file) == digest, f'Committed checkout missing or different: {file}'
    receipt['committed_source_inputs_verified'] = len(inputs)
    subprocess.run(['cp', '-cR', str(root / 'node_modules'), str(target / 'node_modules')], check=True)
    assert not (target / 'node_modules').is_symlink()
    receipt['dev_dependencies'] = {name: json.loads((target / 'node_modules' / name / 'package.json').read_text())['version']
        for name in ['typescript', '@angular/core', '@playwright/test']}
    with socket.socket() as port:
        port.bind(('127.0.0.1', 0))
        selected_port = port.getsockname()[1]
    env = {**os.environ, 'NODE_PATH': '', 'CI': '1', 'FORCE_COLOR': '0', 'UI_FIXTURE_PORT': str(selected_port)}
    receipt.update({'status': 'RUNNING', 'command': ['npm', 'test'], 'fixture_port': selected_port, 'dependencies_copy': 'APFS clone; no main-checkout module symlink'})
    save()
    print(json.dumps({'phase': 'clean-checkout-ready', 'head': head, 'source_inputs': len(inputs), 'checkout': str(target)}), flush=True)
    done = subprocess.run(['npm', 'test'], cwd=target, env=env)
    receipt['npm_test_exit_code'] = done.returncode
    receipt['source_changes'] = [file for file, digest in inputs.items() if not (target / file).is_file() or sha(target / file) != digest]
    receipt['status'] = 'PASSED' if done.returncode == 0 and not receipt['source_changes'] else 'FAILED'
    receipt['completed_at'] = stamp()
    receipt['checkout_retained_for_inspection'] = True
    fixture_bundle = target / 'dist/fixture-app/main.js'
    if fixture_bundle.exists():
        receipt['fixture_bundle_sha256'] = sha(fixture_bundle)
    save()
    raise SystemExit(0 if receipt['status'] == 'PASSED' else done.returncode or 1)
except Exception as error:
    receipt.update({'status': 'PREPARATION_OR_EXECUTION_ERROR', 'error': str(error), 'completed_at': stamp(), 'checkout_retained_for_inspection': True})
    save()
    raise
