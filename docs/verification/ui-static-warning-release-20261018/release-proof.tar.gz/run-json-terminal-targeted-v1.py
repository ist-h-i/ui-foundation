"""Run all four R161 contexts through the normal guarded UI entry point."""
from pathlib import Path
import datetime
import json
import os
import socket
import subprocess

p = Path(__file__).resolve().parent
root = p.parents[2]
output = p / 'json-terminal-targeted-v1'
output.mkdir(exist_ok=False)
with socket.socket() as port:
    port.bind(('127.0.0.1', 0))
    selected_port = port.getsockname()[1]
command = ['npm', 'run', 'test:ui', '--', 'tests/ui/static-runtime-reassessment-layout.spec.ts',
           '--grep', 'reassessment specialist-style R161', '--workers=1', '--reporter=json',
           '--output=' + str(output / 'artifacts')]
receipt = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
           'command': command, 'scope': 'Explicit R161 A/B/C/D only; normal guarded Playwright webServer build, no existing server reuse.',
           'fixture_port': selected_port, 'status': 'RUNNING'}
save = lambda: (output / 'run-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
save()
result = subprocess.run(command, cwd=root, env={**os.environ, 'CI': '1', 'NODE_PATH': '', 'FORCE_COLOR': '0',
    'UI_FIXTURE_PORT': str(selected_port), 'PLAYWRIGHT_JSON_OUTPUT_NAME': str(output / 'results.json')})
receipt['exit_code'] = result.returncode
with socket.socket() as probe:
    probe.settimeout(1)
    receipt['owned_listener_closed'] = probe.connect_ex(('127.0.0.1', selected_port)) != 0
receipt['status'] = 'PASSED' if result.returncode == 0 and receipt['owned_listener_closed'] else 'FAILED'
receipt['completed_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
raise SystemExit(0 if receipt['status'] == 'PASSED' else result.returncode or 1)
