import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {cp,lstat,mkdir,mkdtemp,readFile,readdir,realpath,rm,symlink,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {parse} from 'yaml';
import {prepareSvgConsumer} from '../../../../scripts/verification/prepare-svg-consumer.mjs';
const root=fileURLToPath(new URL('../../../../',import.meta.url));
const here=fileURLToPath(new URL('./',import.meta.url));
const digest=b=>createHash('sha256').update(b).digest('hex');
async function walk(directory,relative=''){
 const rows=[];
 for(const entry of await readdir(join(directory,relative),{withFileTypes:true})){
  const path=join(relative,entry.name);
  if(entry.isDirectory())rows.push(...await walk(directory,path));
  else if(entry.isFile())rows.push({path,kind:'file'});
  else if(entry.isSymbolicLink())rows.push({path,kind:'symlink'});
  else rows.push({path,kind:'other'});
 }
 return rows;
}
const output={node:process.version,assertions:[]};
const work=await mkdtemp(join(here,'positive-'));
try{
 const fixtures=join(root,'tests/consumer-svg-paint');
 const sourceFolders=['src','templates','skills','examples','tests/fixture-app'];
 const sourcePaths=['package.json','package-lock.json','tsconfig.json'];
 const expected=[];
 for(const folder of sourceFolders){
  const rows=await walk(join(root,folder));assert.ok(rows.every(row=>row.kind==='file'),'source tree has only regular files/directories');
  expected.push(...rows.map(row=>join(folder,row.path)));
 }
 expected.push(...sourcePaths);
 const {sourceFiles,installed}=await prepareSvgConsumer({root,work,fixtures});
 const inventory=new Map(sourceFiles.map(file=>[file.path,file]));
 assert.equal(inventory.size,sourceFiles.length,'no duplicate inventory rows');
 assert.deepEqual([...inventory.keys()].sort(),expected.sort(),'exact input inventory, no omitted source files');
 const fixtureRows=await walk(fixtures);assert.ok(fixtureRows.every(row=>row.kind==='file'));
 assert.equal(fixtureRows.filter(row=>inventory.has(row.path)).length,0,'public fixture overlay has no source input collisions');
 for(const file of sourceFiles){
  const bytes=await readFile(join(root,file.path));
  assert.equal(digest(bytes),file.sha256);assert.equal(bytes.length,file.bytes);
  assert.deepEqual(await readFile(join(work,file.path)),bytes);
 }
 for(const file of fixtureRows)assert.deepEqual(await readFile(join(work,file.path)),await readFile(join(fixtures,file.path)));
 assert.equal(await realpath(join(work,'node_modules')),await realpath(join(root,'node_modules')));
 assert.equal((await lstat(join(work,'node_modules'))).isSymbolicLink(),true);
 const actual=await walk(work);
 assert.deepEqual(actual.filter(row=>row.kind==='symlink').map(row=>row.path),['node_modules']);
 assert.deepEqual(actual.filter(row=>row.kind==='file').map(row=>row.path).sort(),[...expected,...fixtureRows.map(row=>row.path)].sort());
 const config=parse(await readFile(join(root,'examples/ui.config.example.yaml'),'utf8'));
 const canonicalInputs=new Set(config.checks.exceptions.map(row=>row.file));
 const roots=[];
 for(const folder of config.checks.source_roots){const files=await walk(join(root,folder));roots.push({path:folder,regular_files:files.length});for(const file of files)canonicalInputs.add(join(folder,file.path));}
 for(const path of canonicalInputs)assert.ok(inventory.has(path));
 assert.ok(inventory.has(config.checks.tsconfig));
 output.positive={sourceFiles:sourceFiles.length,installed:installed.length,sourceRoots:roots,exceptions:config.checks.exceptions.length,uniqueExceptionFiles:new Set(config.checks.exceptions.map(row=>row.file)).size,canonicalSourceAndExceptionFiles:canonicalInputs.size,publicFixtureFiles:fixtureRows.length,publicOverlayCollisions:0,regularFileBytes:sourceFiles.reduce((sum,file)=>sum+file.bytes,0)};
 output.assertions.push('full exact input inventory and byte copies','full public fixture byte copies, no input collisions','work contains only expected regular files plus shared node_modules symlink','all configured source/exception/tsconfig inputs inventoried');
}finally{await rm(work,{recursive:true,force:true});}
assert.ok((await lstat(join(root,'node_modules'))).isDirectory()||(await lstat(join(root,'node_modules'))).isSymbolicLink());
const synthetic=await mkdtemp(join(here,'failure-'));
try{
 const model=join(synthetic,'source');const fixture=join(synthetic,'fixture');const work=join(synthetic,'work');
 await mkdir(work);await mkdir(fixture);await writeFile(join(fixture,'consumer.ts'),'public fixture bytes');
 for(const folder of ['src','templates','skills','examples','tests/fixture-app']){await mkdir(join(model,folder),{recursive:true});await writeFile(join(model,folder,'input.txt'),folder);}
 await writeFile(join(model,'package.json'),JSON.stringify({devDependencies:{sentinel:'1.0.0'}}));
 await writeFile(join(model,'package-lock.json'),'{}');await writeFile(join(model,'tsconfig.json'),'{}');
 await mkdir(join(model,'node_modules/sentinel'),{recursive:true});const packageFile=join(model,'node_modules/sentinel/package.json');await writeFile(packageFile,JSON.stringify({version:'2.0.0'}));
 const before=await readFile(packageFile);
 let failure;
 try{await prepareSvgConsumer({root:model,work,fixtures:fixture});}catch(error){failure=error;}
 assert.equal(failure?.code,'ERR_ASSERTION');assert.equal(failure?.message.startsWith('sentinel exact dependency'),true);
 assert.equal((await lstat(join(work,'node_modules'))).isSymbolicLink(),true);
 await rm(work,{recursive:true,force:true});
 assert.deepEqual(await readFile(packageFile),before,'recursive work cleanup preserves symlink target');
 output.error={code:failure.code,message:failure.message,dependencyMismatchRejected:true,cleanupPreservedSymlinkTarget:true};
 output.assertions.push('wrong installed dependency version rejects preparation','recursive work cleanup unlinks node_modules without traversing source target');
}finally{await rm(synthetic,{recursive:true,force:true});}
console.log(JSON.stringify(output,null,2));
