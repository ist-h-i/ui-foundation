from pathlib import Path
import hashlib, json, os, subprocess, sys, time, datetime

phase = Path(__file__).resolve().parent
component = sys.argv[1]
assert component in ['menu', 'chart']
repo = phase / component / 'repository'
evidence = phase / component / 'evidence'
results = []

def hashes(paths):
    return {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest()
            for directory in paths for p in sorted((repo / directory).rglob('*')) if p.is_file()}

def step(name, args):
    start = time.monotonic()
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    env = dict(os.environ, REVIEW_EVIDENCE=str(evidence))
    result = subprocess.run(args, cwd=repo, env=env, text=True, capture_output=True)
    (evidence / (name + '.log')).write_text(result.stdout + result.stderr)
    (evidence / (name + '.exit')).write_text(str(result.returncode) + '\n')
    row = dict(step=name, args=args, start=now, seconds=round(time.monotonic()-start, 3), exit=result.returncode)
    results.append(row)
    (evidence / 'build-results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if result.returncode:
        sys.exit(result.returncode)

before = hashes(['src', 'templates', 'skills', 'examples'])
inputs = hashes(['tests', 'harness'])
for filename in ['consumer.ts', 'tsconfig.consumer.json', 'build-consumer.mjs', 'serve-consumer.mjs', 'playwright.config.ts', 'tsconfig.json']:
    if (repo / filename).exists():
        inputs[filename] = hashlib.sha256((repo / filename).read_bytes()).hexdigest()
(evidence / 'consumer-input.json').write_text(json.dumps(inputs, indent=2) + '\n')
cli = ['node', '--import', 'tsx', 'src/cli.ts']
config = ['--config', 'examples/ui.config.example.yaml']
step('sync', cli + ['sync'] + config)
generated = hashes(['.ui/generated', '.agents'])
step('check', cli + ['check'] + config)
step('idempotent-sync', cli + ['sync'] + config)
assert generated == hashes(['.ui/generated', '.agents']), 'Idempotent generation changed owned bytes'
step('dry-run-sync', cli + ['sync'] + config + ['--dry-run'])
assert generated == hashes(['.ui/generated', '.agents']), 'Dry run changed owned bytes'
if component == 'menu':
    step('full139-aot', ['node', 'node_modules/@angular/compiler-cli/bundles/src/bin/ngc.js', '-p', 'tsconfig.json'])
    step('public-consumer-bundle', ['node', 'scripts/build.mjs'])
    step('semantic-css', ['node', 'node_modules/@tailwindcss/cli/dist/index.mjs', '-i', 'tests/fixture-app/styles.css', '-o', 'dist/fixture-app/styles.css'])
    step('focused-test-strict', ['node', 'node_modules/typescript/bin/tsc', '--ignoreConfig', '--noEmit', '--skipLibCheck', '--strict', '--types', 'node', '--target', 'ES2022', '--module', 'ESNext', '--moduleResolution', 'bundler', 'tests/cross-browser/runtime-cross-browser.spec.ts', 'tests/cross-browser/runtime-test.ts', 'tests/cross-browser/independent-menu-critic.spec.ts'])
else:
    step('production-public-consumer', ['node', 'build-consumer.mjs'])
after = hashes(['src', 'templates', 'skills', 'examples'])
assert before == after, 'Critic raw source changed during build'
(evidence / 'generated-owned-shas.json').write_text(json.dumps(generated, indent=2) + '\n')
(evidence / 'build-integrity.json').write_text(json.dumps({'sourceChanged': [], 'generatedIdempotencyChanged': [], 'dryRunChanged': [], 'publicIndex': hashlib.sha256((repo / '.ui/generated/angular/index.ts').read_bytes()).hexdigest(), 'rawTsCount': len(list((repo / 'templates/angular').glob('*.ts'))), 'allActualExitZero': all(r['exit'] == 0 for r in results), 'steps': len(results)}, indent=2) + '\n')
