import {test,expect} from './runtime-test';

async function setup(page:any,profile:string){
 await page.goto('/catalog');await page.locator('#catalog-profile').selectOption(profile);
 await page.setViewportSize({width:320,height:800});await page.evaluate(()=>document.documentElement.style.fontSize='200%');
 await page.emulateMedia({reducedMotion:'reduce'});await page.getByLabel('RTL',{exact:true}).check();
}

test('Independent Menu guided: focused sibling is the roving item while its old submenu remains open',async({page},info)=>{
 await setup(page,'guided');const trigger=page.getByRole('button',{name:'申請の操作',exact:true}),popup=page.locator('#recursive-menu');
 await trigger.focus();await trigger.press('ArrowDown');const file=popup.getByRole('menuitem',{name:'ファイル',exact:true});
 await file.press('ArrowLeft');await expect(popup.getByRole('menuitem',{name:'新規',exact:true})).toBeFocused();
 await file.focus();await file.press('ArrowDown');const sibling=popup.getByRole('menuitem',{name:'出力',exact:true});await expect(sibling).toBeFocused();
 const observation=await popup.evaluate(element=>({active:{id:document.activeElement?.id,tabIndex:(document.activeElement as HTMLElement)?.tabIndex},levels:[...element.querySelectorAll('[role=menu]')].map(menu=>({id:menu.id||'root',tabStops:[...menu.querySelectorAll<HTMLButtonElement>('button[tabindex="0"]')].filter(button=>button.closest('[role=menu]')===menu).map(button=>({id:button.id,back:button.dataset.menuBack}))}))}));
 await info.attach('focused-sibling-roving',{body:JSON.stringify(observation,null,2),contentType:'application/json'});
 await expect(sibling).toHaveAttribute('tabindex','0');
 expect(observation.levels.every(level=>level.tabStops.length===1)).toBe(true);
 await page.keyboard.press('Tab');await expect(page.getByRole('button',{name:'Menuの次の操作',exact:true})).toBeFocused();await expect(popup).toBeHidden();
});

for(const profile of ['guided','dense'])test('Independent Menu '+profile+': Tab guards preserve opened trigger and context',async({page},info)=>{
 await setup(page,profile);const observations=[];
 for(const kind of ['click','hover','context']){
  const trigger=kind==='click'?page.getByRole('button',{name:'申請の操作',exact:true}):kind==='hover'?page.getByRole('button',{name:'hoverメニュー',exact:true}):page.locator('ui-context-menu .ui-menu__context');
  const popup=page.locator(kind==='click'?'#recursive-menu':kind==='hover'?'#hover-menu':'#context-menu');
  await trigger.focus();if(kind==='hover')await trigger.hover();else await trigger.press(kind==='context'?'Shift+F10':'ArrowDown');await expect(popup).toBeVisible();await trigger.focus();
  for(const guard of ['defaultPrevented','isComposing','keyCode229']){
   const event=await trigger.evaluate((element,guard)=>{const event=new KeyboardEvent('keydown',{key:'Tab',bubbles:true,cancelable:true,isComposing:guard==='isComposing'});if(guard==='keyCode229')Object.defineProperty(event,'keyCode',{value:229});if(guard==='defaultPrevented')event.preventDefault();element.dispatchEvent(event);return{guard,defaultPrevented:event.defaultPrevented,isComposing:event.isComposing,keyCode:event.keyCode,activeId:document.activeElement?.id};},guard);
   await expect(popup).toBeVisible();await expect(trigger).toBeFocused();observations.push({kind,...event,syntheticGuardOnly:true});
  }
  await trigger.press('Tab');await expect(popup).toBeHidden();await page.mouse.move(0,0);
 }
 await info.attach('guard-observations',{body:JSON.stringify(observations,null,2),contentType:'application/json'});
});
