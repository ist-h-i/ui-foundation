# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: independent-menu-critic.spec.ts >> Independent Menu guided: focused sibling is the roving item while its old submenu remains open
- Location: tests/cross-browser/independent-menu-critic.spec.ts:9:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('#recursive-menu').getByRole('menuitem', { name: '出力', exact: true })
Expected: "0"
Received: "-1"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" locator('#recursive-menu').getByRole('menuitem', { name: '出力', exact: true }) with timeout 5000ms
  - waiting for locator('#recursive-menu').getByRole('menuitem', { name: '出力', exact: true })
    14 × locator resolved to <button type="button" tabindex="-1" role="menuitem" data-menu-item="export" _ngcontent-ng-c1718148430="" id="recursive-menu-item-export">…</button>
       - unexpected value "-1"

```

```yaml
- menuitem "出力"
```

# Test source

```ts
  1  | import {test,expect} from './runtime-test';
  2  | 
  3  | async function setup(page:any,profile:string){
  4  |  await page.goto('/catalog');await page.locator('#catalog-profile').selectOption(profile);
  5  |  await page.setViewportSize({width:320,height:800});await page.evaluate(()=>document.documentElement.style.fontSize='200%');
  6  |  await page.emulateMedia({reducedMotion:'reduce'});await page.getByLabel('RTL',{exact:true}).check();
  7  | }
  8  | 
  9  | test('Independent Menu guided: focused sibling is the roving item while its old submenu remains open',async({page},info)=>{
  10 |  await setup(page,'guided');const trigger=page.getByRole('button',{name:'申請の操作',exact:true}),popup=page.locator('#recursive-menu');
  11 |  await trigger.focus();await trigger.press('ArrowDown');const file=popup.getByRole('menuitem',{name:'ファイル',exact:true});
  12 |  await file.press('ArrowLeft');await expect(popup.getByRole('menuitem',{name:'新規',exact:true})).toBeFocused();
  13 |  await file.focus();await file.press('ArrowDown');const sibling=popup.getByRole('menuitem',{name:'出力',exact:true});await expect(sibling).toBeFocused();
  14 |  const observation=await popup.evaluate(element=>({active:{id:document.activeElement?.id,tabIndex:(document.activeElement as HTMLElement)?.tabIndex},levels:[...element.querySelectorAll('[role=menu]')].map(menu=>({id:menu.id||'root',tabStops:[...menu.querySelectorAll<HTMLButtonElement>('button[tabindex="0"]')].filter(button=>button.closest('[role=menu]')===menu).map(button=>({id:button.id,back:button.dataset.menuBack}))}))}));
  15 |  await info.attach('focused-sibling-roving',{body:JSON.stringify(observation,null,2),contentType:'application/json'});
> 16 |  await expect(sibling).toHaveAttribute('tabindex','0');
     |                        ^ Error: expect(locator).toHaveAttribute(expected) failed
  17 |  expect(observation.levels.every(level=>level.tabStops.length===1)).toBe(true);
  18 |  await page.keyboard.press('Tab');await expect(page.getByRole('button',{name:'Menuの次の操作',exact:true})).toBeFocused();await expect(popup).toBeHidden();
  19 | });
  20 | 
  21 | for(const profile of ['guided','dense'])test('Independent Menu '+profile+': Tab guards preserve opened trigger and context',async({page},info)=>{
  22 |  await setup(page,profile);const observations=[];
  23 |  for(const kind of ['click','hover','context']){
  24 |   const trigger=kind==='click'?page.getByRole('button',{name:'申請の操作',exact:true}):kind==='hover'?page.getByRole('button',{name:'hoverメニュー',exact:true}):page.locator('ui-context-menu .ui-menu__context');
  25 |   const popup=page.locator(kind==='click'?'#recursive-menu':kind==='hover'?'#hover-menu':'#context-menu');
  26 |   await trigger.focus();if(kind==='hover')await trigger.hover();else await trigger.press(kind==='context'?'Shift+F10':'ArrowDown');await expect(popup).toBeVisible();await trigger.focus();
  27 |   for(const guard of ['defaultPrevented','isComposing','keyCode229']){
  28 |    const event=await trigger.evaluate((element,guard)=>{const event=new KeyboardEvent('keydown',{key:'Tab',bubbles:true,cancelable:true,isComposing:guard==='isComposing'});if(guard==='keyCode229')Object.defineProperty(event,'keyCode',{value:229});if(guard==='defaultPrevented')event.preventDefault();element.dispatchEvent(event);return{guard,defaultPrevented:event.defaultPrevented,isComposing:event.isComposing,keyCode:event.keyCode,activeId:document.activeElement?.id};},guard);
  29 |    await expect(popup).toBeVisible();await expect(trigger).toBeFocused();observations.push({kind,...event,syntheticGuardOnly:true});
  30 |   }
  31 |   await trigger.press('Tab');await expect(popup).toBeHidden();await page.mouse.move(0,0);
  32 |  }
  33 |  await info.attach('guard-observations',{body:JSON.stringify(observations,null,2),contentType:'application/json'});
  34 | });
  35 | 
```