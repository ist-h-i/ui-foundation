from pathlib import Path
import datetime, hashlib, json, os, socket, subprocess, sys, time

phase = Path(__file__).resolve().parent
component = sys.argv[1]
assert component in ['menu', 'chart']
repo = phase / component / 'repository'
evidence = phase / component / 'evidence'
integrity = json.loads((evidence / 'build-integrity.json').read_text())
assert integrity['allActualExitZero']
with socket.socket() as probe:
    assert probe.connect_ex(('127.0.0.1', 5483)) != 0, 'Port5483 belongs to an existing listener; no process killed'

def run(name, args, overrides):
    target = evidence / 'native' / name
    target.mkdir(parents=True)
    env = dict(os.environ, **overrides)
    start = time.monotonic()
    with (target / 'native.log').open('w') as log:
        child = subprocess.Popen(args, cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for line in child.stdout:
            log.write(line)
            log.flush()
            print(line.rstrip(), flush=True)
        code = child.wait()
    (target / 'native.exit').write_text(str(code) + '\n')
    receipt = dict(name=name, args=args, env=overrides, pid=child.pid, start=start, seconds=round(time.monotonic()-start, 3), actualExit=code)
    (target / 'execution.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return receipt

started_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
results = []
server = None
server_log = None
try:
    if component == 'menu':
        target = evidence / 'native' / 'focused-five'
        results.append(run('focused-five', ['node', 'node_modules/@playwright/test/cli.js', 'test', '--config', 'playwright.config.ts', '--project', 'chromium', '--grep', '^(Menu |Independent Menu )'], {'REPORT_JSON': str(target / 'results.json'), 'REPORT_DIR': str(target / 'artifacts')}))
    else:
        server_log = (evidence / 'native-server.log').open('w')
        server = subprocess.Popen(['node', 'serve-consumer.mjs'], cwd=repo, env=dict(os.environ, SVG_PORT='5483'), stdout=server_log, stderr=subprocess.STDOUT, text=True)
        for attempt in range(100):
            if server.poll() is not None:
                raise RuntimeError('Own server exited before startup')
            with socket.socket() as probe:
                if probe.connect_ex(('127.0.0.1', 5483)) == 0:
                    break
            time.sleep(.1)
        else:
            raise RuntimeError('Own server5483 never became reachable')
        for config in ['guided-320-rtl', 'guided-1280-rtl', 'dense-320-rtl', 'dense-1280-rtl']:
            target = evidence / 'native' / config
            results.append(run(config, ['node', 'harness/verify-paint.mjs'], {'SVG_CONSUMER_URL': 'http://127.0.0.1:5483/', 'SVG_PAINT_EVIDENCE_DIR': str(target) + '/', 'PAINT_CONFIG': config}))
finally:
    if server is not None:
        if server.poll() is None:
            server.terminate()
        try:
            server.wait(timeout=10)
        except subprocess.TimeoutExpired:
            server.kill()
            server.wait(timeout=10)
        if server_log:
            server_log.close()
    with socket.socket() as probe:
        port_closed = probe.connect_ex(('127.0.0.1', 5483)) != 0
    source_input = json.loads((evidence / 'raw-source-input.json').read_text())['inputs']
    source_changed = [item['path'] for item in source_input if hashlib.sha256((repo / item['path']).read_bytes()).hexdigest() != item['sha256']]
    receipt = dict(component=component, startedAt=started_at, endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(), rootSourceCommit='37ecf88b05b6cae1510e3291d7fc75e62217892b', productSourceChanged=source_changed, focusedRuns=results, ownedServerPid=server.pid if server else None, ownedServerExit=server.returncode if server else None, port5483Closed=port_closed, otherProcessesKilled=False, retries=0, negativeControlsRerun=False)
    (evidence / 'native-execution.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
assert not source_changed
assert port_closed
assert results
sys.exit(0 if all(r['actualExit'] == 0 for r in results) else 1)
